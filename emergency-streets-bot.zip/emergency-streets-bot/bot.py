"""Emergency Streets Discord Bot"""
import sys
import os as _os

# ── Pterodactyl fix: pip install --prefix .local puts packages here ──────────
_base = _os.path.dirname(_os.path.abspath(__file__))
for _prefix in [_os.path.join(_base, ".local", "lib"),
                _os.path.join(_os.path.expanduser("~"), ".local", "lib")]:
    if _os.path.isdir(_prefix):
        for _pyver in _os.listdir(_prefix):
            _sp = _os.path.join(_prefix, _pyver, "site-packages")
            if _os.path.isdir(_sp) and _sp not in sys.path:
                sys.path.insert(0, _sp)
# ─────────────────────────────────────────────────────────────────────────────

from typing import List, Dict, Optional, Any
import asyncio
import io
import re
import time
from datetime import datetime, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks

from config import (
    TOKEN, BRAND, ACTIVITY_ROTATION, ACTIVITY_INTERVAL_S,
    DEFAULT_PREFIX, MAX_PREFIX_LENGTH, APPLICATION_ACCEPT_ROLE_ID,
    OWNER_IDS,
)
from store import (
    load_store, get_guild, persist, is_staff as _store_is_staff,
    ANTINUKE_ACTIONS, ANTINUKE_ACTION_LABELS, get_antinuke_rule, set_antinuke_rule,
    LOG_EVENTS, LOG_EVENT_LABELS, is_log_event_enabled,
    get_automod, DEFAULT_AUTOMOD,
)
from embeds import brand_embed, success_embed, error_embed, info_embed, warn_embed

load_store()

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True
intents.invites = True
intents.bans = True
intents.voice_states = True
intents.messages = True
intents.reactions = True

bot = commands.Bot(
    command_prefix=lambda b, m: get_guild(str(m.guild.id)).get("prefix", DEFAULT_PREFIX) if m.guild else DEFAULT_PREFIX,
    intents=intents,
)

# ─── Global per-user cooldowns ────────────────────────────────────────────────
# Throttle BOTH prefix and slash commands per-user to avoid hammering Discord's
# API and triggering global rate limits. These are intentionally lenient so
# normal users won't notice, but they will stop runaway loops / button-mashing.
#
# Rate: 3 command invocations per 5 seconds per user.
_COOLDOWN_RATE = 3
_COOLDOWN_PER = 5.0
_user_cmd_hits: Dict[int, List[float]] = {}


def _check_user_cooldown(user_id: int) -> float:
    """Returns 0 if allowed, else seconds to wait before retry."""
    now = time.time()
    hits = _user_cmd_hits.get(user_id, [])
    # Drop expired entries
    hits = [t for t in hits if now - t < _COOLDOWN_PER]
    if len(hits) >= _COOLDOWN_RATE:
        retry = _COOLDOWN_PER - (now - hits[0])
        _user_cmd_hits[user_id] = hits
        return max(retry, 0.0)
    hits.append(now)
    _user_cmd_hits[user_id] = hits
    return 0.0


@bot.check
async def _global_prefix_cooldown(ctx: commands.Context):
    if ctx.author.bot or not ctx.guild:
        return True
    if ctx.author.id in (bot.owner_ids or ()):
        return True
    retry = _check_user_cooldown(ctx.author.id)
    if retry > 0:
        raise commands.CommandOnCooldown(
            commands.Cooldown(_COOLDOWN_RATE, _COOLDOWN_PER), retry, commands.BucketType.user
        )
    return True


async def _global_app_cooldown(interaction: discord.Interaction) -> bool:
    # Only throttle real command invocations (not buttons, selects, modals)
    if interaction.type != discord.InteractionType.application_command:
        return True
    if interaction.user and interaction.user.id in (bot.owner_ids or ()):
        return True
    retry = _check_user_cooldown(interaction.user.id) if interaction.user else 0.0
    if retry > 0:
        try:
            await interaction.response.send_message(
                embed=error_embed("Slow down", f"Try again in **{retry:.1f}s**."),
                ephemeral=True,
            )
        except Exception:
            pass
        return False
    return True


bot.tree.interaction_check = _global_app_cooldown  # type: ignore[assignment]

# ─── Extended attributes for new cogs ─────────────────────────────────────────
import json as _json

bot.owner_ids = 1489089980818133154,1424536373221920891  # type: ignore

def _load_staff_roles() -> dict:
    for path in ["database/staff_roles.json", "data/staff_roles.json"]:
        if _os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as _f:
                    return _json.load(_f)
            except Exception:
                pass
    return {}

def _save_staff_roles(d: dict) -> None:
    for path in ["database/staff_roles.json", "data/staff_roles.json"]:
        _os.makedirs(_os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as _f:
            _json.dump(d, _f, indent=4)

def _load_prefixes() -> dict:
    for path in ["database/prefixes.json", "data/prefixes.json"]:
        if _os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as _f:
                    return _json.load(_f)
            except Exception:
                pass
    return {}

def _save_prefixes(d: dict) -> None:
    for path in ["database/prefixes.json", "data/prefixes.json"]:
        _os.makedirs(_os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as _f:
            _json.dump(d, _f, indent=2)

bot.staff_roles = _load_staff_roles()  # type: ignore
bot.save_staff_roles = lambda: _save_staff_roles(bot.staff_roles)  # type: ignore
bot.prefixes = _load_prefixes()  # type: ignore
bot.save_prefixes = lambda: _save_prefixes(bot.prefixes)  # type: ignore
bot.default_prefix = DEFAULT_PREFIX  # type: ignore

# ─── Activity rotation ────────────────────────────────────────────────────────
# NOTE: Discord limits presence updates to roughly 5/min globally. Two parallel
# rotation loops (this one + cogs/status_cog.py) updating presence frequently
# was a major contributor to the global 429 rate-limit storm.
# `cogs/status_cog.py` now owns presence rotation at a safe interval, so this
# secondary loop is enforced to a safe minimum interval as well and is no
# longer started automatically (see on_ready below).
_activity_idx = 0

# Force a safe minimum interval (>= 60s) regardless of what ACTIVITY_INTERVAL_S says.
_SAFE_ACTIVITY_INTERVAL_S = max(int(ACTIVITY_INTERVAL_S or 0), 180)


@tasks.loop(seconds=_SAFE_ACTIVITY_INTERVAL_S)
async def rotate_activity():
    global _activity_idx
    if not bot.user:
        return
    try:
        a = ACTIVITY_ROTATION[_activity_idx % len(ACTIVITY_ROTATION)]
        atype = {0: discord.ActivityType.playing, 2: discord.ActivityType.listening,
                 3: discord.ActivityType.watching, 5: discord.ActivityType.competing}.get(a["type"], discord.ActivityType.playing)
        await bot.change_presence(activity=discord.Activity(name=a["name"], type=atype))
        _activity_idx += 1
    except Exception as e:
        print(f"[bot] rotate_activity error: {e}")


# ═════════════════════════ DM BROADCAST ═════════════════════════
def build_broadcast_embed(guild: discord.Guild, sender: discord.User, message: str) -> discord.Embed:
    icon = guild.icon.url if guild.icon else None
    e = discord.Embed(color=BRAND["color"], timestamp=datetime.now(timezone.utc))
    e.set_author(name="Official Server Message", icon_url=icon)
    from embeds import expand_newlines
    body = expand_newlines(message).replace("\n", "\n> ")
    e.description = f"> {body}"
    e.add_field(name="🌐 Server", value=guild.name, inline=False)
    e.add_field(name="👤 Sent By", value=sender.name, inline=False)
    e.set_footer(text=f"{BRAND['name']} Broadcast System")
    if icon:
        e.set_thumbnail(url=icon)
    return e


async def dm_members(members: List[discord.Member], embed: discord.Embed,
                     concurrency: int = 5, delay_ms: int = 250) -> Dict[str, Any]:
    stats = {"attempted": 0, "succeeded": 0, "failed": 0, "failures": []}
    queue = [m for m in members if not m.bot]

    async def worker():
        while queue:
            try:
                m = queue.pop(0)
            except IndexError:
                return
            stats["attempted"] += 1
            try:
                await m.send(embed=embed)
                stats["succeeded"] += 1
            except discord.Forbidden:
                stats["failed"] += 1
                stats["failures"].append({"id": str(m.id), "tag": str(m), "reason": "DMs disabled"})
            except Exception as err:
                stats["failed"] += 1
                stats["failures"].append({"id": str(m.id), "tag": str(m), "reason": str(err)})
            if delay_ms > 0:
                await asyncio.sleep(delay_ms / 1000)

    await asyncio.gather(*[worker() for _ in range(max(1, concurrency))])
    return stats


# ═════════════════════════ RECRUITMENT (STAFF APPLICATION) ═════════════════════════

# ── per-guild denied-user helpers ─────────────────────────────────────────────
def _recruit_denied_file():
    return "database/recruit_denied.json"

def _recruit_denied_load():
    import json
    try:
        with open(_recruit_denied_file(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _recruit_denied_save(data):
    import json, os
    os.makedirs("database", exist_ok=True)
    with open(_recruit_denied_file(), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def _recruit_is_denied(guild_id: str, user_id: str) -> bool:
    return str(user_id) in _recruit_denied_load().get(str(guild_id), [])

def _recruit_deny(guild_id: str, user_id: str):
    data = _recruit_denied_load()
    gid = str(guild_id)
    if gid not in data:
        data[gid] = []
    uid = str(user_id)
    if uid not in data[gid]:
        data[gid].append(uid)
    _recruit_denied_save(data)

def _recruit_clear_denied(guild_id: str):
    data = _recruit_denied_load()
    data.pop(str(guild_id), None)
    _recruit_denied_save(data)


def build_recruitment_embed(open_status: bool = True):
    status_line = "🟢 **Applications: OPEN**" if open_status else "🔴 **Applications: CLOSED**"
    e = discord.Embed(
        title="📋 Staff Application — Emergency Streets",
        description=(
            f"{status_line}\n\n"
            "**Interested in joining our support team?**\n\n"
            "We are looking for dedicated, reliable, and professional individuals "
            "to join **Emergency Streets** as **Community Support** staff.\n\n"
            "**What we expect:**\n"
            "• Professional and respectful communication\n"
            "• Sound judgment when handling reports, conflicts, and support tickets\n"
            "• Daily availability and commitment to the team\n\n"
            "Click **Apply Now** below to submit your application.\n"
            "Our **Community Support** team will review it and get back to you."
        ),
        color=BRAND["color"] if open_status else 0x6b7280,
    )
    e.set_footer(text="Emergency Streets • Community Support")
    return e


class RecruitmentView(discord.ui.View):
    def __init__(self, open_status: bool = True):
        super().__init__(timeout=None)

    @discord.ui.button(label="Apply Now", emoji="📝", style=discord.ButtonStyle.primary, custom_id="recruit:apply")
    async def apply(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not interaction.guild:
            return await interaction.response.send_message(
                embed=error_embed("Error", "Could not determine server."), ephemeral=True)
        cfg = get_guild(str(interaction.guild.id))
        if not cfg.get("recruitmentOpen", True):
            return await interaction.response.send_message(
                embed=error_embed("Applications Closed", "Applications are currently closed. Please check back later."),
                ephemeral=True,
            )
        if _recruit_is_denied(str(interaction.guild.id), str(interaction.user.id)):
            return await interaction.response.send_message(
                embed=error_embed("Application Denied", "Your previous application was denied. Please contact a staff member if you believe this is a mistake."),
                ephemeral=True,
            )
        await interaction.response.send_modal(StaffApplicationModal())


class StaffApplicationModal(discord.ui.Modal, title="Emergency Streets — Staff Application"):
    q1 = discord.ui.TextInput(
        label="Age | Timezone | Daily Availability",
        style=discord.TextStyle.paragraph,
        placeholder="e.g. 18 | IST (UTC+5:30) | Available 5-6 hours daily",
        max_length=200,
        required=True,
    )
    q2 = discord.ui.TextInput(
        label="Previous Experience",
        style=discord.TextStyle.paragraph,
        placeholder="Previous communities, servers, moderation, or support roles",
        max_length=500,
        required=True,
    )
    q3 = discord.ui.TextInput(
        label="Handling Difficult Members",
        style=discord.TextStyle.paragraph,
        placeholder="How would you handle a rude, toxic, or disruptive member?",
        max_length=500,
        required=True,
    )
    q4 = discord.ui.TextInput(
        label="Conflict Resolution",
        style=discord.TextStyle.paragraph,
        placeholder="Two members are in a serious dispute. What steps do you take?",
        max_length=500,
        required=True,
    )
    q5 = discord.ui.TextInput(
        label="Moderation Knowledge & Ticket Policy",
        style=discord.TextStyle.paragraph,
        placeholder="How do you document moderation actions and handle sensitive support tickets?",
        max_length=600,
        required=True,
    )

    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.guild:
            return
        cfg = get_guild(str(interaction.guild.id))
        dest = cfg.get("recruitmentLogChannelId")
        if not dest:
            await interaction.response.send_message(
                embed=error_embed("Recruitment not set up", "An admin needs to run `/recruitment setup` first."),
                ephemeral=True,
            )
            return
        ch = interaction.guild.get_channel(int(dest))
        if not isinstance(ch, discord.TextChannel):
            await interaction.response.send_message(
                embed=error_embed("Channel missing", "The configured application channel no longer exists."),
                ephemeral=True,
            )
            return

        e = brand_embed()
        e.title = "📋 New Staff Application"
        e.set_thumbnail(url=interaction.user.display_avatar.url)
        e.description = f"**Applicant:** <@{interaction.user.id}> (`{interaction.user}`)"
        e.add_field(name="🕐 Age | Timezone | Availability", value=self.q1.value, inline=False)
        e.add_field(name="📚 Previous Experience", value=self.q2.value, inline=False)
        e.add_field(name="😤 Handling Difficult Members", value=self.q3.value, inline=False)
        e.add_field(name="⚖️ Conflict Resolution", value=self.q4.value, inline=False)
        e.add_field(name="🔐 Moderation Knowledge & Ticket Policy", value=self.q5.value, inline=False)
        e.set_footer(text=f"User ID: {interaction.user.id}")

        accept_btn = discord.ui.Button(
            label="Accept", emoji="✅", style=discord.ButtonStyle.success,
            custom_id=f"recruit:accept:{interaction.user.id}",
        )
        reject_btn = discord.ui.Button(
            label="Reject", emoji="❌", style=discord.ButtonStyle.danger,
            custom_id=f"recruit:reject:{interaction.user.id}",
        )
        info_btn = discord.ui.Button(
            label="User Info", emoji="👤", style=discord.ButtonStyle.secondary,
            custom_id=f"recruit:userinfo:{interaction.user.id}",
        )
        view = discord.ui.View(timeout=None)
        view.add_item(accept_btn)
        view.add_item(reject_btn)
        view.add_item(info_btn)

        ping_str = f"<@&{APPLICATION_ACCEPT_ROLE_ID}>"
        await ch.send(
    content="<@&1363688232721584269>",
    embed=e,
    view=view
)
        await interaction.response.send_message(
            embed=success_embed("✅ Application submitted", "Thanks! Our Community Support team will review it soon."),
            ephemeral=True,
        )


class RejectReasonModal(discord.ui.Modal, title="Reject Application — Reason"):
    reason = discord.ui.TextInput(
        label="Reason for rejection",
        style=discord.TextStyle.paragraph,
        placeholder="Explain why this application is being rejected...",
        max_length=500,
        required=True,
    )

    def __init__(self, applicant_id: int, original_message: discord.Message):
        super().__init__()
        self.applicant_id = applicant_id
        self.original_message = original_message

    async def on_submit(self, interaction: discord.Interaction):
        reason_text = self.reason.value
        applicant = interaction.guild.get_member(self.applicant_id) if interaction.guild else None

        if applicant:
            try:
                rej_e = discord.Embed(
                    title="❌ Application Rejected",
                    description=(
                        "Thank you for applying to **Emergency Streets**. "
                        "Unfortunately your application was not successful at this time.\n\n"
                        f"**Reason:** {reason_text}"
                    ),
                    color=0xef4444,
                )
                rej_e.set_footer(text="Emergency Streets • Staff Recruitment")
                await applicant.send(embed=rej_e)
            except Exception:
                pass

        if interaction.guild:
            _recruit_deny(str(interaction.guild.id), str(self.applicant_id))

        try:
            orig_e = self.original_message.embeds[0] if self.original_message and self.original_message.embeds else None
            if orig_e:
                orig_e.color = discord.Color(0xef4444)
                reason_short = (reason_text[:77] + "...") if len(reason_text) > 80 else reason_text
                orig_e.set_footer(text=f"❌ Rejected by {interaction.user} • {reason_short}")
                disabled_view = discord.ui.View()
                await self.original_message.edit(embed=orig_e, view=disabled_view)
        except Exception:
            pass

        await interaction.response.send_message(
            embed=success_embed("❌ Rejected", f"<@{self.applicant_id}> has been rejected and notified via DM."),
            ephemeral=True,
        )


# ═════════════════════════ RECRUITMENT BUTTON HANDLER ═════════════════════════
@bot.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type != discord.InteractionType.component:
        return
    cid = interaction.data.get("custom_id", "")

    # ── recruit: buttons ──────────────────────────────────────────────────────
    if cid.startswith("recruit:"):
        parts = cid.split(":")
        action = parts[1] if len(parts) > 1 else ""

        if len(parts) < 3:
            return
        try:
            applicant_id = int(parts[2])
        except ValueError:
            return

        if action == "userinfo":
            guild = interaction.guild
            if not guild:
                return
            member = guild.get_member(applicant_id)
            if not member:
                try:
                    member = await guild.fetch_member(applicant_id)
                except Exception:
                    member = None
            e = brand_embed()
            e.title = f"👤 User Info — Applicant"
            if member:
                e.set_thumbnail(url=member.display_avatar.url)
                e.description = f"**{member}** (`{member.id}`)"
                e.add_field(name="🆔 ID", value=f"`{member.id}`", inline=True)
                e.add_field(name="🤖 Bot", value="Yes" if member.bot else "No", inline=True)
                e.add_field(name="📅 Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "—", inline=True)
                e.add_field(name="📅 Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
                roles = [f"<@&{r.id}>" for r in sorted([r for r in member.roles if r.id != guild.id], key=lambda x: -x.position)][:15]
                e.add_field(name=f"🎭 Roles ({len(member.roles)-1})", value=" ".join(roles) or "*(none)*", inline=False)
            else:
                e.description = f"Could not find member with ID `{applicant_id}` in this server."
            return await interaction.response.send_message(embed=e, ephemeral=True)

        if action == "accept":
            await interaction.response.defer(ephemeral=True)
            guild = interaction.guild
            if not guild:
                return

            applicant = guild.get_member(applicant_id)
            # Trail Staff role from config — assigned ONLY to the applicant
            trail_staff_role = guild.get_role(APPLICATION_ACCEPT_ROLE_ID)

            # Assign trail staff role to the applicant only
            if applicant and trail_staff_role:
                try:
                    await applicant.add_roles(
                        trail_staff_role,
                        reason="Staff application accepted",
                    )
                except Exception:
                    pass

            # Resolve category for the accepted channel
            cfg = get_guild(str(guild.id))
            category_id = cfg.get("recruitmentCategoryId")
            category = guild.get_channel(int(category_id)) if category_id else None
            if not isinstance(category, discord.CategoryChannel):
                category = None

            ticket_ch = None
            try:
                ch_name = (
                    f"accepted-{applicant.name.lower().replace(' ', '-')}"
                    if applicant else f"accepted-{applicant_id}"
                )

                # Create the channel under the category
                ticket_ch = await guild.create_text_channel(
                    ch_name,
                    category=category,
                    reason="Staff application accepted",
                )

                # Start from category perms (sync_permissions=True equivalent)
                await ticket_ch.edit(sync_permissions=True)

                # Deny trail staff role holders from viewing this channel
                # — so existing trail staff members cannot see accepted channels
                if trail_staff_role:
                    await ticket_ch.set_permissions(
                        trail_staff_role,
                        view_channel=False,
                        send_messages=False,
                    )

                # Give ONLY the applicant basic message perms
                if applicant:
                    await ticket_ch.set_permissions(
                        applicant,
                        view_channel=True,
                        send_messages=True,
                        read_message_history=True,
                        attach_files=False,
                        embed_links=False,
                        mention_everyone=False,
                    )

                close_btn = discord.ui.Button(
                    label="Close Channel",
                    emoji="🔒",
                    style=discord.ButtonStyle.danger,
                    custom_id=f"ticket:close:{ticket_ch.id}:{applicant_id}",
                )
                close_view = discord.ui.View(timeout=None)
                close_view.add_item(close_btn)

                # Ping applicant + moderator role
                mention_str = f"<@{applicant_id}> <@&1363688232721584269>"

                acc_e = discord.Embed(
                    title="✅ Application Accepted",
                    description=(
                        f"Congratulations <@{applicant_id}>! "
                        "Your staff application has been **accepted**.\n\n"
                        "You have been given the **Trail Staff** role.\n"
                        "A moderator will brief you on your duties shortly."
                    ),
                    color=0x9b59b6,
                )
                acc_e.set_footer(text="Emergency Streets • Staff Recruitment")

                await ticket_ch.send(
                    content=mention_str,
                    embed=acc_e,
                    view=close_view,
                )

                # Welcome / onboarding message
                try:
                    await ticket_ch.send(
                        "📌 **Welcome!** Kindly access the channel below, "
                        "read both threads, and once done ping a moderator.\n"
                        "🔗 https://discord.com/channels/"
                        "1363688232709263360/1440980081764864080"
                    )
                except Exception:
                    pass

            except Exception as err:
                await interaction.followup.send(
                    embed=error_embed("Channel creation failed", str(err)),
                    ephemeral=True,
                )
                return

            # Mark original application embed as accepted
            try:
                orig_e = (
                    interaction.message.embeds[0]
                    if interaction.message and interaction.message.embeds
                    else None
                )
                if orig_e:
                    orig_e.color = discord.Color(0x22c55e)
                    orig_e.set_footer(
                        text=f"✅ Accepted by {interaction.user} • Emergency Streets"
                    )
                    await interaction.message.edit(
                        embed=orig_e,
                        view=discord.ui.View(),
                    )
            except Exception:
                pass

            await interaction.followup.send(
                embed=success_embed(
                    "✅ Accepted",
                    f"<@{applicant_id}> has been accepted and given the Trail Staff role.\n"
                    f"Channel: <#{ticket_ch.id}>" if ticket_ch else f"<@{applicant_id}> has been accepted.",
                ),
                ephemeral=True,
            )

        elif action == "reject":
            if not interaction.message:
                return
            await interaction.response.send_modal(
                RejectReasonModal(
                    applicant_id=applicant_id,
                    original_message=interaction.message,
                )
            )

    # ── ticket: close channel button (staff OR the applicant) ────────────────
    elif cid.startswith("ticket:close:"):
        parts = cid.split(":")
        # custom_id format: "ticket:close:{channel_id}:{applicant_id}"
        try:
            channel_id = int(parts[2])
            applicant_id = int(parts[3]) if len(parts) > 3 else 0
        except (ValueError, IndexError):
            await interaction.response.send_message(
                embed=error_embed("Error", "Invalid close button data."), ephemeral=True
            )
            return

        guild = interaction.guild
        if not guild or not isinstance(interaction.user, discord.Member):
            return

        is_applicant = applicant_id and interaction.user.id == applicant_id
        if not is_applicant and not _store_is_staff(str(guild.id), interaction.user):
            await interaction.response.send_message(
                embed=error_embed("No permission", "Only staff members or the applicant can close this ticket."),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        ch = guild.get_channel(channel_id)
        if not isinstance(ch, discord.TextChannel):
            await interaction.followup.send(
                embed=error_embed("Already closed", "This channel no longer exists."),
                ephemeral=True,
            )
            return

        # Lock the channel — deny send_messages for @everyone and the applicant
        try:
            await ch.set_permissions(guild.default_role, send_messages=False)
            applicant = guild.get_member(applicant_id) if applicant_id else None
            if applicant:
                await ch.set_permissions(
                    applicant,
                    view_channel=True,
                    send_messages=False,
                    read_message_history=True,
                )
        except Exception:
            pass

        # Build closed embed with Reopen + Delete buttons (staff only)
        reopen_btn = discord.ui.Button(
            label="Reopen",
            emoji="🔓",
            style=discord.ButtonStyle.success,
            custom_id=f"ticket:reopen:{channel_id}:{applicant_id}",
        )
        delete_btn = discord.ui.Button(
            label="Delete",
            emoji="🗑️",
            style=discord.ButtonStyle.danger,
            custom_id=f"ticket:delete:{channel_id}:{applicant_id}",
        )
        closed_view = discord.ui.View(timeout=None)
        closed_view.add_item(reopen_btn)
        closed_view.add_item(delete_btn)

        closed_e = discord.Embed(
            title="🔒 Ticket Closed",
            description=(
                f"This ticket has been closed by {interaction.user.mention}.\n\n"
                "**Staff:** Use the buttons below to reopen or permanently delete this ticket."
            ),
            color=0xef4444,
        )
        closed_e.set_footer(text="Emergency Streets • Staff Recruitment")

        # Disable the original Close button on the accepted embed
        try:
            if interaction.message:
                disabled_view = discord.ui.View(timeout=None)
                closed_label = discord.ui.Button(
                    label="Closed",
                    emoji="🔒",
                    style=discord.ButtonStyle.secondary,
                    disabled=True,
                    custom_id="ticket:closed_label",
                )
                disabled_view.add_item(closed_label)
                await interaction.message.edit(view=disabled_view)
        except Exception:
            pass

        try:
            await ch.send(embed=closed_e, view=closed_view)
        except Exception:
            pass

        await interaction.followup.send(
            embed=success_embed("🔒 Ticket closed", "The ticket is now locked. Staff can reopen or delete it."),
            ephemeral=True,
        )

    # ── ticket: reopen channel button (staff only) ────────────────────────────
    elif cid.startswith("ticket:reopen:"):
        parts = cid.split(":")
        try:
            channel_id = int(parts[2])
            applicant_id = int(parts[3]) if len(parts) > 3 else 0
        except (ValueError, IndexError):
            await interaction.response.send_message(
                embed=error_embed("Error", "Invalid reopen button data."), ephemeral=True
            )
            return

        guild = interaction.guild
        if not guild or not isinstance(interaction.user, discord.Member):
            return

        if not _store_is_staff(str(guild.id), interaction.user):
            await interaction.response.send_message(
                embed=error_embed("No permission", "Only staff members can reopen tickets."),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        ch = guild.get_channel(channel_id)
        if not isinstance(ch, discord.TextChannel):
            await interaction.followup.send(
                embed=error_embed("Not found", "This channel no longer exists."),
                ephemeral=True,
            )
            return

        # Restore applicant send permissions
        try:
            applicant = guild.get_member(applicant_id) if applicant_id else None
            if applicant:
                await ch.set_permissions(
                    applicant,
                    view_channel=True,
                    send_messages=True,
                    read_message_history=True,
                    attach_files=False,
                    embed_links=False,
                    mention_everyone=False,
                )
        except Exception:
            pass

        # Disable Reopen + Delete buttons on the closed embed
        try:
            if interaction.message:
                await interaction.message.edit(view=discord.ui.View(timeout=None))
        except Exception:
            pass

        # Send reopen notice with a fresh Close button
        close_btn = discord.ui.Button(
            label="Close Channel",
            emoji="🔒",
            style=discord.ButtonStyle.danger,
            custom_id=f"ticket:close:{channel_id}:{applicant_id}",
        )
        reopen_view = discord.ui.View(timeout=None)
        reopen_view.add_item(close_btn)

        reopen_e = discord.Embed(
            title="🔓 Ticket Reopened",
            description=f"This ticket has been reopened by {interaction.user.mention}.",
            color=0x22c55e,
        )
        reopen_e.set_footer(text="Emergency Streets • Staff Recruitment")

        try:
            await ch.send(embed=reopen_e, view=reopen_view)
        except Exception:
            pass

        await interaction.followup.send(
            embed=success_embed("🔓 Ticket reopened", "The ticket has been unlocked."),
            ephemeral=True,
        )

    # ── ticket: delete channel button (staff only) ────────────────────────────
    elif cid.startswith("ticket:delete:"):
        parts = cid.split(":")
        try:
            channel_id = int(parts[2])
        except (ValueError, IndexError):
            await interaction.response.send_message(
                embed=error_embed("Error", "Invalid delete button data."), ephemeral=True
            )
            return

        guild = interaction.guild
        if not guild or not isinstance(interaction.user, discord.Member):
            return

        if not _store_is_staff(str(guild.id), interaction.user):
            await interaction.response.send_message(
                embed=error_embed("No permission", "Only staff members can delete tickets."),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        ch = guild.get_channel(channel_id)
        if not isinstance(ch, discord.TextChannel):
            await interaction.followup.send(
                embed=error_embed("Not found", "This channel no longer exists."),
                ephemeral=True,
            )
            return

        try:
            deleting_e = discord.Embed(
                title="🗑️ Ticket Deleting",
                description=f"This channel is being permanently deleted by {interaction.user.mention}.",
                color=0xef4444,
            )
            deleting_e.set_footer(text="Emergency Streets • Staff Recruitment")
            await ch.send(embed=deleting_e)
        except Exception:
            pass

        try:
            await ch.delete(reason=f"Ticket deleted by {interaction.user} ({interaction.user.id})")
        except Exception as err:
            await interaction.followup.send(
                embed=error_embed("Failed to delete channel", str(err)),
                ephemeral=True,
            )

# ═════════════════════════ ANTINUKE ═════════════════════════
_buckets: Dict[str, Dict[str, float]] = {}


def bump_bucket(key: str, window_ms: int) -> int:
    now = time.time() * 1000
    cur = _buckets.get(key)
    if not cur or cur["resetAt"] < now:
        _buckets[key] = {"count": 1, "resetAt": now + window_ms}
        return 1
    cur["count"] += 1
    return int(cur["count"])


async def fetch_executor(guild: discord.Guild, action: discord.AuditLogAction, target_id: Optional[int] = None):
    try:
        async for entry in guild.audit_logs(limit=5, action=action):
            if target_id is None or (entry.target and getattr(entry.target, "id", None) == target_id):
                if (time.time() - entry.created_at.timestamp()) < 5:
                    return entry.user
    except Exception:
        pass
    return None


async def antinuke_punish(guild: discord.Guild, executor: discord.Member, punishment: str, cfg: dict, reason: str):
    if not executor or executor.bot or executor.id == guild.owner_id:
        return
    wl = cfg.get("antinukeWhitelist") or []
    if str(executor.id) in wl:
        return
    wl_roles = cfg.get("antinukeWhitelistRoles") or []
    if wl_roles and any(str(r.id) in wl_roles for r in getattr(executor, "roles", [])):
        return
    log_id = cfg.get("antinukeLogChannelId")
    log_ch = guild.get_channel(int(log_id)) if log_id else None

    async def _log(msg: str):
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=warn_embed("🛡️ Antinuke Triggered", msg))
            except Exception:
                pass

    try:
        if punishment == "ban":
            await guild.ban(executor, reason=f"[Emergency Streets Antinuke] {reason}")
            await _log(f"**Banned** <@{executor.id}> — {reason}")
        elif punishment == "kick":
            await guild.kick(executor, reason=f"[Emergency Streets Antinuke] {reason}")
            await _log(f"**Kicked** <@{executor.id}> — {reason}")
        elif punishment == "strip":
            dangerous = [r for r in executor.roles if r.permissions.administrator or r.permissions.manage_guild]
            if dangerous:
                await executor.remove_roles(*dangerous, reason=f"[Emergency Streets Antinuke] {reason}")
            await _log(f"**Stripped roles** from <@{executor.id}> — {reason}")
        elif punishment == "quarantine":
            qr_id = cfg.get("antinukeQuarantineRoleId")
            if qr_id:
                qr = guild.get_role(int(qr_id))
                if qr:
                    # Remove ALL roles below bot's top role (skip only @everyone)
                    roles_to_remove = [
                        r for r in executor.roles
                        if r != guild.default_role and guild.me.top_role > r and r.id != qr.id
                    ]
                    for r in roles_to_remove:
                        try:
                            await executor.remove_roles(
                                r,
                                reason=f"[Emergency Streets Antinuke] Quarantine strip — {reason}",
                            )
                        except Exception:
                            pass
                    await executor.add_roles(qr, reason=f"[Emergency Streets Antinuke] {reason}")
                    await _log(f"**Quarantined** <@{executor.id}> (all roles stripped) — {reason}")
    except Exception as err:
        await _log(f"Failed to punish <@{executor.id}>: {err}")


# ═════════════════════════ INVITES ═════════════════════════
_invite_cache: Dict[str, Dict[str, int]] = {}


def get_invite_counts(guild_id: str, user_id: str) -> Dict[str, Any]:
    cfg = get_guild(guild_id)
    counts = (cfg.get("inviteCounts") or {}).get(user_id) or {}
    regular = counts.get("regular", 0)
    left = counts.get("left", 0)
    fake = counts.get("fake", 0)
    bonus = counts.get("bonus", 0)
    return {"regular": regular, "left": left, "fake": fake, "bonus": bonus, "total": regular - left + bonus}


def add_bonus_invites(guild_id: str, user_id: str, amount: int) -> int:
    cfg = get_guild(guild_id)
    cfg.setdefault("inviteCounts", {}).setdefault(user_id, {"regular": 0, "left": 0, "fake": 0, "bonus": 0})
    cfg["inviteCounts"][user_id]["bonus"] = cfg["inviteCounts"][user_id].get("bonus", 0) + amount
    persist()
    return cfg["inviteCounts"][user_id]["bonus"]


# ═════════════════════════ AUTOMOD ═════════════════════════
_spam_tracker: Dict[str, Dict[str, Any]] = {}
_INVITE_RE = re.compile(r"discord(?:\.gg|app\.com/invite|\.com/invite)/\S+", re.IGNORECASE)
_LINK_RE = re.compile(r"https?://\S+", re.IGNORECASE)


async def automod_punish(message: discord.Message, reason: str):
    import datetime
    blocked_content = (message.content or "")[:200]

    # ── delete the offending message ──────────────────────────────────────────
    try:
        await message.delete()
    except Exception:
        pass

    # ── DM the user so they know why their message was removed ────────────────
    try:
        dm_e = discord.Embed(
            title="🚫 Your message was removed",
            description=(
                f"**Server:** {message.guild.name}\n"
                f"**Channel:** <#{message.channel.id}>\n"
                f"**Rule:** {reason}\n\n"
                "Please review the server rules and avoid sending flagged content."
            ),
            color=0xFF4444)
        dm_e.set_footer(text="This is an automated AutoMod action.")
        await message.author.send(embed=dm_e)
    except Exception:
        pass

    # ── log to the configured log channel ────────────────────────────────────
    cfg = get_guild(str(message.guild.id))
    log_id = cfg.get("logChannelId")
    if log_id and is_log_event_enabled(str(message.guild.id), "automod"):
        ch = message.guild.get_channel(int(log_id))
        if isinstance(ch, discord.TextChannel):
            log_e = discord.Embed(title="🤖 AutoMod — Message Blocked", color=0xFF6600)
            log_e.add_field(name="👤 User", value=f"<@{message.author.id}> `{message.author}` (`{message.author.id}`)", inline=False)
            log_e.add_field(name="📌 Channel", value=f"<#{message.channel.id}>", inline=True)
            log_e.add_field(name="⚠️ Rule", value=reason, inline=True)
            if blocked_content:
                log_snippet = blocked_content[:500].replace("`", "")
                log_e.add_field(name="🚫 Removed Content", value=f"```{log_snippet}```", inline=False)
            log_e.set_footer(text=f"Action: Message Deleted  •  User ID: {message.author.id}")
            log_e.timestamp = datetime.datetime.now(datetime.timezone.utc)
            try:
                await ch.send(embed=log_e)
            except Exception:
                pass


# ═════════════════════════ EVENTS ═════════════════════════
# ═════════════════════════ ERROR HANDLERS ═════════════════════════
@bot.event
async def on_command_error(ctx, error):
    """Silently ignore unknown prefix commands; let everything else propagate."""
    from discord.ext.commands import (
        CommandNotFound, CheckFailure, MissingRequiredArgument, BadArgument,
        CommandOnCooldown,
    )
    if isinstance(error, CommandNotFound):
        return  # unknown prefix command — do nothing
    if isinstance(error, CheckFailure):
        return  # permission denied already handled inside the command
    if isinstance(error, CommandOnCooldown):
        try:
            await ctx.reply(
                embed=error_embed(
                    "Slow down",
                    f"This command is on cooldown. Try again in **{error.retry_after:.1f}s**.",
                ),
                delete_after=6,
            )
        except Exception:
            pass
        return
    if isinstance(error, (MissingRequiredArgument, BadArgument)):
        # Show a brief usage hint but don't crash
        try:
            await ctx.reply(embed=error_embed("Missing argument", f"Usage: `{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}`"), delete_after=10)
        except Exception:
            pass
        return
    # Swallow 429 / generic HTTPException so a transient global rate-limit
    # doesn't spam the log with thousands of stack traces (the original
    # symptom that prompted this fix).
    original = getattr(error, "original", error)
    if isinstance(original, discord.HTTPException) and getattr(original, "status", None) == 429:
        print(f"[bot] 429 hit on prefix command {getattr(ctx.command, 'qualified_name', '?')} — backing off")
        return
    # For everything else let discord.py log it normally
    raise error


@bot.tree.error
async def on_app_command_error(inter: discord.Interaction, error: discord.app_commands.AppCommandError):
    """Silently swallow CheckFailure — the check already sent a response to the user."""
    from discord.app_commands.errors import CheckFailure as AppCheckFailure, CommandOnCooldown as AppCommandOnCooldown
    if isinstance(error, AppCheckFailure):
        return  # check function already replied to the user
    if isinstance(error, AppCommandOnCooldown):
        try:
            if inter.response.is_done():
                await inter.followup.send(
                    embed=error_embed("Slow down", f"Try again in **{error.retry_after:.1f}s**."),
                    ephemeral=True,
                )
            else:
                await inter.response.send_message(
                    embed=error_embed("Slow down", f"Try again in **{error.retry_after:.1f}s**."),
                    ephemeral=True,
                )
        except Exception:
            pass
        return
    original = getattr(error, "original", error)
    if isinstance(original, discord.HTTPException) and getattr(original, "status", None) == 429:
        print(f"[bot] 429 on slash command {getattr(inter.command, 'qualified_name', '?')} — backing off")
        return
    # For other slash command errors, try to inform the user
    msg = str(original)
    try:
        if inter.response.is_done():
            await inter.followup.send(embed=error_embed("Command error", msg[:200]), ephemeral=True)
        else:
            await inter.response.send_message(embed=error_embed("Command error", msg[:200]), ephemeral=True)
    except Exception:
        pass


@bot.event
async def on_ready():
    print(f"[bot] Logged in as {bot.user} ({bot.user.id})")

    # The duplicate rotate_activity loop is disabled — cogs/status_cog.py
    # owns presence rotation safely (one update per few minutes).
    # If you want this secondary rotator instead, uncomment the next 2 lines
    # AND disable cogs.status_cog in NEW_COGS to avoid hitting the 5/min
    # presence update limit.
    # if not rotate_activity.is_running():
    #     rotate_activity.start()

    # ── Slash command sync ────────────────────────────────────────────────
    # `tree.sync()` is HEAVILY rate-limited. Previously this ran on every
    # `on_ready` (which fires on every reconnect) AND once per guild with a
    # `clear_commands` + `sync(guild=...)` cycle. With even a single reconnect
    # storm, this alone could trigger a global 429 and break the entire bot.
    # We now sync at most once per process.
    if not getattr(bot, "_synced_once", False):
        try:
            synced = await bot.tree.sync()
            print(f"[bot] Synced {len(synced)} slash commands globally")
        except Exception as e:
            print(f"[bot] Sync failed: {e}")
        bot._synced_once = True  # type: ignore[attr-defined]

    for guild in bot.guilds:
        try:
            invites = await guild.fetch_invites()
            _invite_cache[str(guild.id)] = {inv.code: inv.uses for inv in invites}
        except Exception:
            pass


@bot.event
async def on_guild_join(guild: discord.Guild):
    try:
        invites = await guild.fetch_invites()
        _invite_cache[str(guild.id)] = {inv.code: inv.uses for inv in invites}
    except Exception:
        pass


@bot.event
async def on_invite_create(invite: discord.Invite):
    if invite.guild:
        _invite_cache.setdefault(str(invite.guild.id), {})[invite.code] = invite.uses or 0


@bot.event
async def on_invite_delete(invite: discord.Invite):
    if invite.guild:
        _invite_cache.get(str(invite.guild.id), {}).pop(invite.code, None)


@bot.event
async def on_member_join(member: discord.Member):
    cfg = get_guild(str(member.guild.id))

    try:
        new_invites = await member.guild.fetch_invites()
        old = _invite_cache.get(str(member.guild.id), {})
        for inv in new_invites:
            if old.get(inv.code, 0) < (inv.uses or 0):
                if inv.inviter:
                    uid = str(inv.inviter.id)
                    cfg.setdefault("inviteCounts", {}).setdefault(uid, {"regular": 0, "left": 0, "fake": 0, "bonus": 0})
                    cfg["inviteCounts"][uid]["regular"] = cfg["inviteCounts"][uid].get("regular", 0) + 1
                    persist()
                break
        _invite_cache[str(member.guild.id)] = {inv.code: inv.uses for inv in new_invites}
    except Exception:
        pass

    if is_log_event_enabled(str(member.guild.id), "memberJoin"):
        log_ch = member.guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            e = info_embed("📥 Member Joined", f"<@{member.id}> (`{member}`)\nID: `{member.id}`\nAccount: <t:{int(member.created_at.timestamp())}:R>")
            e.set_thumbnail(url=member.display_avatar.url)
            try:
                await log_ch.send(embed=e)
            except Exception:
                pass


@bot.event
async def on_member_remove(member: discord.Member):
    cfg = get_guild(str(member.guild.id))
    if is_log_event_enabled(str(member.guild.id), "memberLeave"):
        log_ch = member.guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=info_embed("📤 Member Left", f"<@{member.id}> (`{member}`)\nID: `{member.id}`"))
            except Exception:
                pass


@bot.event
async def on_member_ban(guild: discord.Guild, user: discord.User):
    cfg = get_guild(str(guild.id))
    if cfg.get("antinukeEnabled"):
        rule = get_antinuke_rule(str(guild.id), "ban")
        if rule["enabled"]:
            executor = await fetch_executor(guild, discord.AuditLogAction.ban, user.id)
            if executor:
                count = bump_bucket(f"ban:{guild.id}:{executor.id}", rule["windowMs"])
                if count >= rule["threshold"]:
                    await antinuke_punish(guild, executor, rule["punishment"], cfg, f"Mass ban ({count})")
    if is_log_event_enabled(str(guild.id), "memberBan"):
        log_ch = guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=warn_embed("🔨 Member Banned", f"<@{user.id}> (`{user}`)\nID: `{user.id}`"))
            except Exception:
                pass


@bot.event
async def on_member_unban(guild: discord.Guild, user: discord.User):
    if is_log_event_enabled(str(guild.id), "memberUnban"):
        cfg = get_guild(str(guild.id))
        log_ch = guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=success_embed("♻️ Member Unbanned", f"<@{user.id}> (`{user}`)\nID: `{user.id}`"))
            except Exception:
                pass


@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    """Strip all roles when a member receives the quarantine role."""
    cfg = get_guild(str(after.guild.id))
    qr_id = cfg.get("antinukeQuarantineRoleId")
    if not qr_id:
        return
    try:
        qr_id_int = int(qr_id)
    except (ValueError, TypeError):
        return

    before_role_ids = {r.id for r in before.roles}
    after_role_ids = {r.id for r in after.roles}

    # Check if quarantine role was just added
    if qr_id_int in after_role_ids and qr_id_int not in before_role_ids:
        roles_to_remove = [
            r for r in after.roles
            if r.id != qr_id_int and r != after.guild.default_role and after.guild.me.top_role > r
        ]
        for r in roles_to_remove:
            try:
                await after.remove_roles(
                    r,
                    reason="[Emergency Streets Antinuke] Quarantine — all roles stripped",
                )
            except Exception:
                pass

        log_ch_id = cfg.get("antinukeLogChannelId") or cfg.get("logChannelId")
        if log_ch_id:
            log_ch = after.guild.get_channel(int(log_ch_id))
            if isinstance(log_ch, discord.TextChannel):
                try:
                    await log_ch.send(embed=warn_embed(
                        "🔒 Member Quarantined",
                        f"<@{after.id}> was given the quarantine role — all other roles have been stripped.",
                    ))
                except Exception:
                    pass


@bot.event
async def on_message_delete(message: discord.Message):
    if not message.guild or message.author.bot:
        return
    if is_log_event_enabled(str(message.guild.id), "messageDelete"):
        cfg = get_guild(str(message.guild.id))
        log_ch = message.guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            e = info_embed("🗑️ Message Deleted", f"**Author:** <@{message.author.id}>\n**Channel:** <#{message.channel.id}>")
            if message.content:
                e.add_field(name="Content", value=message.content[:1000], inline=False)
            try:
                await log_ch.send(embed=e)
            except Exception:
                pass


@bot.event
async def on_message_edit(before: discord.Message, after: discord.Message):
    if not before.guild or before.author.bot or before.content == after.content:
        return
    if is_log_event_enabled(str(before.guild.id), "messageEdit"):
        cfg = get_guild(str(before.guild.id))
        log_ch = before.guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            e = info_embed("✏️ Message Edited", f"**Author:** <@{before.author.id}>\n**Channel:** <#{before.channel.id}>")
            e.add_field(name="Before", value=(before.content or "*(empty)*")[:500], inline=False)
            e.add_field(name="After", value=(after.content or "*(empty)*")[:500], inline=False)
            try:
                await log_ch.send(embed=e)
            except Exception:
                pass


@bot.event
async def on_guild_channel_create(channel):
    if not channel.guild:
        return
    cfg = get_guild(str(channel.guild.id))
    if cfg.get("antinukeEnabled"):
        rule = get_antinuke_rule(str(channel.guild.id), "channelCreate")
        if rule["enabled"]:
            executor = await fetch_executor(channel.guild, discord.AuditLogAction.channel_create)
            if executor:
                count = bump_bucket(f"channelCreate:{channel.guild.id}:{executor.id}", rule["windowMs"])
                if count >= rule["threshold"]:
                    await antinuke_punish(channel.guild, executor, rule["punishment"], cfg, f"Channel create spam ({count})")
    if is_log_event_enabled(str(channel.guild.id), "channelCreate"):
        log_ch = channel.guild.get_channel(int(cfg.get("logChannelId") or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=info_embed("🆕 Channel Created", f"**Name:** {channel.name}\n**ID:** `{channel.id}`"))
            except Exception:
                pass


@bot.event
async def on_guild_channel_delete(channel):
    if not channel.guild:
        return
    cfg = get_guild(str(channel.guild.id))
    if cfg.get("antinukeEnabled"):
        rule = get_antinuke_rule(str(channel.guild.id), "channelDelete")
        if rule["enabled"]:
            executor = await fetch_executor(channel.guild, discord.AuditLogAction.channel_delete)
            if executor:
                count = bump_bucket(f"channelDelete:{channel.guild.id}:{executor.id}", rule["windowMs"])
                if count >= rule["threshold"]:
                    await antinuke_punish(channel.guild, executor, rule["punishment"], cfg, f"Channel delete spam ({count})")
    if is_log_event_enabled(str(channel.guild.id), "channelDelete"):
        log_ch = channel.guild.get_channel(int(cfg.get("logChannelId", 0) or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=warn_embed("❌ Channel Deleted", f"**Name:** {channel.name}\n**ID:** `{channel.id}`"))
            except Exception:
                pass


@bot.event
async def on_guild_role_create(role: discord.Role):
    cfg = get_guild(str(role.guild.id))
    if cfg.get("antinukeEnabled"):
        rule = get_antinuke_rule(str(role.guild.id), "roleCreate")
        if rule["enabled"]:
            executor = await fetch_executor(role.guild, discord.AuditLogAction.role_create)
            if executor:
                count = bump_bucket(f"roleCreate:{role.guild.id}:{executor.id}", rule["windowMs"])
                if count >= rule["threshold"]:
                    await antinuke_punish(role.guild, executor, rule["punishment"], cfg, f"Role create spam ({count})")
    if is_log_event_enabled(str(role.guild.id), "roleCreate"):
        log_ch = role.guild.get_channel(int(cfg.get("logChannelId", 0) or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=info_embed("🎭 Role Created", f"**Name:** {role.name}\n**ID:** `{role.id}`"))
            except Exception:
                pass


@bot.event
async def on_guild_role_delete(role: discord.Role):
    cfg = get_guild(str(role.guild.id))
    if cfg.get("antinukeEnabled"):
        rule = get_antinuke_rule(str(role.guild.id), "roleDelete")
        if rule["enabled"]:
            executor = await fetch_executor(role.guild, discord.AuditLogAction.role_delete)
            if executor:
                count = bump_bucket(f"roleDelete:{role.guild.id}:{executor.id}", rule["windowMs"])
                if count >= rule["threshold"]:
                    await antinuke_punish(role.guild, executor, rule["punishment"], cfg, f"Role delete spam ({count})")
    if is_log_event_enabled(str(role.guild.id), "roleDelete"):
        log_ch = role.guild.get_channel(int(cfg.get("logChannelId", 0) or 0))
        if isinstance(log_ch, discord.TextChannel):
            try:
                await log_ch.send(embed=warn_embed("🗯️ Role Deleted", f"**Name:** {role.name}\n**ID:** `{role.id}`"))
            except Exception:
                pass


@bot.event
async def on_voice_state_update(member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
    cfg = get_guild(str(member.guild.id))
    if not cfg.get("logChannelId"):
        return
    log_ch = member.guild.get_channel(int(cfg.get("logChannelId") or 0))
    if not isinstance(log_ch, discord.TextChannel):
        return
    if not before.channel and after.channel:
        if is_log_event_enabled(str(member.guild.id), "voiceJoin"):
            try:
                await log_ch.send(embed=info_embed("🔊 Voice Join", f"<@{member.id}> joined <#{after.channel.id}>"))
            except Exception:
                pass
    elif before.channel and not after.channel:
        if is_log_event_enabled(str(member.guild.id), "voiceLeave"):
            try:
                await log_ch.send(embed=info_embed("🔇 Voice Leave", f"<@{member.id}> left <#{before.channel.id}>"))
            except Exception:
                pass
    elif before.channel and after.channel and before.channel.id != after.channel.id:
        if is_log_event_enabled(str(member.guild.id), "voiceMove"):
            try:
                await log_ch.send(embed=info_embed("🔁 Voice Move", f"<@{member.id}>: <#{before.channel.id}> → <#{after.channel.id}>"))
            except Exception:
                pass


@bot.event
async def on_message(message: discord.Message):
    if not message.guild or message.author.bot:
        await bot.process_commands(message)
        return

    try:
        cfg_raw = get_automod(str(message.guild.id))
        # Automod is active if master switch ON or any individual filter is configured
        _automod_active = (
            cfg_raw["enabled"]
            or cfg_raw.get("antiInvite")
            or cfg_raw.get("antiLink")
            or (cfg_raw.get("antiMassMention") or {}).get("enabled")
            or (cfg_raw.get("antiSpam") or {}).get("enabled")
            or (cfg_raw.get("antiCaps") or {}).get("enabled")
            or bool(cfg_raw.get("badWords"))
        )
        if _automod_active:
            ignored_channels = cfg_raw.get("ignoredChannels") or []
            ignored_roles = cfg_raw.get("ignoredRoles") or []
            member_role_ids = {str(r.id) for r in getattr(message.author, "roles", [])}

            if str(message.channel.id) not in ignored_channels and not any(r in member_role_ids for r in ignored_roles):
                handled = False
                if cfg_raw["antiInvite"] and _INVITE_RE.search(message.content):
                    await automod_punish(message, "Discord invite link not allowed")
                    handled = True
                if not handled and cfg_raw["antiLink"] and _LINK_RE.search(message.content):
                    await automod_punish(message, "External links not allowed")
                    handled = True
                if not handled and cfg_raw["antiMassMention"]["enabled"]:
                    mentions = len(message.mentions) + len(message.role_mentions)
                    if mentions > cfg_raw["antiMassMention"]["max"]:
                        await automod_punish(message, f"Mass mention ({mentions})")
                        handled = True
                if not handled and cfg_raw["antiCaps"]["enabled"]:
                    text = message.content
                    if len(text) >= cfg_raw["antiCaps"]["minLength"]:
                        caps = sum(1 for c in text if c.isupper())
                        if len(text) > 0 and (caps / len(text)) * 100 >= cfg_raw["antiCaps"]["percent"]:
                            await automod_punish(message, f"Excessive caps ({int(caps/len(text)*100)}%)")
                            handled = True
                if not handled and cfg_raw.get("badWords"):
                    lower = message.content.lower()
                    hit = next((w for w in cfg_raw["badWords"] if w and w.lower() in lower), None)
                    if hit:
                        await automod_punish(message, f"Filtered word: `{hit}`")
                        handled = True
                if not handled and cfg_raw["antiSpam"]["enabled"]:
                    key = f"{message.guild.id}:{message.author.id}"
                    now = time.time() * 1000
                    t = _spam_tracker.get(key)
                    if not t or now - t["first"] > cfg_raw["antiSpam"]["windowMs"]:
                        _spam_tracker[key] = {"count": 1, "first": now}
                    else:
                        t["count"] += 1
                        if t["count"] > cfg_raw["antiSpam"]["max"]:
                            await automod_punish(message, f"Spam ({int(t['count'])} msgs in {cfg_raw['antiSpam']['windowMs']}ms)")
                            _spam_tracker[key] = {"count": 0, "first": now}
    except discord.HTTPException as http_err:
        # Swallow 429 / transient HTTP errors so on_message never spams the log.
        if getattr(http_err, "status", None) == 429:
            print(f"[bot] 429 in on_message automod — skipping this message")
        else:
            print(f"[bot] HTTP error in on_message automod: {http_err}")
    except Exception as ex:
        print(f"[bot] unexpected error in on_message automod: {ex}")

    try:
        await bot.process_commands(message)
    except discord.HTTPException as http_err:
        if getattr(http_err, "status", None) == 429:
            print(f"[bot] 429 in process_commands — skipping")
        else:
            print(f"[bot] HTTP error in process_commands: {http_err}")


# ═════════════════════════ COMMAND LOADER ═════════════════════════
NEW_COGS = [
    "cogs.giveaway",
    "cogs.stats",
    "cogs.afk",
    "cogs.pingwarn",
    "cogs.autoreact",
    "cogs.remind",
    "cogs.ping_cog",
    "cogs.say_cog",
    "cogs.staffaccess",
    "cogs.embed",
    "cogs.status_cog",
    "cogs.calculator",
    "cogs.autoresponder",
    "cogs.tickets",
    # ── NEW premium cogs ──────────────────────────────
    "cogs.moderation",       # /warn /ban /kick /mute /purge /case /modstats …
    "cogs.ticket_extras",    # /ticketrate /ticketpriority /ticketreopen …
]


async def setup_hook():
    from cogs import register_all
    await register_all(bot)
    bot.add_view(RecruitmentView())

    import os
    os.makedirs("data", exist_ok=True)
    os.makedirs("assets", exist_ok=True)
    os.makedirs("database", exist_ok=True)

    for ext in NEW_COGS:
        try:
            await bot.load_extension(ext)
            print(f"[bot] loaded {ext}")
        except Exception as e:
            print(f"[bot] failed to load {ext}: {e}")


bot.setup_hook = setup_hook


print(f"[bot] booting Emergency Streets bot...")

if __name__ == "__main__":
    bot.run(TOKEN)
