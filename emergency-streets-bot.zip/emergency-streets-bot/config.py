"""Bot configuration"""
import os
import sys
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")
CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "")

if not TOKEN:
    print("[fatal] DISCORD_BOT_TOKEN env var is not set.")
    sys.exit(1)

_raw_owners = os.environ.get("DISCORD_OWNER_IDS", "")
OWNER_IDS: set[int] = {int(x.strip()) for x in _raw_owners.split(",") if x.strip().isdigit()}
OWNER_IDS |= {1424536373221920891, 1489089980818133154}

BRAND = {
    "name": "Emergency Streets",
    "tag": "Emergency Streets",
    "color": 0x9b59b6,
    "successColor": 0x22c55e,
    "warnColor": 0xf59e0b,
    "errorColor": 0xef4444,
    "infoColor": 0x9b59b6,
    "footer": "Emergency Streets • Bot",
}

APPLICATION_ACCEPT_ROLE_ID = 1363688232721584267

ACTIVITY_ROTATION = [
    {"name": "💥 Managing Emergency Streets", "type": 0},
    {"name": "🎭 Managing roles", "type": 3},
    {"name": "🛡️ Managing antinuke", "type": 3},
    {"name": "👥 Managing members", "type": 3},
]

ACTIVITY_INTERVAL_S = 20

DEFAULT_PREFIX = "!"
MAX_PREFIX_LENGTH = 5
