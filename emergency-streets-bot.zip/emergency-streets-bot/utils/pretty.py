"""
Pretty embed / view helpers — premium look-and-feel used across new cogs.

Keeps the same brand colours from config.BRAND but adds:
    • standardised header styling
    • rich footers with timestamp
    • paginator for long lists
    • confirmation buttons

These are pure helpers — safe to import from any cog without side-effects.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable, Iterable, List, Optional, Sequence

import discord

# Local brand — mirrors config.BRAND so this module can be imported
# even in isolated tests without .env.
BRAND_NAME    = "Emergency Streets"
BRAND_COLOR   = 0x9b59b6
SUCCESS_COLOR = 0x22c55e
WARN_COLOR    = 0xf59e0b
ERROR_COLOR   = 0xef4444
INFO_COLOR    = 0x3b82f6
GRAY_COLOR    = 0x64748b


# ────────────────────────────────────────────────────────────────────
# Embeds
# ────────────────────────────────────────────────────────────────────
def _base(color: int, title: Optional[str] = None,
          description: Optional[str] = None) -> discord.Embed:
    e = discord.Embed(color=color, timestamp=datetime.now(timezone.utc))
    if title:
        e.title = title
    if description:
        e.description = description
    e.set_footer(text=f"{BRAND_NAME} • Bot")
    return e


def ok(title: str, desc: Optional[str] = None) -> discord.Embed:
    return _base(SUCCESS_COLOR, f"✅  {title}", desc)


def warn(title: str, desc: Optional[str] = None) -> discord.Embed:
    return _base(WARN_COLOR, f"⚠️  {title}", desc)


def err(title: str, desc: Optional[str] = None) -> discord.Embed:
    return _base(ERROR_COLOR, f"❌  {title}", desc)


def info(title: str, desc: Optional[str] = None) -> discord.Embed:
    return _base(INFO_COLOR, f"ℹ️  {title}", desc)


def brand(title: str, desc: Optional[str] = None) -> discord.Embed:
    return _base(BRAND_COLOR, title, desc)


# ────────────────────────────────────────────────────────────────────
# Paginator — used by warnings, cases, ticket searches, etc.
# ────────────────────────────────────────────────────────────────────
class Paginator(discord.ui.View):
    """Simple prev / next paginator for a list of embeds."""

    def __init__(self, pages: Sequence[discord.Embed], *,
                 author_id: Optional[int] = None, timeout: float = 180):
        super().__init__(timeout=timeout)
        self.pages: List[discord.Embed] = list(pages)
        self.author_id = author_id
        self.index = 0
        self._refresh_footer()
        self._sync_state()

    def _refresh_footer(self):
        total = len(self.pages)
        for i, e in enumerate(self.pages, 1):
            e.set_footer(text=f"{BRAND_NAME} • Page {i}/{total}")

    def _sync_state(self):
        self.prev_btn.disabled = self.index == 0
        self.next_btn.disabled = self.index >= len(self.pages) - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.author_id and interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "You cannot control this paginator.", ephemeral=True)
            return False
        return True

    @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary)
    async def first_btn(self, interaction: discord.Interaction, _btn):
        self.index = 0
        self._sync_state()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(emoji="⬅️", style=discord.ButtonStyle.primary)
    async def prev_btn(self, interaction: discord.Interaction, _btn):
        self.index = max(0, self.index - 1)
        self._sync_state()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(emoji="➡️", style=discord.ButtonStyle.primary)
    async def next_btn(self, interaction: discord.Interaction, _btn):
        self.index = min(len(self.pages) - 1, self.index + 1)
        self._sync_state()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary)
    async def last_btn(self, interaction: discord.Interaction, _btn):
        self.index = len(self.pages) - 1
        self._sync_state()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(emoji="🗑️", style=discord.ButtonStyle.danger)
    async def close_btn(self, interaction: discord.Interaction, _btn):
        try:
            await interaction.message.delete()
        except Exception:
            for c in self.children:
                c.disabled = True
            await interaction.response.edit_message(view=self)


# ────────────────────────────────────────────────────────────────────
# Confirmation prompt
# ────────────────────────────────────────────────────────────────────
class ConfirmView(discord.ui.View):
    def __init__(self, *, author_id: int, timeout: float = 30):
        super().__init__(timeout=timeout)
        self.author_id = author_id
        self.value: Optional[bool] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "This confirmation is for someone else.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirm", emoji="✅", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, _btn):
        self.value = True
        for c in self.children:
            c.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="Cancel", emoji="✖️", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, _btn):
        self.value = False
        for c in self.children:
            c.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()


# ────────────────────────────────────────────────────────────────────
# Helpers used by cogs
# ────────────────────────────────────────────────────────────────────
def chunk(seq: Iterable, size: int) -> List[list]:
    seq = list(seq)
    return [seq[i:i + size] for i in range(0, len(seq), size)]


def build_pages(items: Sequence, per_page: int,
                make_embed: Callable[[List, int, int], discord.Embed]
                ) -> List[discord.Embed]:
    """Turn a list of items into a paginated list of embeds.

    `make_embed(page_items, page_index, page_count)` must return the embed.
    """
    chunks = chunk(items, per_page)
    total = max(1, len(chunks))
    pages: List[discord.Embed] = []
    if not chunks:
        pages.append(make_embed([], 0, 1))
    else:
        for i, page in enumerate(chunks):
            pages.append(make_embed(page, i, total))
    return pages
