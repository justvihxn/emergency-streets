"""
Ticket System Database Manager
------------------------------
Uses MongoDB (motor) if MONGO_URI is set, otherwise falls back to a
threadsafe JSON file store so the bot works out-of-the-box.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

try:
    from motor.motor_asyncio import AsyncIOMotorClient  # type: ignore
    _HAS_MOTOR = True
except Exception:
    _HAS_MOTOR = False


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)
JSON_PATH = DATA_DIR / "tickets_db.json"


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class _JsonStore:
    """Simple async-friendly JSON store used when Mongo isn't available."""

    def __init__(self, path: Path):
        self.path = path
        self._lock = asyncio.Lock()
        if not path.exists():
            path.write_text(json.dumps(self._empty()))

    @staticmethod
    def _empty() -> dict:
        return {
            "config": {},
            "tickets": {},
            "blacklist": [],
            "counter": 0,
        }

    async def _read(self) -> dict:
        try:
            return json.loads(self.path.read_text() or "{}") or self._empty()
        except Exception:
            return self._empty()

    async def _write(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2, default=str))
        tmp.replace(self.path)

    async def get(self, key: str, default: Any = None) -> Any:
        async with self._lock:
            data = await self._read()
            return data.get(key, default)

    async def set(self, key: str, value: Any) -> None:
        async with self._lock:
            data = await self._read()
            data[key] = value
            await self._write(data)

    async def update_map(self, key: str, sub_key: str, value: Any) -> None:
        async with self._lock:
            data = await self._read()
            data.setdefault(key, {})[sub_key] = value
            await self._write(data)

    async def remove_from_map(self, key: str, sub_key: str) -> None:
        async with self._lock:
            data = await self._read()
            if key in data and sub_key in data[key]:
                del data[key][sub_key]
                await self._write(data)

    async def increment_counter(self) -> int:
        async with self._lock:
            data = await self._read()
            data["counter"] = int(data.get("counter", 0)) + 1
            await self._write(data)
            return data["counter"]


class TicketDB:
    """Unified DB facade — MongoDB (preferred) or JSON fallback."""

    def __init__(self):
        self.mongo_uri = os.environ.get("MONGO_URI") or os.environ.get("MONGO_URL")
        self.db_name = os.environ.get("MONGO_DB_NAME", "emergency_streets_tickets")
        self.mode = "mongo" if (self.mongo_uri and _HAS_MOTOR) else "json"
        self._json = _JsonStore(JSON_PATH)
        self._client = None
        self._db = None

    async def connect(self) -> None:
        if self.mode != "mongo":
            print(f"[ticket-db] Using JSON store at {JSON_PATH}")
            return
        try:
            self._client = AsyncIOMotorClient(self.mongo_uri, serverSelectionTimeoutMS=5000)
            await self._client.admin.command("ping")
            self._db = self._client[self.db_name]
            print(f"[ticket-db] Connected to MongoDB → {self.db_name}")
        except Exception as e:
            print(f"[ticket-db] Mongo unavailable ({e}); falling back to JSON.")
            self.mode = "json"

    # ─── Config (per-guild) ────────────────────────────────────────
    async def get_config(self, guild_id: int) -> dict:
        gid = str(guild_id)
        if self.mode == "mongo":
            doc = await self._db.config.find_one({"_id": gid})
            return doc or {"_id": gid}
        cfg = await self._json.get("config", {})
        return cfg.get(gid, {})

    async def set_config(self, guild_id: int, updates: dict) -> None:
        gid = str(guild_id)
        if self.mode == "mongo":
            await self._db.config.update_one({"_id": gid}, {"$set": updates}, upsert=True)
            return
        cfg = await self._json.get("config", {})
        cfg.setdefault(gid, {}).update(updates)
        await self._json.set("config", cfg)

    # ─── Tickets ───────────────────────────────────────────────────
    async def next_ticket_number(self, guild_id: int) -> int:
        gid = str(guild_id)
        if self.mode == "mongo":
            doc = await self._db.counters.find_one_and_update(
                {"_id": gid}, {"$inc": {"n": 1}}, upsert=True, return_document=True
            )
            return int(doc.get("n", 1))
        return await self._json.increment_counter()

    async def create_ticket(self, ticket: dict) -> None:
        if self.mode == "mongo":
            await self._db.tickets.update_one(
                {"_id": ticket["_id"]}, {"$set": ticket}, upsert=True
            )
            return
        tickets = await self._json.get("tickets", {})
        tickets[ticket["_id"]] = ticket
        await self._json.set("tickets", tickets)

    async def update_ticket(self, ticket_id: str, updates: dict) -> None:
        if self.mode == "mongo":
            await self._db.tickets.update_one({"_id": ticket_id}, {"$set": updates})
            return
        tickets = await self._json.get("tickets", {})
        if ticket_id in tickets:
            tickets[ticket_id].update(updates)
            await self._json.set("tickets", tickets)

    async def get_ticket(self, ticket_id: str) -> Optional[dict]:
        if self.mode == "mongo":
            return await self._db.tickets.find_one({"_id": ticket_id})
        tickets = await self._json.get("tickets", {})
        return tickets.get(ticket_id)

    async def get_ticket_by_channel(self, channel_id: int) -> Optional[dict]:
        if self.mode == "mongo":
            return await self._db.tickets.find_one({"channel_id": int(channel_id)})
        tickets = await self._json.get("tickets", {})
        for t in tickets.values():
            if int(t.get("channel_id", 0)) == int(channel_id):
                return t
        return None

    async def find_open_ticket_by_user(self, guild_id: int, user_id: int, category: str) -> Optional[dict]:
        if self.mode == "mongo":
            return await self._db.tickets.find_one({
                "guild_id": int(guild_id),
                "owner_id": int(user_id),
                "category": category,
                "status": {"$in": ["open", "claimed", "locked"]},
            })
        tickets = await self._json.get("tickets", {})
        for t in tickets.values():
            if (int(t.get("guild_id", 0)) == int(guild_id)
                    and int(t.get("owner_id", 0)) == int(user_id)
                    and t.get("category") == category
                    and t.get("status") in ("open", "claimed", "locked")):
                return t
        return None

    async def list_tickets(self, guild_id: int) -> list:
        if self.mode == "mongo":
            cur = self._db.tickets.find({"guild_id": int(guild_id)})
            return [t async for t in cur]
        tickets = await self._json.get("tickets", {})
        return [t for t in tickets.values() if int(t.get("guild_id", 0)) == int(guild_id)]

    async def delete_ticket(self, ticket_id: str) -> None:
        if self.mode == "mongo":
            await self._db.tickets.delete_one({"_id": ticket_id})
            return
        tickets = await self._json.get("tickets", {})
        tickets.pop(ticket_id, None)
        await self._json.set("tickets", tickets)

    # ─── Blacklist ─────────────────────────────────────────────────
    async def blacklist_add(self, user_id: int, reason: str = "") -> None:
        if self.mode == "mongo":
            await self._db.blacklist.update_one(
                {"_id": str(user_id)},
                {"$set": {"reason": reason, "added_at": _utcnow_iso()}},
                upsert=True,
            )
            return
        bl = await self._json.get("blacklist", [])
        entry = {"user_id": str(user_id), "reason": reason, "added_at": _utcnow_iso()}
        bl = [b for b in bl if str(b.get("user_id")) != str(user_id)] + [entry]
        await self._json.set("blacklist", bl)

    async def blacklist_remove(self, user_id: int) -> None:
        if self.mode == "mongo":
            await self._db.blacklist.delete_one({"_id": str(user_id)})
            return
        bl = await self._json.get("blacklist", [])
        bl = [b for b in bl if str(b.get("user_id")) != str(user_id)]
        await self._json.set("blacklist", bl)

    async def is_blacklisted(self, user_id: int) -> bool:
        if self.mode == "mongo":
            doc = await self._db.blacklist.find_one({"_id": str(user_id)})
            return doc is not None
        bl = await self._json.get("blacklist", [])
        return any(str(b.get("user_id")) == str(user_id) for b in bl)



# global singleton
db = TicketDB()
