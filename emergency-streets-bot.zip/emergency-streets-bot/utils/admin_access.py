"""Admin access module — separate tier between staff and owner.
Admin roles get access to: recruitment panel, giveaways, voice module, embed.
Only bot owners can manage admin roles.
"""
import json
import os

ADMIN_FILE = "database/admin_roles.json"

ADMIN_MODULES = {
    "recruitment": "Recruitment Panel",
    "giveaway": "Giveaways",
    "voice": "Voice Module (Drag)",
    "embed": "Embed",
}


def _load() -> dict:
    try:
        with open(ADMIN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data: dict):
    os.makedirs("database", exist_ok=True)
    with open(ADMIN_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def is_admin(guild_id: str, member) -> bool:
    """True if the member has a configured admin role for this guild."""
    if not hasattr(member, "roles"):
        return False
    data = _load()
    role_ids = {str(r.id) for r in member.roles}
    admin_roles = set(data.get(str(guild_id), []))
    return bool(role_ids & admin_roles)


def add_admin_role(guild_id: str, role_id: str):
    data = _load()
    gid = str(guild_id)
    rid = str(role_id)
    if gid not in data:
        data[gid] = []
    if rid not in data[gid]:
        data[gid].append(rid)
    _save(data)


def remove_admin_role(guild_id: str, role_id: str):
    data = _load()
    gid = str(guild_id)
    data[gid] = [r for r in data.get(gid, []) if r != str(role_id)]
    _save(data)


def get_admin_roles(guild_id: str) -> list:
    return _load().get(str(guild_id), [])
