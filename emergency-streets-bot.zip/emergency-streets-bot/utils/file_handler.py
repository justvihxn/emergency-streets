import json
import os

def ensure_path(path):
    """Create folders and file if they don't exist."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.isfile(path):
        with open(path, "w") as f:
            json.dump({}, f)  # create empty JSON file

def load_json(path):
    ensure_path(path)
    with open(path, "r") as f:
        return json.load(f)

def save_json(path, data):
    ensure_path(path)
    with open(path, "w") as f:
        json.dump(data, f, indent=4)
