"""JSON-backed store"""
import json
import os
import threading
from typing import Any, Dict, List, Optional

DATA_DIR = os.path.abspath(os.environ.get("DATA_DIR") or os.path.join(os.path.dirname(__file__), "data"))
DB_PATH = os.path.join(DATA_DIR, "store.json")

_cache: Dict[str, Any] = {"guilds": {}}
_lock = threading.Lock()
_save_timer: Optional[threading.Timer] = None


def _ensure_dir() -> None:
    os.makedirs(DATA_DIR, exist_ok=True)


def load_store() -> None:
    global _cache
    _ensure_dir()
    if not os.path.exists(DB_PATH):
        _cache = {"guilds": {}}
        persist()
        return
    try:
        with open(DB_PATH, "r", encoding="utf-8") as f:
            _cache = json.load(f)
        if "guilds" not in _cache:
            _cache["guilds"] = {}
    except Exception as err:
        print(f"[store] failed to load, resetting: {err}")
        _cache = {"guilds": {}}
        persist()


def _do_save() -> None:
    _ensure_dir()
    with _lock:
        with open(DB_PATH, "w", encoding="utf-8") as f:
            json.dump(_cache, f, indent=2)


def persist() -> None:
    global _save_timer
    if _save_timer is not None:
        _save_timer.cancel()
    _save_timer = threading.Timer(0.05, _do_save)
    _save_timer.daemon = True
    _save_timer.start()


def get_guild(guild_id: str) -> Dict[str, Any]:
    gid = str(guild_id)
    if gid not in _cache["guilds"]:
        _cache["guilds"][gid] = {}
    return _cache["guilds"][gid]


def update_guild(guild_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    g = get_guild(guild_id)
    g.update(patch)
    persist()
    return g


# ─── Antinuke ──────────────────────────────────────────────────────────────
ANTINUKE_ACTIONS = [
    "channelDelete", "channelCreate", "roleDelete", "roleCreate",
    "ban", "kick", "memberRoleUpdate", "webhookCreate", "botAdd",
]

ANTINUKE_ACTION_LABELS = {
    "channelDelete": "Channel Delete",
    "channelCreate": "Channel Create",
    "roleDelete": "Role Delete",
    "roleCreate": "Role Create",
    "ban": "Member Ban",
    "kick": "Member Kick",
    "memberRoleUpdate": "Mass Role Change",
    "webhookCreate": "Webhook Create",
    "botAdd": "Bot Add",
}

DEFAULT_ANTINUKE_RULES = {
    "channelDelete": {"threshold": 2, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "channelCreate": {"threshold": 4, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "roleDelete": {"threshold": 2, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "roleCreate": {"threshold": 4, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "ban": {"threshold": 3, "windowMs": 10000, "punishment": "ban", "enabled": True},
    "kick": {"threshold": 3, "windowMs": 10000, "punishment": "ban", "enabled": True},
    "memberRoleUpdate": {"threshold": 5, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "webhookCreate": {"threshold": 3, "windowMs": 10000, "punishment": "quarantine", "enabled": True},
    "botAdd": {"threshold": 1, "windowMs": 60000, "punishment": "ban", "enabled": True},
}


def get_antinuke_rule(guild_id: str, action: str) -> Dict[str, Any]:
    g = get_guild(guild_id)
    rules = g.get("antinukeRules") or {}
    rule = rules.get(action)
    if rule:
        return rule
    legacy = g.get("antinukeThresholds")
    default = DEFAULT_ANTINUKE_RULES[action]
    if legacy:
        legacy_map = {
            "channelDelete": legacy.get("channelDelete"),
            "roleDelete": legacy.get("roleDelete"),
            "ban": legacy.get("ban"),
            "kick": legacy.get("kick"),
        }
        return {
            "threshold": legacy_map.get(action) or default["threshold"],
            "windowMs": legacy.get("windowMs") or default["windowMs"],
            "punishment": default["punishment"],
            "enabled": True,
        }
    return dict(default)


def set_antinuke_rule(guild_id: str, action: str, rule: Dict[str, Any]) -> Dict[str, Any]:
    g = get_guild(guild_id)
    if "antinukeRules" not in g:
        g["antinukeRules"] = {}
    current = get_antinuke_rule(guild_id, action)
    nxt = {**current, **rule}
    g["antinukeRules"][action] = nxt
    persist()
    return nxt


# ─── Logs ──────────────────────────────────────────────────────────────────
LOG_EVENT_LABELS = {
    "messageDelete": "🗑️ Message Delete",
    "messageEdit": "✏️ Message Edit",
    "memberJoin": "📥 Member Join",
    "memberLeave": "📤 Member Leave",
    "memberBan": "🔨 Member Ban",
    "memberUnban": "♻️ Member Unban",
    "channelCreate": "🆕 Channel Create",
    "channelDelete": "❌ Channel Delete",
    "roleCreate": "🎭 Role Create",
    "roleDelete": "🗯️ Role Delete",
    "voiceJoin": "🔊 Voice Join",
    "voiceLeave": "🔇 Voice Leave",
    "voiceMove": "🔁 Voice Move",
    "antinuke": "🛡️ Antinuke Trigger",
    "automod": "🤖 AutoMod Action",
    "invite": "🔗 Invite Use",
}
LOG_EVENTS = list(LOG_EVENT_LABELS.keys())


def is_log_event_enabled(guild_id: str, event: str) -> bool:
    g = get_guild(guild_id)
    if not g.get("logChannelId"):
        return False
    return (g.get("logEvents") or {}).get(event, True)


# ─── Staff gate ────────────────────────────────────────────────────────────
def is_staff(guild_id: str, member) -> bool:
    if member is None:
        return False
    perms = getattr(member, "guild_permissions", None) or getattr(member, "permissions", None)
    if perms is not None and getattr(perms, "administrator", False):
        return True
    cfg = get_guild(guild_id)
    staff = cfg.get("staffRoleIds") or []
    if not staff:
        return False
    role_ids = {str(r.id) for r in getattr(member, "roles", [])}
    return any(s in role_ids for s in staff)


# ─── Automod ───────────────────────────────────────────────────────────────
DEFAULT_AUTOMOD = {
    "enabled": False,
    "antiInvite": False,
    "antiLink": False,
    "antiMassMention": {"enabled": False, "max": 5},
    "antiSpam": {"enabled": False, "max": 5, "windowMs": 5000},
    "antiCaps": {"enabled": False, "minLength": 8, "percent": 70},
    "badWords": [],
    "ignoredChannels": [],
    "ignoredRoles": [],
}


def get_automod(guild_id: str) -> Dict[str, Any]:
    g = get_guild(guild_id)
    if "automod" not in g or g["automod"] is None:
        g["automod"] = dict(DEFAULT_AUTOMOD)
    a = g["automod"]
    return {
        "enabled": a.get("enabled", DEFAULT_AUTOMOD["enabled"]),
        "antiInvite": a.get("antiInvite", DEFAULT_AUTOMOD["antiInvite"]),
        "antiLink": a.get("antiLink", DEFAULT_AUTOMOD["antiLink"]),
        "antiMassMention": a.get("antiMassMention", dict(DEFAULT_AUTOMOD["antiMassMention"])),
        "antiSpam": a.get("antiSpam", dict(DEFAULT_AUTOMOD["antiSpam"])),
        "antiCaps": a.get("antiCaps", dict(DEFAULT_AUTOMOD["antiCaps"])),
        "badWords": a.get("badWords") or [],
        "ignoredChannels": a.get("ignoredChannels") or [],
        "ignoredRoles": a.get("ignoredRoles") or [],
    }
