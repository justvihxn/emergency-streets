import discord
from discord.ext import commands, tasks
from discord import app_commands
import time
import os
from utils.file_handler import load_json, save_json

AFK_FILE = "database/afk.json"
AUTOAFK_FILE = "database/autoafk.json"

# Idle threshold for auto-AFK (40 minutes, in seconds)
AUTO_AFK_IDLE_SECONDS = 40 * 60
AUTO_AFK_REASON = "Inactive"

for _f in (AFK_FILE, AUTOAFK_FILE):
    if not os.path.exists(_f):
        save_json(_f, {})


def format_duration(seconds: int):
    mins, secs = divmod(seconds, 60)
    hrs, mins = divmod(mins, 60)
    if hrs > 0:
        return f"{hrs}h {mins}m ago"
    if mins > 0:
        return f"{mins}m {secs}s ago"
    return f"{secs}s ago"


def _autoafk_is_enabled(user_id: int) -> bool:
    cfg = load_json(AUTOAFK_FILE) or {}
    return bool(cfg.get(str(user_id), False))


def _autoafk_set(user_id: int, enabled: bool):
    cfg = load_json(AUTOAFK_FILE) or {}
    if enabled:
        cfg[str(user_id)] = True
    else:
        cfg.pop(str(user_id), None)
    save_json(AUTOAFK_FILE, cfg)


class AFK(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Global last-activity per user (in-memory; resets on bot restart)
        self.last_active: dict[int, float] = {}
        self.auto_afk_loop.start()

    def cog_unload(self):
        self.auto_afk_loop.cancel()

    # ───────────────────────── /afk ─────────────────────────
    @app_commands.command(name="afk", description="Set your AFK status.")
    async def afk(self, interaction: discord.Interaction, reason: str = "AFK"):
        data = load_json(AFK_FILE)
        original_nick = interaction.user.nick if interaction.guild else None
        data[str(interaction.user.id)] = {
            "reason": reason,
            "time": int(time.time()),
            "name": interaction.user.display_name,
            "original_nick": original_nick,
            "auto": False,
        }
        save_json(AFK_FILE, data)

        try:
            if interaction.guild and interaction.user.nick:
                new_nick = f"[AFK] {interaction.user.display_name[:25]}"
                await interaction.user.edit(nick=new_nick)
        except (discord.Forbidden, discord.HTTPException):
            pass

        await interaction.response.send_message(
            f"You are now AFK: **{reason}**",
            ephemeral=False
        )

    # ─────────────── /autoafk enabled:true|false (personal) ───────────────
    @app_commands.command(
        name="autoafk",
        description="Toggle your own auto-AFK after 40 min of inactivity",
    )
    @app_commands.describe(enabled="Turn YOUR auto-AFK on (true) or off (false)")
    async def autoafk_toggle(self, interaction: discord.Interaction, enabled: bool):
        _autoafk_set(interaction.user.id, enabled)
        if enabled:
            # Seed last_active so countdown starts from now
            self.last_active[interaction.user.id] = time.time()
            msg = (f"Auto-AFK is now **enabled ✅** for you.\n"
                   f"If you don't send a message anywhere for **40 minutes**, "
                   f"I'll set you AFK as *{AUTO_AFK_REASON}* automatically.")
        else:
            msg = "Auto-AFK is now **disabled ❌** for you."
        await interaction.response.send_message(msg, ephemeral=True)

    # ─────────────── prefix: !autoafk true / false (personal) ───────────────
    @commands.command(name="autoafk")
    async def autoafk_prefix(self, ctx: commands.Context, enabled: str = None):
        if enabled is None:
            cur = _autoafk_is_enabled(ctx.author.id)
            return await ctx.reply(
                f"Your auto-AFK is currently **{'enabled ✅' if cur else 'disabled ❌'}**.\n"
                f"Usage: `{ctx.prefix}autoafk true` or `{ctx.prefix}autoafk false`"
            )

        truthy = {"true", "on", "yes", "1", "enable", "enabled"}
        falsy = {"false", "off", "no", "0", "disable", "disabled"}
        v = enabled.strip().lower()
        if v in truthy:
            new_val = True
        elif v in falsy:
            new_val = False
        else:
            return await ctx.reply("Invalid value. Use `true` or `false`.")

        _autoafk_set(ctx.author.id, new_val)
        if new_val:
            self.last_active[ctx.author.id] = time.time()
            await ctx.reply(
                f"Auto-AFK is now **enabled ✅** for you.\n"
                f"If you don't send a message anywhere for **40 minutes**, "
                f"I'll set you AFK as *{AUTO_AFK_REASON}* automatically."
            )
        else:
            await ctx.reply("Auto-AFK is now **disabled ❌** for you.")

    # ─────────────────── message listener ───────────────────
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        # Track global last-activity for auto-AFK
        self.last_active[message.author.id] = time.time()

        # Ignore replies for AFK mention notifications
        if message.reference is not None:
            return

        afk_data = load_json(AFK_FILE)

        # Notify when AFK users are mentioned
        for user in message.mentions:
            info = afk_data.get(str(user.id))
            if not info:
                continue

            elapsed = int(time.time()) - info["time"]

            embed = discord.Embed(
                title="User is AFK",
                description=f"**{info['reason']}** — {format_duration(elapsed)}",
                color=discord.Color.purple()
            )
            embed.set_author(name=user.display_name, icon_url=user.display_avatar.url)

            try:
                await message.channel.send(embed=embed)
            except Exception:
                pass

            dm_embed = discord.Embed(
                title="You were mentioned",
                description=f"**Server:** {message.guild.name}",
                color=discord.Color.purple()
            )
            dm_embed.add_field(name="Author", value=message.author.mention, inline=False)
            dm_embed.add_field(
                name="Message",
                value=message.content or "*No text content*",
                inline=False
            )
            dm_embed.add_field(
                name="Jump to message",
                value=f"[Click here]({message.jump_url})",
                inline=False
            )

            try:
                await user.send(embed=dm_embed)
            except discord.Forbidden:
                pass

        # Remove AFK when user sends a message
        author_id = str(message.author.id)
        if author_id in afk_data:
            entry = afk_data[author_id]
            original_nick = entry.get("original_nick")
            try:
                await message.author.edit(nick=original_nick)
            except (discord.Forbidden, discord.HTTPException):
                pass

            del afk_data[author_id]
            save_json(AFK_FILE, afk_data)

            try:
                await message.channel.send(
                    f"✅ Welcome back {message.author.mention}, your AFK status has been removed."
                )
            except Exception:
                pass

    # ─────────────────── background auto-AFK loop ───────────────────
    @tasks.loop(seconds=60.0)
    async def auto_afk_loop(self):
        """Every minute, mark opted-in users AFK if globally idle >= 40 min."""
        try:
            cfg = load_json(AUTOAFK_FILE) or {}
            if not cfg:
                return  # nobody opted in — skip work

            now = time.time()
            afk_data = load_json(AFK_FILE) or {}
            changed = False

            for uid_str in list(cfg.keys()):
                if not cfg.get(uid_str):
                    continue
                try:
                    uid = int(uid_str)
                except ValueError:
                    continue

                if uid_str in afk_data:
                    continue  # already AFK

                last = self.last_active.get(uid)
                if last is None:
                    # Never seen since bot start — seed so window starts now
                    self.last_active[uid] = now
                    continue
                if (now - last) < AUTO_AFK_IDLE_SECONDS:
                    continue

                # Find the user in any guild to capture display name / nick
                member_obj = None
                for g in self.bot.guilds:
                    m = g.get_member(uid)
                    if m and not m.bot:
                        member_obj = m
                        break
                if member_obj is None:
                    continue

                afk_data[uid_str] = {
                    "reason": AUTO_AFK_REASON,
                    "time": int(now),
                    "name": member_obj.display_name,
                    "original_nick": member_obj.nick,
                    "auto": True,
                }
                changed = True

                # Try to update nick in every server they share with the bot
                for g in self.bot.guilds:
                    m = g.get_member(uid)
                    if not m or not m.nick:
                        continue
                    try:
                        await m.edit(nick=f"[AFK] {m.display_name[:25]}")
                    except (discord.Forbidden, discord.HTTPException):
                        pass

            if changed:
                save_json(AFK_FILE, afk_data)
        except Exception:
            pass

    @auto_afk_loop.before_loop
    async def _before_auto_afk(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(AFK(bot))
