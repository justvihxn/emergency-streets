import discord
from discord.ext import commands

class AutoReact(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # 👇 Set your channel IDs directly here
        self.review_channel_ids = [1401789574275010694, 1401797245631860788, 1363688233606582415, 1363688233606582416, 1363688233606582418]  # Add multiple review channel IDs
        self.tracked_channel_ids = [1401797245631860788]   # Add multiple tracked channel IDs

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # Skip system/webhook messages
        if message.webhook_id or message.type != discord.MessageType.default:
            return

        # 💬 REVIEW_CHANNEL: React to user messages only
        if message.channel.id in self.review_channel_ids and not message.author.bot:
            try:
                await message.add_reaction("<:Emergency Streets:1387360626388500510>")
            except discord.HTTPException:
                print(f"❌ Could not react in review channel: {message.channel.id}")

        # 🤖 ORDER_CHANNEL: React to bot messages only
        elif message.channel.id in self.tracked_channel_ids and message.author.bot:
            try:
                await message.add_reaction("<:trusted:1402282696826425355>")
            except discord.HTTPException:
                print(f"❌ Could not react in tracked channel: {message.channel.id}")

        # NOTE: process_commands is handled by bot.py on_message — do NOT call it here
        # Calling it here was causing every prefix command to respond twice.

async def setup(bot: commands.Bot):
    await bot.add_cog(AutoReact(bot))
