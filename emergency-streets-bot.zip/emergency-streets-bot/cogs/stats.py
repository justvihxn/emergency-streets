import discord
import psutil
import platform
import datetime
from discord.ext import commands
from discord import app_commands, Interaction, Embed, ui

class StatsView(ui.View):
    def __init__(self, bot, author: discord.User):
        super().__init__(timeout=60)
        self.bot = bot
        self.author = author

    async def interaction_check(self, interaction: Interaction) -> bool:
        return interaction.user.id == self.author.id

    @ui.button(label="General", style=discord.ButtonStyle.primary)
    async def general_button(self, interaction: Interaction, button: ui.Button):
        uptime = datetime.datetime.now() - self.bot.launch_time
        embed = discord.Embed(
            title="__**General Bot Information**__",
            color=discord.Color.purple()
        )
        embed.add_field(name="__**Bot Tag**__", value=f"{self.bot.user}", inline=True)
        embed.add_field(name="__**Created**__", value=f"<t:{int(self.bot.user.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="__**Servers**__", value=f"{len(self.bot.guilds)}", inline=True)
        embed.add_field(name="__**Channels**__", value=f"{sum(len(guild.channels) for guild in self.bot.guilds)}", inline=True)
        embed.add_field(name="__**Uptime**__", value=f"{uptime}", inline=True)
        embed.add_field(name="__**WS Ping**__", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        embed.set_footer(text=f"Requested by {self.author}", icon_url=self.author.display_avatar.url)
        await interaction.response.edit_message(embed=embed)

    @ui.button(label="System", style=discord.ButtonStyle.secondary)
    async def system_button(self, interaction: Interaction, button: ui.Button):
        cpu = psutil.cpu_freq()
        ram = psutil.virtual_memory()
        free_mem = round(ram.available / 1024**3, 2)
        embed = discord.Embed(
            title="__**System Information**__",
            color=discord.Color.purple()
        )
        embed.add_field(name="__**Platform**__", value=platform.system(), inline=True)
        embed.add_field(name="__**Architecture**__", value=platform.machine(), inline=True)
        embed.add_field(name="__**CPU Model**__", value=platform.processor(), inline=True)
        embed.add_field(name="__**CPU Speed**__", value=f"{cpu.current:.2f} MHz", inline=True)
        embed.add_field(name="__**RAM Usage**__", value=f"{ram.percent}%", inline=True)
        embed.add_field(name="__**Free Memory**__", value=f"{free_mem} GB", inline=True)
        embed.set_footer(text=f"Requested by {self.author}", icon_url=self.author.display_avatar.url)
        await interaction.response.edit_message(embed=embed)

    @ui.button(label="Team", style=discord.ButtonStyle.success)
    async def team_button(self, interaction: Interaction, button: ui.Button):
        embed = discord.Embed(
            title="__**Team Information**__",
            color=discord.Color.purple()
        )
        embed.add_field(
            name="__**Developers**__",
            value="[1. Itz_End](https://discord.com/users/1361695648579321956)",
            inline=False
        )
        embed.add_field(
            name="__**Owners**__",
            value="[1. Rishabh Niranjan](https://discord.com/users/1366420472916348961)",
            inline=False
        )
        embed.set_footer(text=f"Requested by {self.author}", icon_url=self.author.display_avatar.url)
        await interaction.response.edit_message(embed=embed)

class Stats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.launch_time = datetime.datetime.now()

    @app_commands.command(name="stats", description="Show bot statistics in a beautiful embed with buttons")
    async def stats(self, interaction: discord.Interaction):
        view = StatsView(self.bot, interaction.user)
        uptime = datetime.datetime.now() - self.bot.launch_time
        embed = discord.Embed(
            title="__**General Bot Information**__",
            color=discord.Color.purple()
        )
        embed.add_field(name="__**Bot Tag**__", value=f"{self.bot.user}", inline=True)
        embed.add_field(name="__**Created**__", value=f"<t:{int(self.bot.user.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="__**Servers**__", value=f"{len(self.bot.guilds)}", inline=True)
        embed.add_field(name="__**Channels**__", value=f"{sum(len(guild.channels) for guild in self.bot.guilds)}", inline=True)
        embed.add_field(name="__**Uptime**__", value=f"{uptime}", inline=True)
        embed.add_field(name="__**WS Ping**__", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        embed.set_footer(text=f"Requested by {interaction.user}", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(Stats(bot))
