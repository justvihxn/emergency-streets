"""Prefix-command coverage for slash commands."""
import asyncio
from typing import Optional

import discord
from discord.ext import commands

from config import BRAND, DEFAULT_PREFIX
from store import (
    get_guild, persist, is_staff,
    ANTINUKE_ACTIONS, ANTINUKE_ACTION_LABELS, get_antinuke_rule, set_antinuke_rule,
    LOG_EVENTS, LOG_EVENT_LABELS, get_automod,
)
from embeds import brand_embed, success_embed, error_embed, info_embed, expand_newlines


PUNISHMENTS = ["quarantine", "kick", "ban", "strip", "none"]


def _staff(ctx: commands.Context) -> bool:
    if not ctx.guild:
        return False
    return is_staff(str(ctx.guild.id), ctx.author)


async def _deny(ctx: commands.Context):
    await ctx.reply(embed=error_embed("Staff only", "Only members with a configured **staff role** can use bot commands. An admin can run `staff add` to grant access."))


def register_prefix(bot: commands.Bot):
    """Register every prefix command."""

    def _safe_remove(*names: str):
        for n in names:
            if bot.get_command(n):
                bot.remove_command(n)

    _safe_remove("recruitment", "say", "members", "avatar", "serverinfo", "ping", "help",
                 "antinuke", "automod", "logs", "dm", "invites", "drag", "welcome", "requirements", "reqs",
                 "bal", "addr", "tix", "tx")

    # ════════════════════════ ping ════════════════════════
    @bot.command(name="ping")
    async def p_ping(ctx):
        await ctx.reply(embed=success_embed("🏓 Pong!", f"Latency: **{round(bot.latency * 1000)}ms**"))

    # ════════════════════════ help ════════════════════════
    @bot.command(name="help")
    async def p_help(ctx):
        prefix = get_guild(str(ctx.guild.id)).get("prefix", DEFAULT_PREFIX) if ctx.guild else DEFAULT_PREFIX
        e = brand_embed()
        e.title = "Emergency Streets • Help"
        e.description = f"Prefix: `{prefix}` • Also use `/` slash commands."
        e.add_field(name="🛡️ Antinuke [Owner only]",
                    value=f"`{prefix}antinuke status` (staff) • `{prefix}antinuke toggle|set|punishment|whitelist|channel|quarantine` (owner)", inline=False)
        e.add_field(name="🤖 AutoMod [Owner only]",
                    value=f"`{prefix}automod status` (staff) • `{prefix}automod toggle|filter|badword-add/remove|ignore-channel|ignore-role` (owner)", inline=False)
        e.add_field(name="👮 Staff Roles",
                    value=f"`{prefix}staff add|remove @role` (admin) • `{prefix}staff list` (staff)", inline=False)
        e.add_field(name="🔑 Admin Role [Owner only]",
                    value=f"`{prefix}adminrole add|remove|list @role` — grants Recruitment Panel, Giveaways, Voice, Embed access", inline=False)
        e.add_field(name="📝 Logs [Owner only]",
                    value=f"`{prefix}logs channel|toggle|list|enable-all|disable-all`", inline=False)
        e.add_field(name="📜 Recruitment",
                    value=f"`{prefix}recruitment panel` (staff/admin) • `{prefix}recruitment setup #ch` (owner only)", inline=False)
        e.add_field(name="📬 DM",
                    value=f"`{prefix}dm all|role <msg>` (owner) • `{prefix}dm user @user <msg>` (staff)", inline=False)
        e.add_field(name="📨 Invites",
                    value=f"`{prefix}invites view|leaderboard|add|set-log`", inline=False)
        e.add_field(name="🛠️ Util",
                    value=f"`{prefix}serverinfo` • `{prefix}members` • `{prefix}avatar` • `{prefix}memberinfo` • `{prefix}roleinfo`", inline=False)
        e.add_field(name="🎙️ Voice Module",
                    value=f"`{prefix}drag all #vc` (owner) • `{prefix}drag from|user` (staff/admin)", inline=False)
        e.add_field(name="🎉 Giveaway [Staff/Admin]",
                    value=f"`{prefix}gstart #ch <dur> <winners> <prize>` • `{prefix}gend|greroll|gpause|gunpause|gedit|gcancel|glist <id>`", inline=False)
        e.add_field(name="📊 Stats & Tools",
                    value=f"`{prefix}stats` • `{prefix}afk [reason]` • `{prefix}autoafk true|false` • `{prefix}ping` • `{prefix}say <text>`", inline=False)
        e.add_field(name="🔔 Owner Tools",
                    value=f"`{prefix}ownerpingwarn on|off` • `{prefix}owneraddrole @role` • `{prefix}ownerchangerole @user @role`", inline=False)
        e.add_field(name="📨 Remind", value=f"`{prefix}remind @user`", inline=False)
        e.add_field(name="🖼️ Embed [Admin/Admin-role]",
                    value=f"`{prefix}embed <title> | <description> [| <color_hex>]`", inline=False)
        e.add_field(name="🧮 Calculator [Public]",
                    value=f"`{prefix}calc <expression>` — e.g. `{prefix}calc 100 + 50 * 2 - 30 / 3`", inline=False)
        e.add_field(name="💬 Autoresponder",
                    value=f"`{prefix}ar add|addembed|remove|setrole` (owner) • `{prefix}ar list` (staff)", inline=False)
        await ctx.reply(embed=e)

    # ════════════════════════ serverinfo ════════════════════════
    @bot.command(name="serverinfo")
    async def p_si(ctx):
        if not _staff(ctx): return await _deny(ctx)
        g = ctx.guild
        text = sum(1 for c in g.channels if isinstance(c, discord.TextChannel))
        voice = sum(1 for c in g.channels if isinstance(c, discord.VoiceChannel))
        e = brand_embed(); e.title = f"📊 {g.name}"
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.add_field(name="👥 Members", value=str(g.member_count), inline=True)
        e.add_field(name="💬 Text", value=str(text), inline=True)
        e.add_field(name="🔊 Voice", value=str(voice), inline=True)
        e.add_field(name="🎭 Roles", value=str(len(g.roles)), inline=True)
        e.add_field(name="📅 Created", value=f"<t:{int(g.created_at.timestamp())}:R>", inline=True)
        await ctx.reply(embed=e)

    # ════════════════════════ members ════════════════════════
    @bot.command(name="members")
    async def p_members(ctx):
        if not _staff(ctx): return await _deny(ctx)
        g = ctx.guild
        humans = sum(1 for m in g.members if not m.bot)
        bots = sum(1 for m in g.members if m.bot)
        e = brand_embed(); e.title = f"👥 {g.name} — Members"
        e.add_field(name="Total", value=str(g.member_count), inline=True)
        e.add_field(name="Humans", value=str(humans), inline=True)
        e.add_field(name="Bots", value=str(bots), inline=True)
        await ctx.reply(embed=e)

    # ════════════════════════ avatar ════════════════════════
    @bot.command(name="avatar")
    async def p_avatar(ctx, user: Optional[discord.User] = None):
        u = user or ctx.author
        avatar = u.display_avatar
        avatar_url = str(avatar.replace(size=1024))
        e = brand_embed()
        e.title = f"🖼️ {u}"
        e.description = f"{'🎞️ Animated' if avatar.is_animated() else '🖼️ Static'} avatar"
        e.set_image(url=avatar_url)
        await ctx.reply(embed=e)

    # ════════════════════════ say ════════════════════════
    @bot.command(name="say")
    async def p_say(ctx, *, text: str):
        if not _staff(ctx): return await _deny(ctx)
        try:
            await ctx.message.delete()
        except Exception:
            pass
        await ctx.send(text)

    # ════════════════════════ antinuke ════════════════════════
    @bot.group(name="antinuke", aliases=["an"], invoke_without_command=True)
    async def p_an(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`antinuke status|toggle|set|punishment|whitelist add|remove|list [@user/@role ...]|channel|quarantine` *(whitelist: owner only)*"))

    @p_an.command(name="status")
    async def p_an_status(ctx):
        if not _staff(ctx): return await _deny(ctx)
        cfg = get_guild(str(ctx.guild.id))
        rows = []
        for a in ANTINUKE_ACTIONS:
            r = get_antinuke_rule(str(ctx.guild.id), a)
            flag = "🟢" if r["enabled"] else "🔴"
            rows.append(f"{flag} **{ANTINUKE_ACTION_LABELS[a]}** — {r['threshold']} per {r['windowMs']/1000}s → `{r['punishment']}`")
        wl_users = ", ".join(f"<@{u}>"  for u in (cfg.get("antinukeWhitelist")      or [])) or "*(none)*"
        wl_roles  = ", ".join(f"<@&{r}>" for r in (cfg.get("antinukeWhitelistRoles") or [])) or "*(none)*"
        wl = f"Users: {wl_users}\nRoles: {wl_roles}"
        log_id = cfg.get("antinukeLogChannelId"); qr_id = cfg.get("antinukeQuarantineRoleId")
        log_ch_str = f"<#{log_id}>" if log_id else "*not set*"
        qr_str = f"<@&{qr_id}>" if qr_id else "*not set*"
        e = brand_embed(); e.title = "🛡️ Antinuke Status"
        e.description = "\n".join([
            f"**System:** {'🟢 Enabled' if cfg.get('antinukeEnabled') else '🔴 Disabled'}",
            f"**Log channel:** {log_ch_str}",
            f"**Quarantine role:** {qr_str}",
            f"**Whitelist (users):** {wl_users}",
            f"**Whitelist (roles):** {wl_roles}", "", *rows,
        ])
        await ctx.reply(embed=e)

    @p_an.command(name="toggle")
    async def p_an_toggle(ctx, switch: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        en = switch.lower() in ("on", "true", "enable", "enabled", "yes")
        get_guild(str(ctx.guild.id))["antinukeEnabled"] = en; persist()
        await ctx.reply(embed=success_embed(f"Antinuke {'enabled' if en else 'disabled'}"))

    @p_an.command(name="set")
    async def p_an_set(ctx, action: str, threshold: int, window_seconds: Optional[int] = None, enabled: Optional[str] = None):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        if action not in ANTINUKE_ACTIONS:
            return await ctx.reply(embed=error_embed("Invalid action", f"Pick one of: {', '.join(f'`{a}`' for a in ANTINUKE_ACTIONS)}"))
        patch = {"threshold": threshold}
        if window_seconds: patch["windowMs"] = window_seconds * 1000
        if enabled is not None: patch["enabled"] = enabled.lower() in ("on", "true", "yes", "enable", "enabled")
        u = set_antinuke_rule(str(ctx.guild.id), action, patch)
        await ctx.reply(embed=success_embed(f"Updated • {ANTINUKE_ACTION_LABELS[action]}",
            f"Threshold: **{u['threshold']}** • Window: **{u['windowMs']/1000}s** • Punishment: **{u['punishment']}** • {'🟢' if u['enabled'] else '🔴'}"))

    @p_an.command(name="punishment")
    async def p_an_pun(ctx, action: str, punishment: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        if action not in ANTINUKE_ACTIONS:
            return await ctx.reply(embed=error_embed("Invalid action"))
        if punishment not in PUNISHMENTS:
            return await ctx.reply(embed=error_embed("Invalid punishment", f"Pick one of: {', '.join(PUNISHMENTS)}"))
        cfg = get_guild(str(ctx.guild.id))
        if punishment == "quarantine" and not cfg.get("antinukeQuarantineRoleId"):
            return await ctx.reply(embed=error_embed("No quarantine role set", "Run `antinuke quarantine @role` first."))
        u = set_antinuke_rule(str(ctx.guild.id), action, {"punishment": punishment})
        await ctx.reply(embed=success_embed("Punishment updated", f"**{ANTINUKE_ACTION_LABELS[action]}** → `{u['punishment']}`"))

    @p_an.command(name="whitelist", aliases=["wl"])
    async def p_an_wl(ctx, op: str, *, targets: str = ""):
        """Owner-only. Supports multiple @user and @role mentions at once."""
        if ctx.author.id not in bot.owner_ids:
            return await ctx.reply(embed=error_embed("Owner only", "Only bot owners can modify the antinuke whitelist."))

        if op == "list":
            cfg = get_guild(str(ctx.guild.id))
            users_wl = ", ".join(f"<@{u}>"  for u in (cfg.get("antinukeWhitelist")      or [])) or "*(none)*"
            roles_wl = ", ".join(f"<@&{r}>" for r in (cfg.get("antinukeWhitelistRoles") or [])) or "*(none)*"
            e = brand_embed()
            e.title = "🛡️ Antinuke Whitelist"
            e.add_field(name="👤 Whitelisted Users", value=users_wl, inline=False)
            e.add_field(name="🎭 Whitelisted Roles", value=roles_wl, inline=False)
            return await ctx.reply(embed=e)

        if op not in ("add", "remove"):
            return await ctx.reply(embed=error_embed(
                "Usage",
                "`antinuke whitelist add @user @role ...`\n"
                "`antinuke whitelist remove @user @role ...`\n"
                "`antinuke whitelist list`",
            ))

        if not ctx.message.mentions and not ctx.message.role_mentions:
            return await ctx.reply(embed=error_embed("No targets", "Mention at least one user or role after the command."))

        cfg = get_guild(str(ctx.guild.id))
        cfg.setdefault("antinukeWhitelist", [])
        cfg.setdefault("antinukeWhitelistRoles", [])

        added_users, added_roles, removed_users, removed_roles = [], [], [], []

        for user in ctx.message.mentions:
            uid = str(user.id)
            if op == "add":
                if uid not in cfg["antinukeWhitelist"]:
                    cfg["antinukeWhitelist"].append(uid)
                added_users.append(f"<@{uid}>")
            else:
                cfg["antinukeWhitelist"] = [x for x in cfg["antinukeWhitelist"] if x != uid]
                removed_users.append(f"<@{uid}>")

        for role in ctx.message.role_mentions:
            rid = str(role.id)
            if op == "add":
                if rid not in cfg["antinukeWhitelistRoles"]:
                    cfg["antinukeWhitelistRoles"].append(rid)
                added_roles.append(f"<@&{rid}>")
            else:
                cfg["antinukeWhitelistRoles"] = [x for x in cfg["antinukeWhitelistRoles"] if x != rid]
                removed_roles.append(f"<@&{rid}>")

        persist()
        lines = []
        if added_users:   lines.append(f"✅ Added users: {', '.join(added_users)}")
        if added_roles:   lines.append(f"✅ Added roles: {', '.join(added_roles)}")
        if removed_users: lines.append(f"🗑️ Removed users: {', '.join(removed_users)}")
        if removed_roles: lines.append(f"🗑️ Removed roles: {', '.join(removed_roles)}")
        await ctx.reply(embed=success_embed("Whitelist updated", "\n".join(lines)))

    @p_an.command(name="channel")
    async def p_an_ch(ctx, channel: discord.TextChannel):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        get_guild(str(ctx.guild.id))["antinukeLogChannelId"] = str(channel.id); persist()
        await ctx.reply(embed=success_embed("Antinuke log channel set", f"<#{channel.id}>"))

    @p_an.command(name="quarantine")
    async def p_an_qr(ctx, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        get_guild(str(ctx.guild.id))["antinukeQuarantineRoleId"] = str(role.id); persist()
        await ctx.reply(embed=success_embed("Quarantine role set", f"<@&{role.id}>"))

    # ════════════════════════ automod ════════════════════════
    @bot.group(name="automod", aliases=["am"], invoke_without_command=True)
    async def p_am(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`automod status|toggle on|off|filter <type> on|off|badword-add <word>|badword-remove <word>|ignore-channel #ch|ignore-role @role`"))

    @p_am.command(name="toggle")
    async def p_am_toggle(ctx, switch: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        en = switch.lower() in ("on", "true", "enable", "enabled", "yes")
        get_guild(str(ctx.guild.id)).setdefault("automod", {})["enabled"] = en; persist()
        await ctx.reply(embed=success_embed(f"AutoMod {'enabled' if en else 'disabled'}"))

    @p_am.command(name="filter")
    async def p_am_filter(ctx, ftype: str, switch: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        valid = {"antiInvite", "antiLink", "antiMassMention", "antiSpam", "antiCaps"}
        if ftype not in valid:
            return await ctx.reply(embed=error_embed("Invalid filter", f"Pick one of: {', '.join(valid)}"))
        en = switch.lower() in ("on", "true", "enable", "enabled", "yes")
        a = get_guild(str(ctx.guild.id)).setdefault("automod", {})
        if ftype in ("antiInvite", "antiLink"): a[ftype] = en
        elif ftype == "antiMassMention": a["antiMassMention"] = {"enabled": en, "max": (a.get("antiMassMention") or {}).get("max", 5)}
        elif ftype == "antiSpam": a["antiSpam"] = {"enabled": en, "max": (a.get("antiSpam") or {}).get("max", 5), "windowMs": (a.get("antiSpam") or {}).get("windowMs", 5000)}
        elif ftype == "antiCaps": a["antiCaps"] = {"enabled": en, "minLength": (a.get("antiCaps") or {}).get("minLength", 8), "percent": (a.get("antiCaps") or {}).get("percent", 70)}
        persist()
        await ctx.reply(embed=success_embed(f"Filter {ftype} {'enabled' if en else 'disabled'}"))

    @p_am.command(name="badword-add", aliases=["bw-add"])
    async def p_am_bw_add(ctx, *, word: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        a = get_guild(str(ctx.guild.id)).setdefault("automod", {}); a.setdefault("badWords", [])
        w = word.lower()
        if w not in a["badWords"]: a["badWords"].append(w)
        persist()
        await ctx.reply(embed=success_embed("Added", f"`{w}` is now filtered."))

    @p_am.command(name="badword-remove", aliases=["bw-remove"])
    async def p_am_bw_rm(ctx, *, word: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        a = get_guild(str(ctx.guild.id)).setdefault("automod", {}); a.setdefault("badWords", [])
        a["badWords"] = [x for x in a["badWords"] if x != word.lower()]; persist()
        await ctx.reply(embed=success_embed("Removed", f"`{word}` is no longer filtered."))

    @p_am.command(name="ignore-channel")
    async def p_am_ich(ctx, channel: discord.TextChannel):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        a = get_guild(str(ctx.guild.id)).setdefault("automod", {}); a.setdefault("ignoredChannels", [])
        cid = str(channel.id)
        if cid in a["ignoredChannels"]:
            a["ignoredChannels"].remove(cid); persist()
            await ctx.reply(embed=success_embed("Removed from ignore list", f"<#{cid}>"))
        else:
            a["ignoredChannels"].append(cid); persist()
            await ctx.reply(embed=success_embed("Added to ignore list", f"<#{cid}>"))

    @p_am.command(name="ignore-role")
    async def p_am_irole(ctx, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        a = get_guild(str(ctx.guild.id)).setdefault("automod", {}); a.setdefault("ignoredRoles", [])
        rid = str(role.id)
        if rid in a["ignoredRoles"]:
            a["ignoredRoles"].remove(rid); persist()
            await ctx.reply(embed=success_embed("Removed", f"<@&{rid}> no longer exempt."))
        else:
            a["ignoredRoles"].append(rid); persist()
            await ctx.reply(embed=success_embed("Added", f"<@&{rid}> exempt from automod."))

    @p_am.command(name="status")
    async def p_am_status(ctx):
        if not _staff(ctx): return await _deny(ctx)
        a = get_automod(str(ctx.guild.id))
        fmt = lambda b: "🟢 ON" if b else "🔴 OFF"
        e = brand_embed(); e.title = "🤖 AutoMod Status"; e.description = f"Master switch: {fmt(a['enabled'])}"
        e.add_field(name="🔗 Anti-Invite", value=fmt(a["antiInvite"]), inline=True)
        e.add_field(name="🌐 Anti-Link", value=fmt(a["antiLink"]), inline=True)
        e.add_field(name="📣 Anti-Mass-Mention", value=f"{fmt(a['antiMassMention']['enabled'])} (max {a['antiMassMention']['max']})", inline=True)
        e.add_field(name="💨 Anti-Spam", value=f"{fmt(a['antiSpam']['enabled'])} ({a['antiSpam']['max']}/{a['antiSpam']['windowMs']}ms)", inline=True)
        e.add_field(name="🔠 Anti-Caps", value=f"{fmt(a['antiCaps']['enabled'])} ({a['antiCaps']['percent']}% of ≥{a['antiCaps']['minLength']} chars)", inline=True)
        e.add_field(name="🚫 Bad words", value=(", ".join(f"`{w}`" for w in a["badWords"])[:1000] if a["badWords"] else "*(none)*"), inline=False)
        e.add_field(name="🙈 Ignored channels", value=(" ".join(f"<#{c}>" for c in a["ignoredChannels"]) if a["ignoredChannels"] else "*(none)*"), inline=False)
        e.add_field(name="🙉 Ignored roles", value=(" ".join(f"<@&{r}>" for r in a["ignoredRoles"]) if a["ignoredRoles"] else "*(none)*"), inline=False)
        await ctx.reply(embed=e)

    # ════════════════════════ logs (OWNER only) ════════════════════════
    def _owner(ctx: commands.Context) -> bool:
        from config import OWNER_IDS
        return ctx.author.id in OWNER_IDS

    async def _deny_owner_ctx(ctx: commands.Context):
        await ctx.reply(embed=error_embed("Owner only", "This command is restricted to **bot owners** only."))

    @bot.group(name="logs", invoke_without_command=True)
    async def p_logs(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        await ctx.reply(embed=info_embed("Usage", "`logs channel [#ch]` • `logs toggle <event> on|off` • `logs list` • `logs enable-all` • `logs disable-all`"))

    @p_logs.command(name="channel")
    async def p_logs_ch(ctx, channel: Optional[discord.TextChannel] = None):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        cfg = get_guild(str(ctx.guild.id))
        if channel:
            cfg["logChannelId"] = str(channel.id); persist()
            await ctx.reply(embed=success_embed("Log channel set", f"All enabled events will now be logged to <#{channel.id}>."))
        else:
            cfg.pop("logChannelId", None); persist()
            await ctx.reply(embed=success_embed("Logging disabled"))

    @p_logs.command(name="toggle")
    async def p_logs_tog(ctx, event: str, switch: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        if event not in LOG_EVENTS:
            return await ctx.reply(embed=error_embed("Invalid event", f"Pick one of: {', '.join(LOG_EVENTS)}"))
        en = switch.lower() in ("on", "true", "enable", "enabled", "yes")
        cfg = get_guild(str(ctx.guild.id)); cfg.setdefault("logEvents", {})[event] = en; persist()
        ch_part = f"Logging to <#{cfg['logChannelId']}>." if cfg.get("logChannelId") else "⚠️ No log channel set. Run `logs channel #ch` first."
        await ctx.reply(embed=success_embed(f"{'Enabled' if en else 'Disabled'}: {LOG_EVENT_LABELS[event]}", ch_part))

    @p_logs.command(name="list")
    async def p_logs_list(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        cfg = get_guild(str(ctx.guild.id))
        lines = [f"{'🟢' if (cfg.get('logEvents') or {}).get(ev, True) else '🔴'} {LOG_EVENT_LABELS[ev]}" for ev in LOG_EVENTS]
        log_id = cfg.get("logChannelId")
        ch_str = f"<#{log_id}>" if log_id else "*(none — run `logs channel`)*"
        e = brand_embed(); e.title = "📝 Log Events"
        e.description = f"Channel: {ch_str}\n\n" + "\n".join(lines)
        await ctx.reply(embed=e)

    @p_logs.command(name="enable-all")
    async def p_logs_en(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        cfg = get_guild(str(ctx.guild.id)); cfg["logEvents"] = {e: True for e in LOG_EVENTS}; persist()
        await ctx.reply(embed=success_embed("All log events enabled"))

    @p_logs.command(name="disable-all")
    async def p_logs_dis(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        cfg = get_guild(str(ctx.guild.id)); cfg["logEvents"] = {e: False for e in LOG_EVENTS}; persist()
        await ctx.reply(embed=success_embed("All log events disabled"))

    # ════════════════════════ recruitment ════════════════════════
    @bot.group(name="recruitment", aliases=["recruit"], invoke_without_command=True)
    async def p_rc(ctx):
        if not _staff(ctx): return await _deny(ctx)
        from bot import build_recruitment_embed, RecruitmentView
        await ctx.send(embed=build_recruitment_embed(), view=RecruitmentView())

    @p_rc.command(name="setup")
    async def p_rc_setup(ctx, application_channel: discord.TextChannel,
                         panel_channel: Optional[discord.TextChannel] = None,
                         category: Optional[discord.CategoryChannel] = None):
        if not _owner(ctx): return await _deny(ctx)
        from bot import build_recruitment_embed, RecruitmentView
        cfg = get_guild(str(ctx.guild.id))
        cfg["recruitmentLogChannelId"] = str(application_channel.id)
        if panel_channel:
            cfg["recruitmentChannelId"] = str(panel_channel.id)
            await panel_channel.send(embed=build_recruitment_embed(), view=RecruitmentView())
        if category:
            cfg["recruitmentCategoryId"] = str(category.id)
        persist()
        msg = f"Applications: <#{application_channel.id}>"
        if panel_channel: msg += f"\nPanel posted in: <#{panel_channel.id}>"
        if category: msg += f"\nAccepted channels created under: **{category.name}**"
        await ctx.reply(embed=success_embed("Recruitment configured", msg))

    @p_rc.command(name="panel")
    async def p_rc_panel(ctx):
        from utils.admin_access import is_admin as _is_admin_role
        if not (_staff(ctx) or _is_admin_role(str(ctx.guild.id), ctx.author)): return await _deny(ctx)
        from bot import build_recruitment_embed, RecruitmentView
        cfg = get_guild(str(ctx.guild.id))
        if not cfg.get("recruitmentLogChannelId"):
            return await ctx.reply(embed=info_embed("Set up first", "Run `recruitment setup #app_ch` first."))
        await ctx.send(embed=build_recruitment_embed(), view=RecruitmentView())

    # ════════════════════════ dm broadcast ════════════════════════
    @bot.group(name="dm", invoke_without_command=True)
    async def p_dm(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`dm all <message>` • `dm role @role <message>` • `dm user @user <message>`"))

    @p_dm.command(name="all")
    async def p_dm_all(ctx, *, message: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        from bot import build_broadcast_embed, dm_members
        e = build_broadcast_embed(ctx.guild, ctx.author, message)
        members = [m async for m in ctx.guild.fetch_members(limit=None) if not m.bot]
        eta_min = max(1, (len(members) * 30) // 60)
        await ctx.reply(embed=info_embed("📤 Broadcast started",
            f"Sending to **{len(members)}** members at **2 DMs/min** (rate-limit safe).\nEstimated time: **~{eta_min} min**. You'll receive the summary via DM."))
        s = await dm_members(members, e, concurrency=1, delay_ms=30000)
        try:
            await ctx.author.send(embed=success_embed("📬 Broadcast complete",
                f"Server: **{ctx.guild.name}**\nTargeted **all members**.\nAttempted: **{s['attempted']}**\nDelivered: **{s['succeeded']}**\nFailed: **{s['failed']}**"))
        except Exception:
            pass

    @p_dm.command(name="role")
    async def p_dm_role(ctx, role: discord.Role, *, message: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        from bot import build_broadcast_embed, dm_members
        members = [m for m in role.members if not m.bot]
        if not members:
            return await ctx.reply(embed=error_embed("No targets", "Nobody currently has this role."))
        e = build_broadcast_embed(ctx.guild, ctx.author, message)
        eta_min = max(1, (len(members) * 30) // 60)
        await ctx.reply(embed=info_embed("📤 Role broadcast started",
            f"Sending to **{len(members)}** members of <@&{role.id}> at **2 DMs/min** (rate-limit safe).\nEstimated time: **~{eta_min} min**. You'll receive the summary via DM."))
        s = await dm_members(members, e, concurrency=1, delay_ms=30000)
        try:
            await ctx.author.send(embed=success_embed("📬 Role broadcast complete",
                f"Server: **{ctx.guild.name}**\nTargeted role <@&{role.id}> ({len(members)}).\nAttempted: **{s['attempted']}**\nDelivered: **{s['succeeded']}**\nFailed: **{s['failed']}**"))
        except Exception:
            pass

    @p_dm.command(name="user")
    async def p_dm_user(ctx, user: discord.Member, *, message: str):
        if not _staff(ctx): return await _deny(ctx)
        from bot import build_broadcast_embed, dm_members
        e = build_broadcast_embed(ctx.guild, ctx.author, message)
        s = await dm_members([user], e, concurrency=1)
        if s["succeeded"]:
            await ctx.reply(embed=success_embed("📬 DM sent", f"Delivered to <@{user.id}>."))
        else:
            reason = s["failures"][0]["reason"] if s["failures"] else "unknown"
            await ctx.reply(embed=error_embed("DM failed", f"Could not DM <@{user.id}> — *{reason}*."))

    # ════════════════════════ invites ════════════════════════
    @bot.group(name="invites", aliases=["inv"], invoke_without_command=True)
    async def p_inv(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`invites view [@user]` • `invites leaderboard` • `invites add @user <amount>` • `invites set-log #ch`"))

    @p_inv.command(name="view")
    async def p_inv_view(ctx, user: Optional[discord.User] = None):
        if not _staff(ctx): return await _deny(ctx)
        from bot import get_invite_counts
        target = user or ctx.author
        c = get_invite_counts(str(ctx.guild.id), str(target.id))
        e = brand_embed(); e.title = f"📨 Invites • {target.name}"
        e.description = f"**Total:** {c['total']}\n**Real:** {c['regular']}\n**Left:** {c['left']}\n**Fake:** {c['fake']}\n**Bonus:** {c['bonus']}"
        e.set_thumbnail(url=target.display_avatar.url)
        await ctx.reply(embed=e)

    @p_inv.command(name="leaderboard", aliases=["lb"])
    async def p_inv_lb(ctx):
        if not _staff(ctx): return await _deny(ctx)
        cfg = get_guild(str(ctx.guild.id))
        counts = cfg.get("inviteCounts") or {}
        ranked = sorted([(uid, c["regular"] - c["left"] + c["bonus"]) for uid, c in counts.items()], key=lambda x: -x[1])[:10]
        lines = "\n".join(f"**{i+1}.** <@{uid}> — `{t}` invites" for i, (uid, t) in enumerate(ranked)) or "No invite data yet."
        e = brand_embed(); e.title = "📨 Invite Leaderboard"; e.description = lines
        await ctx.reply(embed=e)

    @p_inv.command(name="add")
    async def p_inv_add(ctx, user: discord.User, amount: int):
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("Missing permission", "Requires Manage Server."))
        from bot import add_bonus_invites
        b = add_bonus_invites(str(ctx.guild.id), str(user.id), amount)
        await ctx.reply(embed=success_embed("Bonus invites updated", f"<@{user.id}> now has **{b}** bonus invites."))

    @p_inv.command(name="set-log")
    async def p_inv_log(ctx, channel: discord.TextChannel):
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("Missing permission", "Requires Manage Server."))
        get_guild(str(ctx.guild.id))["inviteLogChannelId"] = str(channel.id); persist()
        await ctx.reply(embed=success_embed("Invite log channel set", f"<#{channel.id}>"))

    # ════════════════════════ drag ════════════════════════
    @bot.group(name="drag", invoke_without_command=True)
    async def p_drag(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`drag all #vc` • `drag from #source #dest` • `drag user @member #vc`"))

    @p_drag.command(name="all")
    async def p_drag_all(ctx, destination: discord.VoiceChannel):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        moved = failed = 0
        for m in ctx.guild.members:
            if m.voice and m.voice.channel and m.voice.channel.id != destination.id:
                try: await m.move_to(destination); moved += 1
                except Exception: failed += 1
        await ctx.reply(embed=success_embed("🔁 Drag complete", f"Moved **{moved}** member(s) into <#{destination.id}>" + (f"\nFailed: {failed}" if failed else "")))

    @p_drag.command(name="from")
    async def p_drag_from(ctx, source: discord.VoiceChannel, destination: discord.VoiceChannel):
        from utils.admin_access import is_admin as _is_admin_role
        if not (_staff(ctx) or _is_admin_role(str(ctx.guild.id), ctx.author)): return await _deny(ctx)
        moved = failed = 0
        for m in source.members:
            try: await m.move_to(destination); moved += 1
            except Exception: failed += 1
        await ctx.reply(embed=success_embed("🔁 Drag complete", f"Moved **{moved}** from <#{source.id}> → <#{destination.id}>" + (f"\nFailed: {failed}" if failed else "")))

    @p_drag.command(name="user")
    async def p_drag_user(ctx, user: discord.Member, destination: discord.VoiceChannel):
        from utils.admin_access import is_admin as _is_admin_role
        if not (_staff(ctx) or _is_admin_role(str(ctx.guild.id), ctx.author)): return await _deny(ctx)
        if not user.voice or not user.voice.channel:
            return await ctx.reply(embed=error_embed("User not in voice", f"<@{user.id}> isn't in any voice channel right now."))
        try:
            await user.move_to(destination)
            await ctx.reply(embed=success_embed("🔁 Moved", f"<@{user.id}> → <#{destination.id}>"))
        except Exception as err:
            await ctx.reply(embed=error_embed("Move failed", str(err)))

    # ════════════════════════ staff roles ════════════════════════
    def _admin(ctx: commands.Context) -> bool:
        return ctx.author.guild_permissions.administrator or ctx.author.id in bot.owner_ids

    async def _deny_admin(ctx: commands.Context):
        await ctx.reply(embed=error_embed("Admin only", "Only server Administrators can use this command."))

    _safe_remove("staff")

    @bot.group(name="staff", invoke_without_command=True)
    async def p_staff(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed("Usage", "`staff add @role` • `staff remove @role` • `staff list`"))

    @p_staff.command(name="add")
    async def p_staff_add(ctx, role: discord.Role):
        if not _admin(ctx): return await _deny_admin(ctx)
        cfg = get_guild(str(ctx.guild.id)); cfg.setdefault("staffRoleIds", [])
        if str(role.id) in cfg["staffRoleIds"]:
            return await ctx.reply(embed=error_embed("Already added", f"<@&{role.id}> is already a staff role."))
        cfg["staffRoleIds"].append(str(role.id)); persist()
        await ctx.reply(embed=success_embed("Staff role added", f"Members with <@&{role.id}> can now use bot commands."))

    @p_staff.command(name="remove")
    async def p_staff_remove(ctx, role: discord.Role):
        if not _admin(ctx): return await _deny_admin(ctx)
        cfg = get_guild(str(ctx.guild.id)); cfg.setdefault("staffRoleIds", [])
        if str(role.id) not in cfg["staffRoleIds"]:
            return await ctx.reply(embed=error_embed("Not a staff role"))
        cfg["staffRoleIds"].remove(str(role.id)); persist()
        await ctx.reply(embed=success_embed("Staff role removed", f"<@&{role.id}> removed."))

    @p_staff.command(name="list")
    async def p_staff_list(ctx):
        if not _staff(ctx): return await _deny(ctx)
        cfg = get_guild(str(ctx.guild.id)); ids = cfg.get("staffRoleIds") or []
        lst = "\n".join(f"• <@&{r}>" for r in ids) if ids else "*(none — only Administrators can use the bot)*"
        e = brand_embed(); e.title = "👮 Staff Roles"
        e.description = f"Members in any of these roles (and Administrators) can use bot commands:\n\n{lst}"
        await ctx.reply(embed=e)

    # ════════════════════════ admin roles (owner-only management) ════════════════════════
    _safe_remove("adminrole")

    @bot.group(name="adminrole", aliases=["adminaccess"], invoke_without_command=True)
    async def p_adminrole(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        await ctx.reply(embed=info_embed(
            "🔑 Admin Role",
            "`adminrole add @role` • `adminrole remove @role` • `adminrole list`\n\n"
            "Admin roles get elevated access to:\n"
            "• 📜 Recruitment Panel\n• 🎉 Giveaways\n• 🎙️ Voice Module (drag)\n• 🖼️ Embed"
        ))

    @p_adminrole.command(name="add")
    async def p_adminrole_add(ctx, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        from utils.admin_access import add_admin_role
        add_admin_role(str(ctx.guild.id), str(role.id))
        await ctx.reply(embed=success_embed("Admin role added", f"<@&{role.id}> now has admin module access (Recruitment Panel, Giveaways, Voice, Embed)."))

    @p_adminrole.command(name="remove")
    async def p_adminrole_remove(ctx, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        from utils.admin_access import remove_admin_role
        remove_admin_role(str(ctx.guild.id), str(role.id))
        await ctx.reply(embed=success_embed("Admin role removed", f"<@&{role.id}> no longer has admin module access."))

    @p_adminrole.command(name="list")
    async def p_adminrole_list(ctx):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        from utils.admin_access import get_admin_roles
        role_ids = get_admin_roles(str(ctx.guild.id))
        lst = "\n".join(f"• <@&{r}>" for r in role_ids) if role_ids else "*(none)*"
        e = brand_embed()
        e.title = "🔑 Admin Roles"
        e.description = f"Modules: Recruitment Panel • Giveaways • Voice Module • Embed\n\n{lst}"
        await ctx.reply(embed=e)

    # ════════════════════════ memberinfo / roleinfo ════════════════════════
    _safe_remove("memberinfo", "roleinfo")

    @bot.command(name="memberinfo", aliases=["minfo", "whois"])
    async def p_memberinfo(ctx, user: Optional[discord.Member] = None):
        if not _staff(ctx): return await _deny(ctx)
        m = user or ctx.author
        roles = [f"<@&{r.id}>" for r in sorted([r for r in m.roles if r.id != m.guild.id], key=lambda x: -x.position)][:20]
        e = brand_embed(); e.title = f"👤 {m}"
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="🆔 ID", value=f"`{m.id}`", inline=True)
        e.add_field(name="📅 Joined", value=f"<t:{int(m.joined_at.timestamp())}:R>" if m.joined_at else "unknown", inline=True)
        e.add_field(name="📅 Created", value=f"<t:{int(m.created_at.timestamp())}:R>", inline=True)
        e.add_field(name="🤖 Bot", value="Yes" if m.bot else "No", inline=True)
        e.add_field(name="🎭 Top Role", value=f"<@&{m.top_role.id}>" if m.top_role else "—", inline=True)
        e.add_field(name=f"🎭 Roles ({len(m.roles)-1})", value=" ".join(roles) or "*(none)*", inline=False)
        await ctx.reply(embed=e)

    @bot.command(name="roleinfo", aliases=["rinfo"])
    async def p_roleinfo(ctx, *, role: discord.Role):
        if not _staff(ctx): return await _deny(ctx)
        e = brand_embed(); e.title = f"🎭 {role.name}"
        if role.color.value: e.color = role.color
        e.add_field(name="🆔 ID", value=f"`{role.id}`", inline=True)
        e.add_field(name="🎨 Color", value=f"`#{role.color.value:06x}`", inline=True)
        e.add_field(name="📅 Created", value=f"<t:{int(role.created_at.timestamp())}:R>", inline=True)
        e.add_field(name="👥 Members", value=str(len(role.members)), inline=True)
        e.add_field(name="📍 Position", value=str(role.position), inline=True)
        e.add_field(name="🔝 Hoisted", value="Yes" if role.hoist else "No", inline=True)
        e.add_field(name="🔔 Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        e.add_field(name="🤖 Managed", value="Yes" if role.managed else "No", inline=True)
        await ctx.reply(embed=e)

    # ════════════════════════ giveaway ════════════════════════
    _safe_remove("gstart", "gend", "greroll", "gpause", "gunpause", "gedit", "gcancel", "glist")

    def _gaw_staff(ctx: commands.Context) -> bool:
        from utils.admin_access import is_admin as _is_admin_role
        from config import OWNER_IDS as _OWNER_IDS
        if ctx.author.id in _OWNER_IDS:
            return True
        if _is_admin_role(str(ctx.guild.id), ctx.author):
            return True
        guild_id = str(ctx.guild.id)
        staff_role_id = bot.staff_roles.get(guild_id)
        if not staff_role_id:
            return ctx.author.guild_permissions.administrator
        return staff_role_id in [r.id for r in ctx.author.roles] or ctx.author.guild_permissions.administrator

    async def _gaw_deny(ctx):
        await ctx.reply(embed=error_embed("Staff only", "You need the staff role to manage giveaways."))

    @bot.command(name="gstart")
    async def p_gstart(ctx, channel: discord.TextChannel, duration: str, winners: int, *, prize: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import parse_duration, now_ts, load_data, save_data, DECORATION_EMOJI, REACTION_EMOJI, THUMBNAIL_PATH, BANNER_PATH
        seconds = parse_duration(duration)
        if not seconds:
            return await ctx.reply(embed=error_embed("Invalid duration", "Use formats like `10m`, `1h`, `2d`."))
        end_ts = now_ts() + seconds
        embed = discord.Embed(
            title=f"{DECORATION_EMOJI} Giveaway Started!",
            description=(f"**Prize:** {prize}\n**Winners:** {winners}\n**Ends:** <t:{end_ts}:R> • <t:{end_ts}:f>\n\nReact with {REACTION_EMOJI} to enter!"),
            color=discord.Color.purple())
        embed.set_footer(text=f"Hosted by {ctx.author}")
        try:
            files = [discord.File(THUMBNAIL_PATH, filename="tslogo.png"), discord.File(BANNER_PATH, filename="banner.gif")]
            embed.set_thumbnail(url="attachment://tslogo.png")
            embed.set_image(url="attachment://banner.gif")
            msg = await channel.send(embed=embed, files=files)
        except Exception:
            msg = await channel.send(embed=embed)
        try: await msg.add_reaction(REACTION_EMOJI)
        except Exception: pass
        data = load_data()
        data.setdefault(str(ctx.guild.id), {})[str(msg.id)] = {
            "channel_id": str(channel.id), "end_ts": int(end_ts), "prize": prize,
            "winners": int(winners), "host_id": str(ctx.author.id), "status": "active", "paused_remaining": None}
        save_data(data)
        await ctx.reply(embed=success_embed(f"{DECORATION_EMOJI} Giveaway started!", f"Posted in {channel.mention}"))

    @bot.command(name="gend")
    async def p_gend(ctx, message_id: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, now_ts
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") not in ("active", "paused"):
            return await ctx.reply(embed=error_embed("Not found", "No active giveaway with that message ID."))
        g["end_ts"] = now_ts(); g["status"] = "active"; save_data(data)
        await ctx.reply(embed=success_embed("Giveaway ending soon"))

    @bot.command(name="greroll")
    async def p_greroll(ctx, message_id: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, DECORATION_EMOJI, REACTION_EMOJI
        import random
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") != "ended":
            return await ctx.reply(embed=error_embed("Not ended", "Giveaway must be ended to reroll."))
        channel = bot.get_channel(int(g["channel_id"]))
        if not channel: return await ctx.reply(embed=error_embed("Channel not found"))
        try: msg = await channel.fetch_message(int(message_id))
        except discord.NotFound: return await ctx.reply(embed=error_embed("Message not found"))
        participants = []
        for reaction in msg.reactions:
            if str(reaction.emoji) == REACTION_EMOJI:
                participants = [u async for u in reaction.users() if not u.bot]; break
        if not participants: return await ctx.reply(embed=error_embed("No participants"))
        winners = random.sample(participants, min(len(participants), int(g["winners"])))
        await channel.send(embed=discord.Embed(
            title=f"{DECORATION_EMOJI} Giveaway Reroll!",
            description=f"New winner(s): {', '.join(w.mention for w in winners)} for **{g['prize']}**.",
            color=discord.Color.purple()))
        await ctx.reply(embed=success_embed("Rerolled!"))

    @bot.command(name="gpause")
    async def p_gpause(ctx, message_id: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, now_ts
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") != "active":
            return await ctx.reply(embed=error_embed("Not active"))
        g["paused_remaining"] = max(0, int(g["end_ts"]) - now_ts()); g["status"] = "paused"; save_data(data)
        await ctx.reply(embed=success_embed("Giveaway paused"))

    @bot.command(name="gunpause")
    async def p_gunpause(ctx, message_id: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, now_ts
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") != "paused":
            return await ctx.reply(embed=error_embed("Not paused"))
        rem = g.get("paused_remaining") or 0
        g["end_ts"] = now_ts() + (rem if rem > 0 else 5); g["status"] = "active"; g["paused_remaining"] = None; save_data(data)
        await ctx.reply(embed=success_embed("Giveaway resumed"))

    @bot.command(name="gedit")
    async def p_gedit(ctx, message_id: str, *, changes: str = ""):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, now_ts, parse_duration
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") not in ("active", "paused"):
            return await ctx.reply(embed=error_embed("Cannot edit", "Giveaway not found or already ended."))
        await ctx.reply(embed=info_embed("Use /gedit", "For full editing options (prize, winners, duration) please use the slash command `/gedit`."))

    @bot.command(name="gcancel")
    async def p_gcancel(ctx, message_id: str):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, save_data, DECORATION_EMOJI
        data = load_data()
        g = data.get(str(ctx.guild.id), {}).get(message_id)
        if not g or g.get("status") in ("ended", "cancelled"):
            return await ctx.reply(embed=error_embed("Not found or already ended"))
        g["status"] = "cancelled"; save_data(data)
        try:
            channel = bot.get_channel(int(g["channel_id"]))
            await channel.send(embed=discord.Embed(
                title=f"{DECORATION_EMOJI} Giveaway Cancelled",
                description=f"Prize **{g['prize']}** has been cancelled.",
                color=discord.Color.purple()))
        except Exception: pass
        await ctx.reply(embed=success_embed("Giveaway cancelled"))

    @bot.command(name="glist")
    async def p_glist(ctx):
        if not _gaw_staff(ctx): return await _gaw_deny(ctx)
        from cogs.giveaway import load_data, DECORATION_EMOJI
        data = load_data()
        active = {mid: g for mid, g in data.get(str(ctx.guild.id), {}).items() if g.get("status") in ("active", "paused")}
        if not active:
            return await ctx.reply(embed=info_embed("No active giveaways", "Nothing running right now."))
        embed = discord.Embed(title="Active Giveaways", color=discord.Color.purple())
        for mid, g in active.items():
            status = g.get("status", "active")
            ends_str = f"Paused • {g.get('paused_remaining', 0)}s left" if status == "paused" else f"<t:{int(g['end_ts'])}:R>"
            embed.add_field(name=f"{DECORATION_EMOJI} {g['prize']}", value=f"Status: **{status}**\nID: `{mid}`\nEnds: {ends_str}", inline=False)
        await ctx.reply(embed=embed)

    # ════════════════════════ stats ════════════════════════
    _safe_remove("stats")

    @bot.command(name="stats")
    async def p_stats(ctx):
        if not _staff(ctx): return await _deny(ctx)
        import platform, sys, time as _time
        e = brand_embed(); e.title = "📊 Bot Statistics"
        guilds = len(bot.guilds)
        members = sum(g.member_count or 0 for g in bot.guilds)
        e.add_field(name="🌐 Servers", value=str(guilds), inline=True)
        e.add_field(name="👥 Users", value=str(members), inline=True)
        e.add_field(name="📡 Latency", value=f"{round(bot.latency * 1000)}ms", inline=True)
        e.add_field(name="🐍 Python", value=platform.python_version(), inline=True)
        e.add_field(name="📦 discord.py", value=discord.__version__, inline=True)
        await ctx.reply(embed=e)

    # ════════════════════════ afk ════════════════════════
    _safe_remove("afk")

    @bot.command(name="afk")
    async def p_afk(ctx, *, reason: str = "AFK"):
        from cogs.afk import AfkCog
        cog = bot.cogs.get("AfkCog")
        if cog:
            class _FakeInter:
                user = ctx.author
                guild = ctx.guild
                async def response_send(self, **kwargs):
                    await ctx.reply(**kwargs)
            # Just write the AFK directly
            import json, os
            AFK_FILE = "database/afk.json"
            try:
                with open(AFK_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}
            from datetime import datetime, timezone
            data[str(ctx.author.id)] = {"reason": reason, "timestamp": datetime.now(timezone.utc).isoformat(), "guild": str(ctx.guild.id)}
            os.makedirs("database", exist_ok=True)
            with open(AFK_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
            e = brand_embed(); e.title = "💤 AFK Set"
            e.description = f"<@{ctx.author.id}> is now AFK\n**Reason:** {reason}"
            await ctx.reply(embed=e)
        else:
            await ctx.reply(embed=error_embed("AFK system unavailable", "The AFK cog is not loaded."))

    # ════════════════════════ owner ping warn ════════════════════════
    _safe_remove("ownerpingwarn", "owneraddrole", "ownerchangerole")

    @bot.command(name="ownerpingwarn")
    async def p_ownerpingwarn(ctx, switch: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        import json, os
        DATA_FILE = "database/pingwarn.json"
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f: data = json.load(f)
        except Exception:
            data = {}
        guild_id = str(ctx.guild.id)
        data.setdefault(guild_id, {})
        en = switch.lower() in ("on", "enable", "true", "yes")
        data[guild_id]["enabled"] = en
        os.makedirs("database", exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        await ctx.reply(embed=success_embed(f"Owner ping warning {'enabled' if en else 'disabled'}"))

    @bot.command(name="owneraddrole")
    async def p_owneraddrole(ctx, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        import json, os
        DATA_FILE = "database/owner_roles.json"
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f: data = json.load(f)
        except Exception:
            data = {}
        guild_id = str(ctx.guild.id)
        data[guild_id] = str(role.id)
        os.makedirs("database", exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        await ctx.reply(embed=success_embed("Owner role set", f"<@&{role.id}> is now the owner role."))

    @bot.command(name="ownerchangerole")
    async def p_ownerchangerole(ctx, user: discord.Member, role: discord.Role):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        try:
            await user.add_roles(role, reason=f"Owner role assigned by {ctx.author}")
            await ctx.reply(embed=success_embed("Role assigned", f"<@&{role.id}> given to <@{user.id}>"))
        except Exception as err:
            await ctx.reply(embed=error_embed("Failed", str(err)))

    # ════════════════════════ remind ════════════════════════
    _safe_remove("remind")

    @bot.command(name="remind")
    async def p_remind(ctx, user: discord.Member):
        if not _staff(ctx): return await _deny(ctx)
        try:
            e = brand_embed()
            e.title = "🔔 Ticket Reminder"
            e.description = (
                f"Hey <@{user.id}>! 👋\n\n"
                "You have an **open ticket** waiting for your response.\n"
                f"Please check <#{ctx.channel.id}> and reply at your earliest convenience.\n\n"
                f"**Server:** {ctx.guild.name}"
            )
            await user.send(embed=e)
            await ctx.reply(embed=success_embed("✅ Reminder sent", f"DM sent to <@{user.id}>."))
        except discord.Forbidden:
            await ctx.reply(embed=error_embed("Cannot DM", f"<@{user.id}> has DMs disabled."))
        except Exception as err:
            await ctx.reply(embed=error_embed("Failed", str(err)))

    # ════════════════════════ embed ════════════════════════
    # ════════════════════════ apptoggle ════════════════════════
    _safe_remove("apptoggle")

    @bot.command(name="apptoggle")
    async def p_apptoggle(ctx):
        import json as _j
        _or_file = "database/owner_roles.json"
        try:
            with open(_or_file, "r", encoding="utf-8") as _f: _or_data = _j.load(_f)
        except Exception:
            _or_data = {}
        _or_id = _or_data.get(str(ctx.guild.id))
        _or_role = ctx.guild.get_role(int(_or_id)) if _or_id else None
        _has_owner_role = _or_role and _or_role in ctx.author.roles
        if not _has_owner_role:
            return await ctx.reply(embed=error_embed("Owner Role only", "Only the designated owner role can toggle applications." + (" Set it with `!owneraddrole @role`." if not _or_id else "")))
        from store import get_guild, persist
        cfg = get_guild(str(ctx.guild.id))
        current = cfg.get("recruitmentOpen", True)
        new_state = not current
        cfg["recruitmentOpen"] = new_state
        persist()
        status_str = "🟢 Open" if new_state else "🔴 Closed"
        await ctx.reply(embed=success_embed("Applications toggled", f"Applications are now **{status_str}**."))

    _safe_remove("embed")

    @bot.command(name="embed")
    async def p_embed(ctx, *, content: str):
        from utils.admin_access import is_admin as _is_admin_role
        from config import OWNER_IDS as _OWNER_IDS
        if not (ctx.author.guild_permissions.administrator or ctx.author == ctx.guild.owner
                or ctx.author.id in _OWNER_IDS or _is_admin_role(str(ctx.guild.id), ctx.author)):
            return await ctx.reply(embed=error_embed("No access", "Only Administrators or members with an admin role can create embeds."))
        # Format: "title | description | color(optional)"
        parts = [p.strip() for p in content.split("|")]
        title = parts[0] if len(parts) > 0 else "Embed"
        description = parts[1].replace("\\n", "\n") if len(parts) > 1 else ""
        color_str = parts[2] if len(parts) > 2 else None
        color = BRAND["color"]
        if color_str:
            try: color = int(color_str.strip().lstrip("#"), 16)
            except Exception: pass
        e = discord.Embed(title=title, description=description, color=color)
        e.set_footer(text=ctx.guild.name)
        try:
            await ctx.message.delete()
        except Exception:
            pass
        await ctx.send(embed=e)

    # ════════════════════════ calculator (public — single expression) ════════════════════════
    _safe_remove("calc", "add", "sub", "mul", "div")

    from cogs.calculator import _safe_calc as _calc_eval, _make_embed as _calc_make_embed

    @bot.command(name="calc", aliases=["calculate"])
    async def p_calc(ctx, *, expression: str):
        """Calculate any math expression. Example: !calc 100 + 50 * 2 - 30 / 3"""
        try:
            result, ops = _calc_eval(expression)
        except ZeroDivisionError as e:
            return await ctx.reply(embed=discord.Embed(title="❌ Division by Zero", description=str(e), color=0xef4444))
        except Exception as e:
            return await ctx.reply(embed=discord.Embed(title="❌ Invalid Expression", description=str(e), color=0xef4444))
        await ctx.reply(embed=_calc_make_embed(expression, result, ops))

    # ════════════════════════ autoresponder (staff only) ════════════════════════
    from utils.file_handler import load_json as _ar_load_json, save_json as _ar_save_json
    _AR_FILE_PF = "database/autoresponder.json"

    def _ar_load_pf():
        return _ar_load_json(_AR_FILE_PF)

    def _ar_save_pf(data):
        _ar_save_json(_AR_FILE_PF, data)

    _safe_remove("ar")

    @bot.group(name="ar", invoke_without_command=True)
    async def p_ar(ctx):
        if not _staff(ctx): return await _deny(ctx)
        await ctx.reply(embed=info_embed(
            "Autoresponder",
            "`!ar add <trigger> | <response>` — add text response\n"
            "`!ar addembed <trigger> | <title> | <desc> [| <color> | <image_url> | <thumb_url>]` — add embed response\n"
            "`!ar remove <trigger>` — remove response\n"
            "`!ar list` — list all guild responses\n"
            "`!ar setrole <trigger> @role` — restrict trigger to a role"
        ))

    @p_ar.command(name="add")
    async def p_ar_add(ctx, *, content: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        if "|" not in content:
            return await ctx.reply(embed=error_embed("Usage", "`!ar add <trigger> | <response>`"))
        trigger, response = content.split("|", 1)
        trigger = trigger.strip().lower()
        response = response.strip().replace("\\n", "\n")
        data = _ar_load_pf()
        data.setdefault(str(ctx.guild.id), {})[trigger] = {"type": "text", "response": response, "role_id": None}
        _ar_save_pf(data)
        await ctx.reply(embed=success_embed("Autoresponder added", f"Trigger: `{trigger}`"))

    @p_ar.command(name="addembed")
    async def p_ar_addembed(ctx, *, content: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        parts = [p.strip() for p in content.split("|")]
        if len(parts) < 3:
            return await ctx.reply(embed=error_embed(
                "Usage",
                "`!ar addembed <trigger> | <title> | <description> [| <color_hex> | <image_url> | <thumbnail_url>]`"
            ))
        trigger     = parts[0].lower()
        title       = parts[1]
        description = parts[2].replace("\\n", "\n")
        try:
            color = int(parts[3].lstrip("#"), 16) if len(parts) > 3 and parts[3] else 0x9b59b6
        except Exception:
            color = 0x9b59b6
        image     = parts[4] if len(parts) > 4 and parts[4] else None
        thumbnail = parts[5] if len(parts) > 5 and parts[5] else None
        data = _ar_load_pf()
        data.setdefault(str(ctx.guild.id), {})[trigger] = {
            "type": "embed",
            "embed": {
                "title": title,
                "description": description,
                "color": color,
                "image": image,
                "thumbnail": thumbnail,
            },
            "role_id": None,
        }
        _ar_save_pf(data)
        preview = discord.Embed(title=title, description=description, color=color)
        if image:
            preview.set_image(url=image)
        if thumbnail:
            preview.set_thumbnail(url=thumbnail)
        preview.set_footer(text=f"Trigger: {trigger}")
        await ctx.reply(embeds=[
            discord.Embed(title="✅ Embed autoresponder added", description=f"Trigger: `{trigger}`", color=0x22c55e),
            preview,
        ])

    @p_ar.command(name="remove")
    async def p_ar_remove(ctx, *, trigger: str):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        data = _ar_load_pf()
        guild_data = data.get(str(ctx.guild.id), {})
        key = trigger.strip().lower()
        if key not in guild_data:
            return await ctx.reply(embed=error_embed("Not found", f"No autoresponse for `{key}`."))
        del guild_data[key]
        _ar_save_pf(data)
        await ctx.reply(embed=success_embed("Removed", f"Deleted autoresponse for `{key}`."))

    @p_ar.command(name="list")
    async def p_ar_list(ctx):
        if not _staff(ctx): return await _deny(ctx)
        data = _ar_load_pf()
        guild_data = data.get(str(ctx.guild.id), {})
        if not guild_data:
            return await ctx.reply(embed=info_embed("Autoresponder", "No autoresponses configured for this server."))
        e = brand_embed()
        e.title = "📋 Guild Autoresponses"
        e.set_footer(text=f"{len(guild_data)} total")
        for key, val in list(guild_data.items())[:20]:
            role_str = f"<@&{val['role_id']}>" if val.get("role_id") else "Everyone"
            type_str = val.get("type", "text").title()
            has_img  = " 🖼️" if val.get("type") == "embed" and val.get("embed", {}).get("image") else ""
            has_thm  = " 🔲" if val.get("type") == "embed" and val.get("embed", {}).get("thumbnail") else ""
            e.add_field(name=f"`{key}`", value=f"**{type_str}**{has_img}{has_thm} | Role: {role_str}", inline=False)
        await ctx.reply(embed=e)

    @p_ar.command(name="setrole")
    async def p_ar_setrole(ctx, trigger: str, role: discord.Role = None):
        if not _owner(ctx): return await _deny_owner_ctx(ctx)
        data = _ar_load_pf()
        guild_data = data.setdefault(str(ctx.guild.id), {})
        key = trigger.strip().lower()
        if key not in guild_data:
            return await ctx.reply(embed=error_embed("Not found", f"No autoresponse for `{key}`."))
        guild_data[key]["role_id"] = str(role.id) if role else None
        _ar_save_pf(data)
        role_str = role.mention if role else "Everyone (cleared)"
        await ctx.reply(embed=success_embed("Role updated", f"Trigger `{key}` → {role_str}"))
