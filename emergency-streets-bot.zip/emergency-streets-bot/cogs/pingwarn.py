import discord, json, time
from discord.ext import commands
from discord import app_commands
from utils.file_handler import load_json, save_json

PINGWARN_FILE = "database/pingwarn.json"
OWNER_ROLE_FILE = "database/owner_roles.json"
CONFIG_FILE = "config.json"


class PingWarn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ping_tracker = {}  # {guild_id: {author_id: [timestamps]}}

    def is_owner(self, user_id: int) -> bool:
        """Check if a user is a bot owner (multiple owners supported)."""
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            return str(user_id) in data.get("owner_ids", [])
        except Exception as e:
            print(f"[ERROR] Failed to read config: {e}")
            return False

    @app_commands.command(name="ownerpingwarn", description="Toggle owner ping warning")
    @app_commands.choices(status=[
        app_commands.Choice(name="Enable", value="on"),
        app_commands.Choice(name="Disable", value="off")
    ])
    async def ownerpingwarn(self, interaction: discord.Interaction, status: app_commands.Choice[str]):
        """Enable or disable owner ping warning for this server."""
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message(
                "❌ Only the bot owner can use this command.", ephemeral=True
            )

        guild_id = str(interaction.guild.id)
        try:
            data = load_json(PINGWARN_FILE)
            if data.get(guild_id) == status.value:
                return await interaction.response.send_message(
                    f"ℹ️ Owner ping warning is already `{status.value}`.", ephemeral=True
                )

            data[guild_id] = status.value
            save_json(PINGWARN_FILE, data)
            await interaction.response.send_message(
                f"🔔 Owner ping warning is now `{status.value}`.", ephemeral=True
            )
        except Exception as e:
            print(f"[ERROR] Failed to toggle ping warning: {e}")
            await interaction.response.send_message("❌ Something went wrong.", ephemeral=True)

    @app_commands.command(name="owneraddrole", description="Set the owner role for this server")
    @app_commands.describe(role="Select the role to assign as 'owner'")
    async def owner_add_role(self, interaction: discord.Interaction, role: discord.Role):
        """Save a role as the server's owner role."""
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message(
                "❌ Only the bot owner can use this command.", ephemeral=True
            )

        guild_id = str(interaction.guild.id)
        try:
            data = load_json(OWNER_ROLE_FILE)
            if data.get(guild_id) == role.id:
                return await interaction.response.send_message(
                    f"ℹ️ `{role.name}` is already set as the owner role.", ephemeral=True
                )

            data[guild_id] = role.id
            save_json(OWNER_ROLE_FILE, data)
            await interaction.response.send_message(
                f"✅ Owner role for this server is now `{role.name}`.", ephemeral=True
            )
        except Exception as e:
            print(f"[ERROR] Failed to set owner role: {e}")
            await interaction.response.send_message("❌ Something went wrong.", ephemeral=True)

    @app_commands.command(name="ownerchangerole", description="Assign the owner role to a member")
    @app_commands.describe(user="User to assign the role to", role="Owner role to give")
    async def owner_change_role(self, interaction: discord.Interaction, user: discord.Member, role: discord.Role):
        """Assign the configured owner role to a member."""
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message(
                "❌ Only the bot owner can use this command.", ephemeral=True
            )

        try:
            if role in user.roles:
                return await interaction.response.send_message(
                    f"ℹ️ {user.mention} already has the `{role.name}` role.", ephemeral=True
                )

            await user.add_roles(role)
            await interaction.response.send_message(
                f"✅ `{role.name}` role given to {user.mention}.", ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to assign that role.", ephemeral=True)
        except Exception as e:
            print(f"[ERROR] Failed to assign role: {e}")
            await interaction.response.send_message("❌ Something went wrong.", ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Track and warn if someone spam-pings the server owner."""
        if message.author.bot or not message.guild:
            return

        # Ignore replies to the bot's own message
        if message.reference and message.reference.resolved:
            if getattr(message.reference.resolved, "author", None) == self.bot.user:
                return

        # Skip if another bot already warned recently
        try:
            async for msg in message.channel.history(limit=5):
                if msg.author.bot and "please don’t spam ping the server owner" in msg.content.lower():
                    return
        except (discord.errors.NotFound, discord.errors.Forbidden):
            return

        guild_id = str(message.guild.id)
        author_id = message.author.id

        # Check if ping warning is enabled
        warn_data = load_json(PINGWARN_FILE)
        if warn_data.get(guild_id) != "on":
            return

        # Load owner role
        role_data = load_json(OWNER_ROLE_FILE)
        owner_role_id = role_data.get(guild_id)
        if not owner_role_id:
            return

        owner_role = message.guild.get_role(owner_role_id)
        if not owner_role:
            return

        # Check if any mentioned user has the owner role
        if not any(owner_role in m.roles for m in message.mentions):
            return

        # Track pings in last 60 seconds
        now = time.time()
        self.ping_tracker.setdefault(guild_id, {}).setdefault(author_id, [])
        self.ping_tracker[guild_id][author_id] = [
            t for t in self.ping_tracker[guild_id][author_id] if now - t < 60
        ]
        self.ping_tracker[guild_id][author_id].append(now)

        # Warn if pinged 3+ times in 60 seconds
        if len(self.ping_tracker[guild_id][author_id]) >= 3:
            await message.channel.send(
                f"⚠️ {message.author.mention}, please don’t spam ping the server owner!"
            )
            self.ping_tracker[guild_id][author_id].clear()


async def setup(bot):
    await bot.add_cog(PingWarn(bot))
