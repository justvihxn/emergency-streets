"""
Moderation System — warnings, cases, kick/ban/mute/timeout, purge, lockdown,
slowmode, nickname reset.

Uses per-guild JSON store for moderation cases. Every action creates a
case with a permanent, searchable case ID.

Slash commands
--------------
/warn      — warn a member (creates a case)
/warnings  — view warnings history of a member
/clearwarns — clear warnings for a member
/kick      — kick a member
/ban       — ban a member (with optional message purge days)
/unban     — unban a member by ID
/mute      — timeout a member for N minutes
/unmute    — remove timeout
/purge     — bulk delete messages (with optional user filter)
/slowmode  — set channel slowmode
/lockdown  — lock a channel for @everyone
/unlock    — reverse a lockdown
/nick      — set / reset a member's nickname
/case      — look up a moderation case by ID
/modstats  — top moderators, case counts
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.pretty import (
    ok, err, warn, info, brand, Paginator, build_pages,
    BRAND_COLOR, SUCCESS_COLOR, WARN_COLOR, ERROR_COLOR,
)


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)
MOD_PATH = DATA_DIR / "moderation.json"


# ─────────────────── store ───────────────────
class _ModStore:
    def __init__(self, path: Path):
        self.path = path
        self._lock = asyncio.Lock()
        if not path.exists():
            path.write_text(json.dumps({"cases": {}, "counter": 0}))

    async def read(self):
        async with self._lock:
            try:
                return json.loads(self.path.read_text() or "{}") or {"cases": {}, "counter": 0}
            except Exception:
                return {"cases": {}, "counter": 0}

    async def write(self, data):
        async with self._lock:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2, default=str))
            tmp.replace(self.path)

    async def next_case_id(self) -> int:
        async with self._lock:
            data = json.loads(self.path.read_text() or "{}") or {"cases": {}, "counter": 0}
            data["counter"] = int(data.get("counter", 0)) + 1
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2, default=str))
            tmp.replace(self.path)
            return data["counter"]


store = _ModStore(MOD_PATH)


ACTION_STYLES = {
    "warn":     ("⚠️", WARN_COLOR),
    "kick":     ("👢", 0xf97316),
    "ban":      ("🔨", ERROR_COLOR),
    "unban":    ("🔓", SUCCESS_COLOR),
    "mute":     ("🔇", 0x64748b),
    "unmute":   ("🔊", SUCCESS_COLOR),
    "clearwarns": ("🧹", SUCCESS_COLOR),
    "nick":     ("📝", BRAND_COLOR),
}


async def _create_case(guild_id: int, moderator: discord.Member,
                       target: discord.abc.User, action: str,
                       reason: str) -> dict:
    cid = await store.next_case_id()
    data = await store.read()
    case = {
        "id": cid,
        "guild_id": guild_id,
        "moderator_id": moderator.id,
        "target_id": target.id,
        "action": action,
        "reason": reason or "No reason provided.",
        "ts": time.time(),
    }
    data["cases"][str(cid)] = case
    await store.write(data)
    return case


def _case_embed(c: dict) -> discord.Embed:
    emoji, color = ACTION_STYLES.get(c["action"], ("🗒️", BRAND_COLOR))
    e = discord.Embed(
        title=f"{emoji} Case #{c['id']}  •  {c['action'].upper()}",
        color=color, timestamp=datetime.fromtimestamp(c.get("ts", time.time()), timezone.utc),
    )
    e.add_field(name="👤 Target",    value=f"<@{c['target_id']}> (`{c['target_id']}`)", inline=False)
    e.add_field(name="🛡️ Moderator", value=f"<@{c['moderator_id']}>", inline=True)
    e.add_field(name="📝 Reason",     value=c.get("reason", "—"), inline=False)
    e.set_footer(text="Emergency Streets • Moderation")
    return e


_DURATION_RE = re.compile(r"^\s*(\d+)\s*([smhdw]?)\s*$", re.IGNORECASE)


def _parse_duration(s: str, default_unit: str = "m") -> Optional[int]:
    """Return duration in seconds."""
    m = _DURATION_RE.match(s or "")
    if not m:
        return None
    n = int(m.group(1))
    u = (m.group(2) or default_unit).lower()
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[u]


# ─────────────────── Cog ───────────────────
class Moderation(commands.Cog):
    """Moderation commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # /warn
    @app_commands.command(name="warn", description="Warn a member and record a case.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def warn_cmd(self, interaction: discord.Interaction,
                       member: discord.Member, reason: str = ""):
        if member.bot or member.id == interaction.user.id:
            return await interaction.response.send_message(embed=err("Invalid target"), ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, member, "warn", reason)
        # DM the warned user
        try:
            e = discord.Embed(
                title=f"⚠️ You were warned in {interaction.guild.name}",
                description=f"**Reason:** {reason or 'No reason provided.'}\n**Case:** `#{case['id']}`",
                color=WARN_COLOR,
            )
            await member.send(embed=e)
        except Exception:
            pass
        await interaction.response.send_message(embed=_case_embed(case))

    # /warnings
    @app_commands.command(name="warnings",
                          description="Show all warnings for a member.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def warnings_cmd(self, interaction: discord.Interaction, member: discord.Member):
        data = await store.read()
        cases = [c for c in data["cases"].values()
                 if int(c.get("guild_id", 0)) == interaction.guild.id
                 and int(c.get("target_id", 0)) == member.id
                 and c.get("action") == "warn"]
        cases.sort(key=lambda c: -c.get("ts", 0))
        if not cases:
            return await interaction.response.send_message(
                embed=info("No warnings", f"{member.mention} has a clean record."),
                ephemeral=True)

        def make_page(page_items, i, total):
            e = brand(f"⚠️ Warnings — {member.display_name}",
                      f"Total: **{len(cases)}** warning(s)")
            for c in page_items:
                e.add_field(
                    name=f"Case #{c['id']}  ·  <t:{int(c['ts'])}:R>",
                    value=f"**Mod:** <@{c['moderator_id']}>\n**Reason:** {c.get('reason','—')}",
                    inline=False)
            e.set_footer(text=f"Emergency Streets • Page {i+1}/{total}")
            return e

        pages = build_pages(cases, 5, make_page)
        await interaction.response.send_message(
            embed=pages[0],
            view=Paginator(pages, author_id=interaction.user.id),
            ephemeral=True,
        )

    # /clearwarns
    @app_commands.command(name="clearwarns",
                          description="Clear all warnings for a member.")
    @app_commands.checks.has_permissions(ban_members=True)
    async def clearwarns_cmd(self, interaction: discord.Interaction, member: discord.Member,
                              reason: str = ""):
        data = await store.read()
        removed = 0
        for cid, c in list(data["cases"].items()):
            if (int(c.get("guild_id", 0)) == interaction.guild.id
                    and int(c.get("target_id", 0)) == member.id
                    and c.get("action") == "warn"):
                data["cases"].pop(cid, None)
                removed += 1
        await store.write(data)
        case = await _create_case(interaction.guild.id, interaction.user, member, "clearwarns",
                                   reason or f"Cleared {removed} warning(s)")
        await interaction.response.send_message(embed=_case_embed(case))

    # /kick
    @app_commands.command(name="kick", description="Kick a member from the server.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick_cmd(self, interaction: discord.Interaction,
                       member: discord.Member, reason: str = ""):
        if member.id == interaction.user.id or member.top_role >= interaction.user.top_role:
            return await interaction.response.send_message(
                embed=err("Not allowed", "You cannot moderate this member."), ephemeral=True)
        try:
            await member.send(embed=discord.Embed(
                title=f"👢 You were kicked from {interaction.guild.name}",
                description=f"**Reason:** {reason or 'No reason provided.'}",
                color=0xf97316,
            ))
        except Exception:
            pass
        try:
            await member.kick(reason=f"[{interaction.user}] {reason}")
        except discord.Forbidden:
            return await interaction.response.send_message(
                embed=err("Missing permission", "I can't kick that member (role hierarchy?)."),
                ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, member, "kick", reason)
        await interaction.response.send_message(embed=_case_embed(case))

    # /ban
    @app_commands.command(name="ban", description="Ban a member. Optionally purge their messages.")
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.describe(delete_message_days="Days of messages to delete (0-7)")
    async def ban_cmd(self, interaction: discord.Interaction,
                      user: discord.User, reason: str = "",
                      delete_message_days: app_commands.Range[int, 0, 7] = 0):
        member = interaction.guild.get_member(user.id)
        if member and (member.id == interaction.user.id
                       or member.top_role >= interaction.user.top_role):
            return await interaction.response.send_message(
                embed=err("Not allowed", "You cannot moderate this member."), ephemeral=True)
        try:
            if member:
                await member.send(embed=discord.Embed(
                    title=f"🔨 You were banned from {interaction.guild.name}",
                    description=f"**Reason:** {reason or 'No reason provided.'}",
                    color=ERROR_COLOR,
                ))
        except Exception:
            pass
        try:
            await interaction.guild.ban(
                user, reason=f"[{interaction.user}] {reason}",
                delete_message_days=int(delete_message_days),
            )
        except discord.Forbidden:
            return await interaction.response.send_message(
                embed=err("Missing permission", "I can't ban that user."), ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, user, "ban", reason)
        await interaction.response.send_message(embed=_case_embed(case))

    # /unban
    @app_commands.command(name="unban", description="Unban a user by ID.")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban_cmd(self, interaction: discord.Interaction, user_id: str, reason: str = ""):
        if not user_id.isdigit():
            return await interaction.response.send_message(embed=err("Invalid ID"), ephemeral=True)
        uid = int(user_id)
        try:
            user = await self.bot.fetch_user(uid)
            await interaction.guild.unban(user, reason=f"[{interaction.user}] {reason}")
        except discord.NotFound:
            return await interaction.response.send_message(embed=err("Not banned"), ephemeral=True)
        except discord.Forbidden:
            return await interaction.response.send_message(
                embed=err("Missing permission"), ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, user, "unban", reason)
        await interaction.response.send_message(embed=_case_embed(case))

    # /mute (timeout)
    @app_commands.command(name="mute", description="Timeout a member. Duration: 5m, 1h, 1d …")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mute_cmd(self, interaction: discord.Interaction, member: discord.Member,
                       duration: str, reason: str = ""):
        sec = _parse_duration(duration, "m")
        if not sec or sec < 1 or sec > 60 * 60 * 24 * 28:
            return await interaction.response.send_message(
                embed=err("Bad duration", "Use e.g. `10m`, `2h`, `1d` — max 28 days."),
                ephemeral=True)
        until = datetime.now(timezone.utc) + timedelta(seconds=sec)
        try:
            await member.timeout(until, reason=f"[{interaction.user}] {reason}")
        except discord.Forbidden:
            return await interaction.response.send_message(
                embed=err("Missing permission"), ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, member, "mute",
                                   f"{duration} — {reason}".strip(" —"))
        e = _case_embed(case)
        e.add_field(name="⏳ Duration", value=f"{duration} (until <t:{int(until.timestamp())}:R>)",
                    inline=False)
        await interaction.response.send_message(embed=e)

    # /unmute
    @app_commands.command(name="unmute", description="Remove a timeout from a member.")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def unmute_cmd(self, interaction: discord.Interaction, member: discord.Member,
                         reason: str = ""):
        try:
            await member.timeout(None, reason=f"[{interaction.user}] {reason}")
        except discord.Forbidden:
            return await interaction.response.send_message(
                embed=err("Missing permission"), ephemeral=True)
        case = await _create_case(interaction.guild.id, interaction.user, member, "unmute", reason)
        await interaction.response.send_message(embed=_case_embed(case))

    # /purge
    @app_commands.command(name="purge",
                          description="Bulk delete messages (optionally from a user).")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge_cmd(self, interaction: discord.Interaction,
                        amount: app_commands.Range[int, 1, 200],
                        user: Optional[discord.User] = None):
        await interaction.response.defer(ephemeral=True, thinking=True)

        def check(m):
            return (user is None) or (m.author.id == user.id)

        try:
            deleted = await interaction.channel.purge(limit=amount, check=check,
                                                       reason=f"Purge by {interaction.user}")
        except discord.Forbidden:
            return await interaction.followup.send(embed=err("Missing permission"), ephemeral=True)
        await interaction.followup.send(
            embed=ok(f"Purged {len(deleted)} messages",
                     f"Channel: <#{interaction.channel.id}>"
                     + (f"\nUser filter: <@{user.id}>" if user else "")),
            ephemeral=True,
        )

    # /slowmode
    @app_commands.command(name="slowmode", description="Set channel slowmode in seconds.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def slowmode_cmd(self, interaction: discord.Interaction,
                           seconds: app_commands.Range[int, 0, 21600]):
        await interaction.channel.edit(slowmode_delay=seconds,
                                        reason=f"Slowmode by {interaction.user}")
        await interaction.response.send_message(
            embed=ok("Slowmode updated", f"<#{interaction.channel.id}> → **{seconds}s**"))

    # /lockdown
    @app_commands.command(name="lockdown", description="Lock this channel for @everyone.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def lockdown_cmd(self, interaction: discord.Interaction, reason: str = ""):
        await interaction.channel.set_permissions(interaction.guild.default_role,
                                                   send_messages=False,
                                                   reason=f"Lockdown by {interaction.user}")
        await interaction.response.send_message(
            embed=warn("🔒 Channel locked", reason or "Locked by staff."))

    # /unlock
    @app_commands.command(name="unlock", description="Unlock this channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unlock_cmd(self, interaction: discord.Interaction):
        await interaction.channel.set_permissions(interaction.guild.default_role,
                                                   send_messages=None,
                                                   reason=f"Unlock by {interaction.user}")
        await interaction.response.send_message(embed=ok("🔓 Channel unlocked"))

    # /nick
    @app_commands.command(name="nick", description="Set or reset a member's nickname.")
    @app_commands.checks.has_permissions(manage_nicknames=True)
    async def nick_cmd(self, interaction: discord.Interaction,
                       member: discord.Member, new_nickname: Optional[str] = None):
        try:
            await member.edit(nick=new_nickname)
        except discord.Forbidden:
            return await interaction.response.send_message(embed=err("Missing permission"),
                                                            ephemeral=True)
        await _create_case(interaction.guild.id, interaction.user, member, "nick",
                          f"→ {new_nickname or 'reset'}")
        await interaction.response.send_message(
            embed=ok("Nickname updated",
                     f"{member.mention} → **{new_nickname or member.name}**"),
            ephemeral=True)

    # /case
    @app_commands.command(name="case", description="Look up a moderation case by ID.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def case_cmd(self, interaction: discord.Interaction, case_id: int):
        data = await store.read()
        c = data["cases"].get(str(case_id))
        if not c or int(c.get("guild_id", 0)) != interaction.guild.id:
            return await interaction.response.send_message(embed=err("No such case"),
                                                            ephemeral=True)
        await interaction.response.send_message(embed=_case_embed(c), ephemeral=True)

    # /modstats
    @app_commands.command(name="modstats", description="Server moderation activity.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def modstats_cmd(self, interaction: discord.Interaction):
        data = await store.read()
        cases = [c for c in data["cases"].values()
                 if int(c.get("guild_id", 0)) == interaction.guild.id]
        by_action: dict[str, int] = {}
        by_mod: dict[int, int] = {}
        for c in cases:
            by_action[c["action"]] = by_action.get(c["action"], 0) + 1
            by_mod[int(c["moderator_id"])] = by_mod.get(int(c["moderator_id"]), 0) + 1
        top = sorted(by_mod.items(), key=lambda kv: -kv[1])[:5]
        e = brand("🛡️ Moderation Statistics")
        e.add_field(name="📊 Total cases", value=str(len(cases)), inline=True)
        e.add_field(name="🧾 By action",
                    value="\n".join(f"• **{k}** — {v}"
                                    for k, v in sorted(by_action.items(), key=lambda kv: -kv[1]))
                    or "*none*",
                    inline=False)
        e.add_field(name="🏆 Top moderators",
                    value="\n".join(f"• <@{uid}> — {n} cases" for uid, n in top)
                    or "*none*",
                    inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
