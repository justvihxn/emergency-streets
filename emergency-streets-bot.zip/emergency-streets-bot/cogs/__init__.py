"""All slash commands + prefix command router."""
import discord
from discord import app_commands
from discord.ext import commands
import time

from config import BRAND, DEFAULT_PREFIX, OWNER_IDS
from store import (
    get_guild, persist, is_staff,
    ANTINUKE_ACTIONS, ANTINUKE_ACTION_LABELS, get_antinuke_rule, set_antinuke_rule,
    LOG_EVENTS, LOG_EVENT_LABELS, get_automod,
)
from embeds import brand_embed, success_embed, error_embed, info_embed, expand_newlines


def staff_gate(interaction: discord.Interaction, public_names=None) -> bool:
    public_names = public_names or {"help"}
    if not interaction.guild:
        return False
    name = interaction.command.qualified_name.split()[0] if interaction.command else ""
    if name in public_names:
        return True
    return is_staff(str(interaction.guild.id), interaction.user)


def owner_gate(interaction: discord.Interaction) -> bool:
    return interaction.user.id in OWNER_IDS


async def deny(interaction):
    await interaction.response.send_message(
        embed=error_embed("Staff only", "Only members with a configured **staff role** can use this command."),
        ephemeral=True,
    )


async def deny_owner(interaction):
    await interaction.response.send_message(
        embed=error_embed("Owner only", "This command is restricted to **bot owners** only."),
        ephemeral=True,
    )


PUNISHMENTS = ["quarantine", "kick", "ban", "strip", "none"]


async def register_all(bot: commands.Bot):
    tree = bot.tree

    # ─── /help ─── (premium paginated help)
    from utils.pretty import Paginator as _HelpPaginator, brand as _brand_e

    @tree.command(name="help", description="Show all available commands (paginated)")
    async def help_cmd(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        prefix = (get_guild(str(interaction.guild.id)).get("prefix") if interaction.guild else None) or DEFAULT_PREFIX

        # ── Retained feature pages ────────────────────────────
        p1 = _brand_e(
            "Emergency Streets • Command Center",
            f"Prefix: `{prefix}` · Use slash commands or the classic prefix.\n\n"
            "Community safety, support, staff operations, and giveaways.",
        )
        p1.add_field(name="🛡️ Security", value="Moderation · Antinuke · AutoMod · Logs", inline=False)
        p1.add_field(name="🎫 Support", value="Tickets · Staff applications · DM broadcasts", inline=False)
        p1.add_field(name="🎉 Community", value="Giveaways · Utilities · AFK · Autoresponder", inline=False)
        p1.set_footer(text="Emergency Streets • Bot")

        p2 = _brand_e("🛡️ Moderation & Security")
        p2.add_field(name="Cases", value="`/warn` `/warnings` `/clearwarns` `/case` `/modstats`", inline=False)
        p2.add_field(name="Enforce", value="`/kick` `/ban` `/unban` `/mute` `/unmute`", inline=False)
        p2.add_field(name="Channels", value="`/purge` `/slowmode` `/lockdown` `/unlock` `/nick`", inline=False)
        p2.add_field(name="Protection", value="`/automod ...` `/antinuke ...` `/logs ...`", inline=False)

        p3 = _brand_e("🎫 Tickets & Staff")
        p3.add_field(name="Setup", value="`/ticketpanel` `/ticketconfig` `/addticketstaff` `/removeticketstaff`", inline=False)
        p3.add_field(name="Actions", value="`/close` `/delete` `/rename` `/claim` `/unclaim` `/add` `/remove`", inline=False)
        p3.add_field(name="Tools", value="`/transcript` `/ticketpriority` `/ticketreopen` `/ticketsearch` `/ticketnote`", inline=False)
        p3.add_field(name="Staff panel", value="`/recruitment panel|setup`", inline=False)
        p3.add_field(name="Broadcast", value="`/dm all|role|user`", inline=False)

        p4 = _brand_e("🎉 Giveaways & Utilities")
        p4.add_field(name="Giveaways", value="`/gstart` `/gend` `/greroll` `/gpause` `/gunpause` `/gedit` `/gcancel` `/glist`", inline=False)
        p4.add_field(name="Utilities", value="`/stats` `/ping` `/afk` `/autoafk` `/embed` `/say` `/calc`", inline=False)
        p4.add_field(name="Access", value="`/staff add|remove|list` `/adminrole add|remove|list`", inline=False)

        pages = [p1, p2, p3, p4]
        view = _HelpPaginator(pages, author_id=interaction.user.id)
        await interaction.response.send_message(embed=pages[0], view=view, ephemeral=True)

    # ─── /staff ───
    staff_grp = app_commands.Group(name="staff", description="Control which roles can use bot commands")

    @staff_grp.command(name="add", description="Add a staff role")
    async def staff_add(interaction: discord.Interaction, role: discord.Role):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(embed=error_embed("Admin only"), ephemeral=True)
        cfg = get_guild(str(interaction.guild.id))
        cfg.setdefault("staffRoleIds", [])
        if str(role.id) in cfg["staffRoleIds"]:
            return await interaction.response.send_message(embed=error_embed("Already added", f"<@&{role.id}> is already a staff role."), ephemeral=True)
        cfg["staffRoleIds"].append(str(role.id)); persist()
        await interaction.response.send_message(embed=success_embed("Staff role added", f"Members with <@&{role.id}> can now use bot commands."), ephemeral=True)

    @staff_grp.command(name="remove", description="Remove a staff role")
    async def staff_remove(interaction: discord.Interaction, role: discord.Role):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(embed=error_embed("Admin only"), ephemeral=True)
        cfg = get_guild(str(interaction.guild.id))
        cfg.setdefault("staffRoleIds", [])
        if str(role.id) not in cfg["staffRoleIds"]:
            return await interaction.response.send_message(embed=error_embed("Not a staff role"), ephemeral=True)
        cfg["staffRoleIds"].remove(str(role.id)); persist()
        await interaction.response.send_message(embed=success_embed("Staff role removed", f"<@&{role.id}> removed."), ephemeral=True)

    @staff_grp.command(name="list", description="Show all configured staff roles")
    async def staff_list(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        cfg = get_guild(str(interaction.guild.id)); ids = cfg.get("staffRoleIds") or []
        lst = "\n".join(f"• <@&{r}>" for r in ids) if ids else "*(none — only Administrators can use the bot)*"
        e = brand_embed(); e.title = "👮 Staff Roles"
        e.description = f"Members in any of these roles (and Administrators) can use bot commands:\n\n{lst}"
        await interaction.response.send_message(embed=e, ephemeral=True)
    tree.add_command(staff_grp)

    # ─── /adminrole ─── (OWNER only — manage admin role tier)
    adminrole_grp = app_commands.Group(name="adminrole", description="Manage admin roles (elevated access tier, owner only)")

    @adminrole_grp.command(name="add", description="[Owner] Grant a role admin-level module access")
    async def adminrole_add(interaction: discord.Interaction, role: discord.Role):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from utils.admin_access import add_admin_role
        add_admin_role(str(interaction.guild.id), str(role.id))
        await interaction.response.send_message(
            embed=success_embed("Admin role added", f"<@&{role.id}> now has access to: Recruitment Panel • Giveaways • Voice Module • Embed"),
            ephemeral=True)

    @adminrole_grp.command(name="remove", description="[Owner] Revoke admin-level module access from a role")
    async def adminrole_remove(interaction: discord.Interaction, role: discord.Role):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from utils.admin_access import remove_admin_role
        remove_admin_role(str(interaction.guild.id), str(role.id))
        await interaction.response.send_message(
            embed=success_embed("Admin role removed", f"<@&{role.id}> no longer has admin module access."),
            ephemeral=True)

    @adminrole_grp.command(name="list", description="[Owner] List all admin roles for this server")
    async def adminrole_list(interaction: discord.Interaction):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from utils.admin_access import get_admin_roles
        role_ids = get_admin_roles(str(interaction.guild.id))
        lst = "\n".join(f"• <@&{r}>" for r in role_ids) if role_ids else "*(none)*"
        e = brand_embed()
        e.title = "🔑 Admin Roles"
        e.description = f"Modules: Recruitment Panel • Giveaways • Voice Module • Embed\n\n{lst}"
        await interaction.response.send_message(embed=e, ephemeral=True)
    tree.add_command(adminrole_grp)

    # ─── /antinuke ─── (toggle/set/punishment/whitelist/channel/quarantine = OWNER only; status = staff)
    an_grp = app_commands.Group(name="antinuke", description="Antinuke configuration & status")
    action_choices = [app_commands.Choice(name=ANTINUKE_ACTION_LABELS[a], value=a) for a in ANTINUKE_ACTIONS]
    pun_choices = [app_commands.Choice(name=p, value=p) for p in PUNISHMENTS]

    @an_grp.command(name="status", description="Show current antinuke configuration")
    async def an_status(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        cfg = get_guild(str(interaction.guild.id))
        rows = []
        for a in ANTINUKE_ACTIONS:
            r = get_antinuke_rule(str(interaction.guild.id), a)
            flag = "🟢" if r["enabled"] else "🔴"
            rows.append(f"{flag} **{ANTINUKE_ACTION_LABELS[a]}** — {r['threshold']} per {r['windowMs']/1000}s → `{r['punishment']}`")
        wl = ", ".join(f"<@{u}>" for u in (cfg.get("antinukeWhitelist") or [])) or "none"
        log_ch_id = cfg.get("antinukeLogChannelId")
        qr_id = cfg.get("antinukeQuarantineRoleId")
        log_ch_str = f"<#{log_ch_id}>" if log_ch_id else "*not set*"
        qr_str = f"<@&{qr_id}>" if qr_id else "*not set*"
        e = brand_embed(); e.title = "🛡️ Antinuke Status"
        e.description = "\n".join([
            f"**System:** {'🟢 Enabled' if cfg.get('antinukeEnabled') else '🔴 Disabled'}",
            f"**Log channel:** {log_ch_str}",
            f"**Quarantine role:** {qr_str}",
            f"**Whitelist:** {wl}", "", *rows,
        ])
        await interaction.response.send_message(embed=e, ephemeral=True)

    @an_grp.command(name="toggle", description="[Owner] Enable or disable the antinuke system")
    async def an_toggle(interaction: discord.Interaction, enabled: bool):
        if not owner_gate(interaction): return await deny_owner(interaction)
        get_guild(str(interaction.guild.id))["antinukeEnabled"] = enabled; persist()
        await interaction.response.send_message(embed=success_embed(f"Antinuke {'enabled' if enabled else 'disabled'}"), ephemeral=True)

    @an_grp.command(name="set", description="[Owner] Set threshold/window for a detection")
    @app_commands.choices(action=action_choices)
    async def an_set(interaction: discord.Interaction, action: app_commands.Choice[str],
                     threshold: app_commands.Range[int, 1, 9999],
                     window_seconds: app_commands.Range[int, 2, 600] = None,
                     enabled: bool = None):
        if not owner_gate(interaction): return await deny_owner(interaction)
        patch = {"threshold": threshold}
        if window_seconds: patch["windowMs"] = window_seconds * 1000
        if enabled is not None: patch["enabled"] = enabled
        u = set_antinuke_rule(str(interaction.guild.id), action.value, patch)
        await interaction.response.send_message(embed=success_embed(f"Updated • {ANTINUKE_ACTION_LABELS[action.value]}",
            f"Threshold: **{u['threshold']}** • Window: **{u['windowMs']/1000}s** • Punishment: **{u['punishment']}** • {'🟢' if u['enabled'] else '🔴'}"), ephemeral=True)

    @an_grp.command(name="punishment", description="[Owner] Set the punishment for a detection")
    @app_commands.choices(action=action_choices, punishment=pun_choices)
    async def an_pun(interaction: discord.Interaction, action: app_commands.Choice[str], punishment: app_commands.Choice[str]):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        if punishment.value == "quarantine" and not cfg.get("antinukeQuarantineRoleId"):
            return await interaction.response.send_message(embed=error_embed("No quarantine role set", "Run `/antinuke quarantine` first."), ephemeral=True)
        u = set_antinuke_rule(str(interaction.guild.id), action.value, {"punishment": punishment.value})
        await interaction.response.send_message(embed=success_embed("Punishment updated", f"**{ANTINUKE_ACTION_LABELS[action.value]}** → `{u['punishment']}`"), ephemeral=True)

    @an_grp.command(name="whitelist", description="[Owner] Add or remove a user from the antinuke whitelist")
    @app_commands.choices(op=[app_commands.Choice(name="add", value="add"), app_commands.Choice(name="remove", value="remove")])
    async def an_wl(interaction: discord.Interaction, op: app_commands.Choice[str], user: discord.User):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        cfg.setdefault("antinukeWhitelist", [])
        uid = str(user.id)
        if op.value == "add":
            if uid not in cfg["antinukeWhitelist"]: cfg["antinukeWhitelist"].append(uid)
        else:
            cfg["antinukeWhitelist"] = [x for x in cfg["antinukeWhitelist"] if x != uid]
        persist()
        await interaction.response.send_message(embed=success_embed("Whitelist updated", f"{'Added' if op.value == 'add' else 'Removed'} <@{uid}>"), ephemeral=True)

    @an_grp.command(name="whitelist-role", description="[Owner] Add or remove up to 3 roles from the antinuke whitelist at once")
    @app_commands.choices(op=[app_commands.Choice(name="add", value="add"), app_commands.Choice(name="remove", value="remove")])
    @app_commands.describe(role1="First role", role2="Second role (optional)", role3="Third role (optional)")
    async def an_wl_role(interaction: discord.Interaction, op: app_commands.Choice[str],
                         role1: discord.Role, role2: discord.Role = None, role3: discord.Role = None):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        cfg.setdefault("antinukeWhitelistRoles", [])
        roles = [r for r in [role1, role2, role3] if r is not None]
        added, removed = [], []
        for role in roles:
            rid = str(role.id)
            if op.value == "add":
                if rid not in cfg["antinukeWhitelistRoles"]:
                    cfg["antinukeWhitelistRoles"].append(rid)
                added.append(f"<@&{rid}>")
            else:
                cfg["antinukeWhitelistRoles"] = [x for x in cfg["antinukeWhitelistRoles"] if x != rid]
                removed.append(f"<@&{rid}>")
        persist()
        lines = []
        if added:   lines.append(f"✅ Added: {', '.join(added)}")
        if removed: lines.append(f"🗑️ Removed: {', '.join(removed)}")
        await interaction.response.send_message(embed=success_embed("Role whitelist updated", "\n".join(lines)), ephemeral=True)

    @an_grp.command(name="whitelist-list", description="[Owner] Show all whitelisted users and roles")
    async def an_wl_list(interaction: discord.Interaction):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        users_wl = ", ".join(f"<@{u}>"  for u in (cfg.get("antinukeWhitelist")      or [])) or "*(none)*"
        roles_wl = ", ".join(f"<@&{r}>" for r in (cfg.get("antinukeWhitelistRoles") or [])) or "*(none)*"
        e = brand_embed()
        e.title = "🛡️ Antinuke Whitelist"
        e.add_field(name="👤 Whitelisted Users", value=users_wl, inline=False)
        e.add_field(name="🎭 Whitelisted Roles", value=roles_wl, inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @an_grp.command(name="channel", description="[Owner] Set the antinuke log channel")
    async def an_ch(interaction: discord.Interaction, channel: discord.TextChannel):
        if not owner_gate(interaction): return await deny_owner(interaction)
        get_guild(str(interaction.guild.id))["antinukeLogChannelId"] = str(channel.id); persist()
        await interaction.response.send_message(embed=success_embed("Antinuke log channel set", f"<#{channel.id}>"), ephemeral=True)

    @an_grp.command(name="quarantine", description="[Owner] Set the quarantine role")
    async def an_qr(interaction: discord.Interaction, role: discord.Role):
        if not owner_gate(interaction): return await deny_owner(interaction)
        get_guild(str(interaction.guild.id))["antinukeQuarantineRoleId"] = str(role.id); persist()
        await interaction.response.send_message(embed=success_embed("Quarantine role set", f"<@&{role.id}>"), ephemeral=True)
    tree.add_command(an_grp)

    # ─── /automod ─── (toggle/filter/badword-add/remove/ignore-channel/ignore-role = OWNER only; status = staff)
    am_grp = app_commands.Group(name="automod", description="Auto moderation system")
    filter_choices = [app_commands.Choice(name="🔗 Anti-Invite", value="antiInvite"),
                      app_commands.Choice(name="🌐 Anti-Link", value="antiLink"),
                      app_commands.Choice(name="📣 Anti-Mass-Mention", value="antiMassMention"),
                      app_commands.Choice(name="💨 Anti-Spam", value="antiSpam"),
                      app_commands.Choice(name="🔠 Anti-Caps", value="antiCaps")]

    @am_grp.command(name="toggle", description="[Owner] Master on/off switch for automod")
    async def am_toggle(interaction: discord.Interaction, enabled: bool):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id)); cfg.setdefault("automod", {})["enabled"] = enabled; persist()
        await interaction.response.send_message(embed=success_embed(f"AutoMod {'enabled' if enabled else 'disabled'}"), ephemeral=True)

    @am_grp.command(name="filter", description="[Owner] Enable/disable individual automod filters")
    @app_commands.choices(type=filter_choices)
    async def am_filter(interaction: discord.Interaction, type: app_commands.Choice[str], enabled: bool):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id)); a = cfg.setdefault("automod", {})
        t = type.value
        if t in ("antiInvite", "antiLink"): a[t] = enabled
        elif t == "antiMassMention": a["antiMassMention"] = {"enabled": enabled, "max": (a.get("antiMassMention") or {}).get("max", 5)}
        elif t == "antiSpam": a["antiSpam"] = {"enabled": enabled, "max": (a.get("antiSpam") or {}).get("max", 5), "windowMs": (a.get("antiSpam") or {}).get("windowMs", 5000)}
        elif t == "antiCaps": a["antiCaps"] = {"enabled": enabled, "minLength": (a.get("antiCaps") or {}).get("minLength", 8), "percent": (a.get("antiCaps") or {}).get("percent", 70)}
        persist()
        await interaction.response.send_message(embed=success_embed(f"Filter `{t}` {'enabled' if enabled else 'disabled'}"), ephemeral=True)

    @am_grp.command(name="badword-add", description="[Owner] Add a banned word")
    async def am_bw_add(interaction: discord.Interaction, word: str):
        if not owner_gate(interaction): return await deny_owner(interaction)
        a = get_guild(str(interaction.guild.id)).setdefault("automod", {}); a.setdefault("badWords", [])
        w = word.lower()
        if w not in a["badWords"]: a["badWords"].append(w)
        persist()
        await interaction.response.send_message(embed=success_embed("Added", f"`{w}` is now filtered."), ephemeral=True)

    @am_grp.command(name="badword-remove", description="[Owner] Remove a banned word")
    async def am_bw_rm(interaction: discord.Interaction, word: str):
        if not owner_gate(interaction): return await deny_owner(interaction)
        a = get_guild(str(interaction.guild.id)).setdefault("automod", {}); a.setdefault("badWords", [])
        a["badWords"] = [x for x in a["badWords"] if x != word.lower()]; persist()
        await interaction.response.send_message(embed=success_embed("Removed", f"`{word}` is no longer filtered."), ephemeral=True)

    @am_grp.command(name="ignore-channel", description="[Owner] Toggle a channel in automod ignore list")
    async def am_ich(interaction: discord.Interaction, channel: discord.TextChannel):
        if not owner_gate(interaction): return await deny_owner(interaction)
        a = get_guild(str(interaction.guild.id)).setdefault("automod", {}); a.setdefault("ignoredChannels", [])
        cid = str(channel.id)
        if cid in a["ignoredChannels"]:
            a["ignoredChannels"].remove(cid); persist()
            await interaction.response.send_message(embed=success_embed("Removed from ignore list", f"<#{cid}>"), ephemeral=True)
        else:
            a["ignoredChannels"].append(cid); persist()
            await interaction.response.send_message(embed=success_embed("Added to ignore list", f"<#{cid}>"), ephemeral=True)

    @am_grp.command(name="ignore-role", description="[Owner] Toggle a role in automod ignore list")
    async def am_irole(interaction: discord.Interaction, role: discord.Role):
        if not owner_gate(interaction): return await deny_owner(interaction)
        a = get_guild(str(interaction.guild.id)).setdefault("automod", {}); a.setdefault("ignoredRoles", [])
        rid = str(role.id)
        if rid in a["ignoredRoles"]:
            a["ignoredRoles"].remove(rid); persist()
            await interaction.response.send_message(embed=success_embed("Removed", f"<@&{rid}> no longer exempt."), ephemeral=True)
        else:
            a["ignoredRoles"].append(rid); persist()
            await interaction.response.send_message(embed=success_embed("Added", f"<@&{rid}> exempt from automod."), ephemeral=True)

    @am_grp.command(name="status", description="Show current automod configuration")
    async def am_status(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        a = get_automod(str(interaction.guild.id))
        fmt = lambda b: "🟢 ON" if b else "🔴 OFF"
        e = brand_embed(); e.title = "🤖 AutoMod Status"; e.description = f"Master switch: {fmt(a['enabled'])}"
        e.add_field(name="🔗 Anti-Invite", value=fmt(a["antiInvite"]), inline=True)
        e.add_field(name="🌐 Anti-Link", value=fmt(a["antiLink"]), inline=True)
        e.add_field(name="📣 Anti-Mass-Mention", value=f"{fmt(a['antiMassMention']['enabled'])} (max {a['antiMassMention']['max']})", inline=True)
        e.add_field(name="💨 Anti-Spam", value=f"{fmt(a['antiSpam']['enabled'])} ({a['antiSpam']['max']}/{a['antiSpam']['windowMs']}ms)", inline=True)
        e.add_field(name="🔠 Anti-Caps", value=f"{fmt(a['antiCaps']['enabled'])} ({a['antiCaps']['percent']}% of ≥{a['antiCaps']['minLength']} chars)", inline=True)
        e.add_field(name="🚫 Bad words", value=(", ".join(f"`{w}`" for w in a["badWords"])[:1000] if a["badWords"] else "*(none)*"), inline=False)
        e.add_field(name="🙈 Ignored channels", value=(" ".join(f"<#{c}>" for c in a["ignoredChannels"]) if a["ignoredChannels"] else "*(none)*"), inline=False)
        e.add_field(name="🙉 Ignored roles", value=(" ".join(f"<@&{r}>" for r in a["ignoredRoles"]) if a["ignoredRoles"] else "*(none)*"), inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)
    tree.add_command(am_grp)

    # ─── /logs ─── (OWNER only)
    logs_grp = app_commands.Group(name="logs", description="Server logging system")
    log_choices = [app_commands.Choice(name=LOG_EVENT_LABELS[e], value=e) for e in LOG_EVENTS]

    @logs_grp.command(name="channel", description="[Owner] Set the channel where logs are posted")
    async def logs_ch(interaction: discord.Interaction, channel: discord.TextChannel = None):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        if channel:
            cfg["logChannelId"] = str(channel.id); persist()
            await interaction.response.send_message(embed=success_embed("Log channel set", f"Events logged to <#{channel.id}>."), ephemeral=True)
        else:
            cfg.pop("logChannelId", None); persist()
            await interaction.response.send_message(embed=success_embed("Logging disabled"), ephemeral=True)

    @logs_grp.command(name="toggle", description="[Owner] Enable or disable a specific log event")
    @app_commands.choices(event=log_choices)
    async def logs_tog(interaction: discord.Interaction, event: app_commands.Choice[str], enabled: bool):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id)); cfg.setdefault("logEvents", {})[event.value] = enabled; persist()
        ch_part = f"Logging to <#{cfg['logChannelId']}>." if cfg.get("logChannelId") else "⚠️ No log channel set. Run `/logs channel` first."
        await interaction.response.send_message(embed=success_embed(f"{'Enabled' if enabled else 'Disabled'}: {LOG_EVENT_LABELS[event.value]}", ch_part), ephemeral=True)

    @logs_grp.command(name="list", description="[Owner] Show all log events and their on/off status")
    async def logs_list(interaction: discord.Interaction):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id))
        lines = [f"{'🟢' if (cfg.get('logEvents') or {}).get(ev, True) else '🔴'} {LOG_EVENT_LABELS[ev]}" for ev in LOG_EVENTS]
        log_ch_id = cfg.get("logChannelId")
        ch_str = f"<#{log_ch_id}>" if log_ch_id else "*(none — run `/logs channel`)*"
        e = brand_embed(); e.title = "📝 Log Events"
        e.description = f"Channel: {ch_str}\n\n" + "\n".join(lines)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @logs_grp.command(name="enable-all", description="[Owner] Enable every log event")
    async def logs_en(interaction: discord.Interaction):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id)); cfg["logEvents"] = {e: True for e in LOG_EVENTS}; persist()
        await interaction.response.send_message(embed=success_embed("All log events enabled"), ephemeral=True)

    @logs_grp.command(name="disable-all", description="[Owner] Disable every log event")
    async def logs_dis(interaction: discord.Interaction):
        if not owner_gate(interaction): return await deny_owner(interaction)
        cfg = get_guild(str(interaction.guild.id)); cfg["logEvents"] = {e: False for e in LOG_EVENTS}; persist()
        await interaction.response.send_message(embed=success_embed("All log events disabled"), ephemeral=True)
    tree.add_command(logs_grp)

    # ─── /recruitment ───
    rc_grp = app_commands.Group(name="recruitment", description="Staff recruitment system")

    @rc_grp.command(name="setup", description="[Owner] Configure the staff recruitment system")
    async def rc_setup(interaction: discord.Interaction, application_channel: discord.TextChannel,
                       panel_channel: discord.TextChannel = None,
                       category: discord.CategoryChannel = None):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from bot import build_recruitment_embed, RecruitmentView, _recruit_clear_denied
        cfg = get_guild(str(interaction.guild.id))
        cfg["recruitmentLogChannelId"] = str(application_channel.id)
        if panel_channel:
            cfg["recruitmentChannelId"] = str(panel_channel.id)
            cfg["recruitmentOpen"] = True
            _recruit_clear_denied(str(interaction.guild.id))
            await panel_channel.send(embed=build_recruitment_embed(open_status=True), view=RecruitmentView(open_status=True))
        if category:
            cfg["recruitmentCategoryId"] = str(category.id)
        persist()
        msg = f"Applications: <#{application_channel.id}>"
        if panel_channel: msg += f"\nPanel posted in: <#{panel_channel.id}>"
        if category: msg += f"\nAccepted channels created under: **{category.name}**"
        await interaction.response.send_message(embed=success_embed("Recruitment configured", msg), ephemeral=True)

    @rc_grp.command(name="panel", description="Post the staff application panel in this channel")
    async def rc_panel(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        from bot import build_recruitment_embed, RecruitmentView, _recruit_clear_denied
        cfg = get_guild(str(interaction.guild.id))
        if not cfg.get("recruitmentLogChannelId"):
            return await interaction.response.send_message(embed=info_embed("Set up first", "Run `/recruitment setup` first."), ephemeral=True)
        cfg["recruitmentOpen"] = True
        persist()
        _recruit_clear_denied(str(interaction.guild.id))
        await interaction.channel.send(embed=build_recruitment_embed(open_status=True), view=RecruitmentView(open_status=True))
        await interaction.response.send_message(embed=success_embed("Panel posted", "Denied list cleared and applications set to Open."), ephemeral=True)
    tree.add_command(rc_grp)

    # ─── /dm ─── (OWNER only)
    dm_grp = app_commands.Group(name="dm", description="Direct-message broadcast tools")

    @dm_grp.command(name="all", description="[Owner] DM every member in the server")
    async def dm_all(interaction: discord.Interaction, message: str):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from bot import build_broadcast_embed, dm_members
        await interaction.response.defer(ephemeral=True)
        e = build_broadcast_embed(interaction.guild, interaction.user, message)
        members = [m async for m in interaction.guild.fetch_members(limit=None) if not m.bot]
        eta_min = max(1, (len(members) * 30) // 60)
        await interaction.followup.send(embed=info_embed("📤 Broadcast started",
            f"Sending to **{len(members)}** members at **2 DMs/min** (rate-limit safe).\nEstimated time: **~{eta_min} min**. You'll get a summary when done."), ephemeral=True)
        s = await dm_members(members, e, concurrency=1, delay_ms=30000)
        try:
            await interaction.user.send(embed=success_embed("📬 Broadcast complete",
                f"Server: **{interaction.guild.name}**\nTargeted **all members**.\nAttempted: **{s['attempted']}**\nDelivered: **{s['succeeded']}**\nFailed: **{s['failed']}**"))
        except Exception:
            pass

    @dm_grp.command(name="role", description="[Owner] DM every member with a role")
    async def dm_role(interaction: discord.Interaction, role: discord.Role, message: str):
        if not owner_gate(interaction): return await deny_owner(interaction)
        from bot import build_broadcast_embed, dm_members
        await interaction.response.defer(ephemeral=True)
        members = [m for m in role.members if not m.bot]
        if not members:
            return await interaction.followup.send(embed=error_embed("No targets", "Nobody currently has this role."), ephemeral=True)
        e = build_broadcast_embed(interaction.guild, interaction.user, message)
        eta_min = max(1, (len(members) * 30) // 60)
        await interaction.followup.send(embed=info_embed("📤 Role broadcast started",
            f"Sending to **{len(members)}** members of <@&{role.id}> at **2 DMs/min** (rate-limit safe).\nEstimated time: **~{eta_min} min**. You'll get a summary when done."), ephemeral=True)
        s = await dm_members(members, e, concurrency=1, delay_ms=30000)
        try:
            await interaction.user.send(embed=success_embed("📬 Role broadcast complete",
                f"Server: **{interaction.guild.name}**\nTargeted <@&{role.id}> ({len(members)}).\nDelivered: **{s['succeeded']}** / Failed: **{s['failed']}**"))
        except Exception:
            pass

    @dm_grp.command(name="user", description="[Staff] DM a single user via the bot")
    async def dm_user(interaction: discord.Interaction, user: discord.Member, message: str):
        if not staff_gate(interaction): return await deny(interaction)
        from bot import build_broadcast_embed, dm_members
        await interaction.response.defer(ephemeral=True)
        e = build_broadcast_embed(interaction.guild, interaction.user, message)
        s = await dm_members([user], e, concurrency=1)
        if s["succeeded"]:
            await interaction.followup.send(embed=success_embed("📬 DM sent", f"Delivered to <@{user.id}>."), ephemeral=True)
        else:
            reason = s["failures"][0]["reason"] if s["failures"] else "unknown"
            await interaction.followup.send(embed=error_embed("DM failed", f"Could not DM <@{user.id}> — *{reason}*."), ephemeral=True)
    tree.add_command(dm_grp)

    # ─── /invites ───
    inv_grp = app_commands.Group(name="invites", description="Invite tracking commands")

    @inv_grp.command(name="view", description="Show invite stats for a member")
    async def inv_view(interaction: discord.Interaction, user: discord.User = None):
        if not staff_gate(interaction): return await deny(interaction)
        from bot import get_invite_counts
        target = user or interaction.user
        c = get_invite_counts(str(interaction.guild.id), str(target.id))
        e = brand_embed(); e.title = f"📨 Invites • {target.name}"
        e.description = f"**Total:** {c['total']}\n**Real:** {c['regular']}\n**Left:** {c['left']}\n**Fake:** {c['fake']}\n**Bonus:** {c['bonus']}"
        e.set_thumbnail(url=target.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @inv_grp.command(name="leaderboard", description="Top inviters")
    async def inv_lb(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        cfg = get_guild(str(interaction.guild.id))
        counts = cfg.get("inviteCounts") or {}
        ranked = sorted([(uid, c["regular"] - c["left"] + c["bonus"]) for uid, c in counts.items()], key=lambda x: -x[1])[:10]
        lines = "\n".join(f"**{i+1}.** <@{uid}> — `{t}` invites" for i, (uid, t) in enumerate(ranked)) or "No invite data yet."
        e = brand_embed(); e.title = "📨 Invite Leaderboard"; e.description = lines
        await interaction.response.send_message(embed=e)

    @inv_grp.command(name="add", description="Give bonus invites to a member")
    async def inv_add(interaction: discord.Interaction, user: discord.User, amount: int):
        if not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message(embed=error_embed("Missing permission", "Requires Manage Server."), ephemeral=True)
        from bot import add_bonus_invites
        b = add_bonus_invites(str(interaction.guild.id), str(user.id), amount)
        await interaction.response.send_message(embed=success_embed("Bonus invites updated", f"<@{user.id}> now has **{b}** bonus invites."), ephemeral=True)

    @inv_grp.command(name="set-log", description="Set the invite log channel")
    async def inv_log(interaction: discord.Interaction, channel: discord.TextChannel):
        if not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message(embed=error_embed("Missing permission", "Requires Manage Server."), ephemeral=True)
        get_guild(str(interaction.guild.id))["inviteLogChannelId"] = str(channel.id); persist()
        await interaction.response.send_message(embed=success_embed("Invite log channel set", f"<#{channel.id}>"), ephemeral=True)
    tree.add_command(inv_grp)

    # ─── /util ───
    util_grp = app_commands.Group(name="util", description="Utility commands")

    @util_grp.command(name="serverinfo", description="Show information about this server")
    async def u_si(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        g = interaction.guild; await interaction.response.defer()
        owner = g.owner or (await g.fetch_member(g.owner_id) if g.owner_id else None)
        text = sum(1 for c in g.channels if isinstance(c, discord.TextChannel))
        voice = sum(1 for c in g.channels if isinstance(c, discord.VoiceChannel))
        cats = sum(1 for c in g.channels if isinstance(c, discord.CategoryChannel))
        e = brand_embed(); e.title = f"📊 {g.name}"
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.add_field(name="👑 Owner", value=f"<@{owner.id}>", inline=True)
        e.add_field(name="🆔 Server ID", value=f"`{g.id}`", inline=True)
        e.add_field(name="📅 Created", value=f"<t:{int(g.created_at.timestamp())}:R>", inline=True)
        e.add_field(name="👥 Members", value=str(g.member_count), inline=True)
        e.add_field(name="🎭 Roles", value=str(len(g.roles)), inline=True)
        e.add_field(name="😀 Emojis", value=str(len(g.emojis)), inline=True)
        e.add_field(name="💬 Text", value=str(text), inline=True)
        e.add_field(name="🔊 Voice", value=str(voice), inline=True)
        e.add_field(name="📁 Categories", value=str(cats), inline=True)
        e.add_field(name="🚀 Boost Tier", value=f"Tier {g.premium_tier} ({g.premium_subscription_count or 0} boosts)", inline=True)
        e.add_field(name="🔐 Verification", value=str(g.verification_level), inline=True)
        await interaction.followup.send(embed=e)

    @util_grp.command(name="memberinfo", description="Show information about a member")
    async def u_mi(interaction: discord.Interaction, user: discord.Member = None):
        if not staff_gate(interaction): return await deny(interaction)
        m = user or interaction.user
        roles = [f"<@&{r.id}>" for r in sorted([r for r in m.roles if r.id != m.guild.id], key=lambda x: -x.position)][:20]
        e = brand_embed(); e.title = f"👤 {m}"
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="🆔 ID", value=f"`{m.id}`", inline=True)
        e.add_field(name="📅 Joined Server", value=f"<t:{int(m.joined_at.timestamp())}:R>" if m.joined_at else "unknown", inline=True)
        e.add_field(name="📅 Account Created", value=f"<t:{int(m.created_at.timestamp())}:R>", inline=True)
        e.add_field(name="🤖 Bot", value="Yes" if m.bot else "No", inline=True)
        e.add_field(name="🎭 Top Role", value=f"<@&{m.top_role.id}>" if m.top_role else "—", inline=True)
        e.add_field(name=f"🎭 Roles ({len(m.roles)-1})", value=" ".join(roles) or "*(none)*", inline=False)
        await interaction.response.send_message(embed=e)

    @util_grp.command(name="members", description="Show server member counts")
    async def u_mem(interaction: discord.Interaction):
        if not staff_gate(interaction): return await deny(interaction)
        g = interaction.guild
        humans = sum(1 for m in g.members if not m.bot)
        bots = sum(1 for m in g.members if m.bot)
        e = brand_embed(); e.title = f"👥 {g.name} — Members"
        e.add_field(name="Total", value=str(g.member_count), inline=True)
        e.add_field(name="Humans", value=str(humans), inline=True)
        e.add_field(name="Bots", value=str(bots), inline=True)
        await interaction.response.send_message(embed=e)

    @util_grp.command(name="roleinfo", description="Show information about a role")
    async def u_ri(interaction: discord.Interaction, role: discord.Role):
        if not staff_gate(interaction): return await deny(interaction)
        e = brand_embed(); e.title = f"🎭 {role.name}"
        if role.color.value: e.color = role.color
        e.add_field(name="🆔 ID", value=f"`{role.id}`", inline=True)
        e.add_field(name="🎨 Color", value=f"`#{role.color.value:06x}`", inline=True)
        e.add_field(name="📅 Created", value=f"<t:{int(role.created_at.timestamp())}:R>", inline=True)
        e.add_field(name="👥 Members", value=str(len(role.members)), inline=True)
        e.add_field(name="📍 Position", value=str(role.position), inline=True)
        e.add_field(name="🔝 Hoisted", value="Yes" if role.hoist else "No", inline=True)
        e.add_field(name="🔔 Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        e.add_field(name="🤖 Managed", value="Yes" if role.managed else "No", inline=True)
        await interaction.response.send_message(embed=e)

    @util_grp.command(name="avatar", description="Show a user's avatar (supports animated avatars)")
    async def u_av(interaction: discord.Interaction, user: discord.User = None):
        if not staff_gate(interaction): return await deny(interaction)
        u = user or interaction.user
        # Use replace() to preserve the animated gif format for animated avatars
        avatar = u.display_avatar
        avatar_url = str(avatar.replace(size=1024))
        e = brand_embed()
        e.title = f"🖼️ {u}"
        e.description = f"{'🎞️ Animated' if avatar.is_animated() else '🖼️ Static'} avatar"
        e.set_image(url=avatar_url)
        # Also add global avatar link if different from display (server-specific)
        if u.avatar and u.avatar.key != avatar.key:
            global_url = str(u.avatar.replace(size=1024))
            e.add_field(name="🌐 Global Avatar", value=f"[Click to view]({global_url})", inline=False)
        await interaction.response.send_message(embed=e)
    tree.add_command(util_grp)

    # ─── /drag ─── (all = OWNER only; from/user = staff)
    drag_grp = app_commands.Group(name="drag", description="Move members between voice channels")

    @drag_grp.command(name="all", description="[Owner] Drag every member in voice into one channel")
    async def drag_all(interaction: discord.Interaction, destination: discord.VoiceChannel):
        if not owner_gate(interaction): return await deny_owner(interaction)
        await interaction.response.defer(ephemeral=True)
        moved = failed = 0
        for m in interaction.guild.members:
            if m.voice and m.voice.channel and m.voice.channel.id != destination.id:
                try: await m.move_to(destination); moved += 1
                except Exception: failed += 1
        await interaction.followup.send(embed=success_embed("🔁 Drag complete", f"Moved **{moved}** member(s) into <#{destination.id}>" + (f"\nFailed: {failed}" if failed else "")), ephemeral=True)

    @drag_grp.command(name="from", description="Drag everyone from one VC to another")
    async def drag_from(interaction: discord.Interaction, source: discord.VoiceChannel, destination: discord.VoiceChannel):
        if not staff_gate(interaction): return await deny(interaction)
        await interaction.response.defer(ephemeral=True)
        moved = failed = 0
        for m in source.members:
            try: await m.move_to(destination); moved += 1
            except Exception: failed += 1
        await interaction.followup.send(embed=success_embed("🔁 Drag complete", f"Moved **{moved}** from <#{source.id}> → <#{destination.id}>" + (f"\nFailed: {failed}" if failed else "")), ephemeral=True)

    @drag_grp.command(name="user", description="Drag a specific user to a voice channel")
    async def drag_user(interaction: discord.Interaction, user: discord.Member, destination: discord.VoiceChannel):
        if not staff_gate(interaction): return await deny(interaction)
        await interaction.response.defer(ephemeral=True)
        if not user.voice or not user.voice.channel:
            return await interaction.followup.send(embed=error_embed("User not in voice", f"<@{user.id}> isn't in any voice channel right now."), ephemeral=True)
        try:
            await user.move_to(destination)
            await interaction.followup.send(embed=success_embed("🔁 Moved", f"<@{user.id}> → <#{destination.id}>"), ephemeral=True)
        except Exception as err:
            await interaction.followup.send(embed=error_embed("Move failed", str(err)), ephemeral=True)
    tree.add_command(drag_grp)

    # Register prefix commands
    from cogs.prefix_full import register_prefix
    register_prefix(bot)
