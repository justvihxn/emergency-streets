import discord
from discord.ext import commands
from discord import app_commands
from config import OWNER_IDS
from utils.admin_access import is_admin


def _can_use_embed(inter: discord.Interaction) -> bool:
    """Owner, server admin, OR users with an admin role can use embed."""
    if inter.user.id in OWNER_IDS:
        return True
    if not inter.guild or not isinstance(inter.user, discord.Member):
        return False
    if inter.user.guild_permissions.administrator or inter.user == inter.guild.owner:
        return True
    return is_admin(str(inter.guild.id), inter.user)


def _can_use_embed_ctx(ctx: commands.Context) -> bool:
    """Same check for prefix command."""
    from config import OWNER_IDS as _OWNER_IDS
    if ctx.author.id in _OWNER_IDS:
        return True
    if not ctx.guild:
        return False
    if ctx.author.guild_permissions.administrator or ctx.author == ctx.guild.owner:
        return True
    return is_admin(str(ctx.guild.id), ctx.author)


class EmbedCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="embed", description="Create a beautiful embed (admins/admin-role/owner only).")
    @app_commands.describe(
        title="The title (use | for line breaks)",
        description="The description (use | for line breaks)",
        author="The author (use | for line breaks)",
        footer="The footer text (use | for line breaks)",
        footer_image="URL of the footer icon",
        thumbnail="URL of the thumbnail icon",
        image="URL of the image",
        color="HEX color code (e.g., #FF0000 or FF0000)"
    )
    async def embed_command(
        self,
        inter: discord.Interaction,
        title: str = None,
        description: str = None,
        author: str = None,
        footer: str = None,
        footer_image: str = None,
        thumbnail: str = None,
        image: str = None,
        color: str = None
    ):
        if not _can_use_embed(inter):
            return await inter.response.send_message(
                "🚫 Only the server owner, admins, or members with an admin role can use this command.",
                ephemeral=True,
            )

        embed_color = discord.Color.purple()
        if color:
            try:
                if color.startswith("#"):
                    color = color[1:]
                embed_color = discord.Color(int(color, 16))
            except ValueError:
                return await inter.response.send_message("❌ Invalid color. Use HEX like `#FF0000`.", ephemeral=True)

        def fix_text(txt: str):
            return txt.replace("|", "\n") if txt else None

        embed = discord.Embed(
            title=fix_text(title),
            description=fix_text(description),
            color=embed_color
        )

        if author:
            embed.set_author(name=fix_text(author))
        if footer:
            if footer_image:
                embed.set_footer(text=fix_text(footer), icon_url=footer_image)
            else:
                embed.set_footer(text=fix_text(footer))
        if thumbnail:
            embed.set_thumbnail(url=thumbnail)
        if image:
            embed.set_image(url=image)

        await inter.response.send_message("✅ Embed sent!", ephemeral=True)
        await inter.channel.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(EmbedCog(bot))
