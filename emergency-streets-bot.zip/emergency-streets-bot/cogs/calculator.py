"""Calculator cog — single expression command, both prefix and slash. Public use."""
import ast
import operator as _op
import re
import discord
from discord.ext import commands
from discord import app_commands


_OP_MAP = {
    ast.Add:      (_op.add,        "is adding"),
    ast.Sub:      (_op.sub,        "is subtracting"),
    ast.Mult:     (_op.mul,        "is multiplying"),
    ast.Div:      (_op.truediv,    "is dividing"),
    ast.FloorDiv: (_op.floordiv,   "is dividing (floor)"),
    ast.Pow:      (_op.pow,        "is exponentiating"),
    ast.Mod:      (_op.mod,        "is using modulo"),
}


def _eval_node(node, ops_seen: list):
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return float(node.value)
        raise ValueError("Only numeric values are allowed.")
    if isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in _OP_MAP:
            raise ValueError(f"Unsupported operator: {op_type.__name__}")
        fn, label = _OP_MAP[op_type]
        left = _eval_node(node.left, ops_seen)
        right = _eval_node(node.right, ops_seen)
        if op_type is ast.Div and right == 0:
            raise ZeroDivisionError("Cannot divide by zero.")
        if op_type is ast.FloorDiv and right == 0:
            raise ZeroDivisionError("Cannot divide by zero.")
        if label not in ops_seen:
            ops_seen.append(label)
        return fn(left, right)
    if isinstance(node, ast.UnaryOp):
        if isinstance(node.op, ast.USub):
            return -_eval_node(node.operand, ops_seen)
        if isinstance(node.op, ast.UAdd):
            return _eval_node(node.operand, ops_seen)
        raise ValueError("Unsupported unary operator.")
    raise ValueError(f"Unsupported expression element: {type(node).__name__}")


def _safe_calc(expr: str):
    """Parse and evaluate a math expression safely. Returns (result, ops_list)."""
    expr = expr.strip()
    if not expr:
        raise ValueError("No expression provided.")
    if len(expr) > 500:
        raise ValueError("Expression too long (max 500 characters).")
    if not re.search(r"[\d.]", expr):
        raise ValueError("Expression must contain numbers.")
    tree = ast.parse(expr, mode="eval")
    ops_seen: list = []
    result = _eval_node(tree.body, ops_seen)
    return result, ops_seen


def _make_embed(expression: str, result, ops: list) -> discord.Embed:
    color = discord.Color.blurple()
    e = discord.Embed(title="🧮 Calculator", color=color)
    e.add_field(name="📝 Expression", value=f"```{expression}```", inline=False)
    ops_str = " • ".join(ops) if ops else "direct evaluation"
    e.add_field(name="⚙️ Operations", value=f"*{ops_str}*", inline=False)
    if isinstance(result, float) and result == int(result) and abs(result) < 1e15:
        display = f"{int(result):,}"
    else:
        display = f"{result:g}"
    e.add_field(name="✅ Result", value=f"**`{display}`**", inline=False)
    return e


class Calculator(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="calc", description="Calculate any math expression (public)")
    @app_commands.describe(expression="Math expression, e.g. 100 + 50 * 2 - 30 / 3")
    async def slash_calc(self, inter: discord.Interaction, expression: str):
        try:
            result, ops = _safe_calc(expression)
        except ZeroDivisionError as e:
            return await inter.response.send_message(
                embed=discord.Embed(title="❌ Division by Zero", description=str(e), color=0xef4444),
                ephemeral=True,
            )
        except Exception as e:
            return await inter.response.send_message(
                embed=discord.Embed(title="❌ Invalid Expression", description=str(e), color=0xef4444),
                ephemeral=True,
            )
        await inter.response.send_message(embed=_make_embed(expression, result, ops))

    # NOTE: prefix `!calc` is registered by cogs/prefix_full.py to avoid
    # discord.py's global "command already registered" collision when loading
    # this cog after the prefix router. The slash `/calc` above is the only
    # thing this cog owns.


async def setup(bot: commands.Bot):
    await bot.add_cog(Calculator(bot))
