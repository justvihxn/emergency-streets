"""Remind cog — slash + prefix, usable by staff"""
import discord
from discord.ext import commands
from discord import app_commands
import os
from store import is_staff as _store_is_staff


class RemindCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def _is_staff(self, interaction: discord.Interaction) -> bool:
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            return False
        if interaction.user.guild_permissions.administrator:
            return True
        return _store_is_staff(str(interaction.guild.id), interaction.user)

    @app_commands.command(name="remind", description="DM a user to remind them about their ticket.")
    @app_commands.describe(user="The user to remind via DM")
    async def remind(self, interaction: discord.Interaction, user: discord.Member):
        if not self._is_staff(interaction):
            return await interaction.response.send_message(
                "🚫 Only staff members can use this command.", ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)

        ticket_channel = interaction.channel
        ticket_url = ticket_channel.jump_url if ticket_channel else None

        thumb_path = os.path.join("assets", "tslogo.png")
        gif_path = os.path.join("assets", "Emergency Streets gif.gif")

        embed = discord.Embed(
            title="🎫 Your Ticket Needs Attention!",
            description=(
                f"Hey {user.mention},\n\n"
                "> We are still waiting for your response in the ticket.\n"
                "> Please click the button below to view your ticket.\n\n"
                "Kindly respond when you're available. We're here to help! 🙂"
            ),
            color=discord.Color.blurple()
        )
        embed.set_footer(
            text="Emergency Streets Support Team",
            icon_url=interaction.guild.icon.url if interaction.guild and interaction.guild.icon else None
        )

        files = []
        # Attach assets only if they exist
        if os.path.isfile(thumb_path):
            embed.set_thumbnail(url="attachment://tslogo.png")
            files.append(discord.File(thumb_path, filename="tslogo.png"))
        if os.path.isfile(gif_path):
            embed.set_image(url="attachment://store.gif")
            files.append(discord.File(gif_path, filename="store.gif"))

        view = discord.ui.View()
        if ticket_url:
            view.add_item(discord.ui.Button(label="🔗 View Ticket", url=ticket_url))
        view.add_item(discord.ui.Button(label="💬 Support Server", url="https://discord.gg/DNZyTuNNQA"))

        try:
            await user.send(embed=embed, view=view, files=files)
            await interaction.followup.send(f"📨 Successfully reminded {user.mention} via DM!", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send(
                f"❌ I couldn't DM {user.mention}. Their DMs might be closed.", ephemeral=True
            )
        except Exception as err:
            await interaction.followup.send(f"❌ Failed: {err}", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(RemindCog(bot))
