import discord
from discord.ext import commands
from discord import app_commands
from store import is_staff


class SayCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def interaction_check(self, inter: discord.Interaction) -> bool:
        if not inter.guild:
            await inter.response.send_message("🚫 This command can only be used in a server.", ephemeral=True)
            return False
        if (
            inter.user == inter.guild.owner
            or inter.user.guild_permissions.administrator
            or is_staff(str(inter.guild.id), inter.user)
        ):
            return True
        await inter.response.send_message(
            "🚫 Only the server owner, admins, or staff can use this command.",
            ephemeral=True,
        )
        return False

    @app_commands.command(
        name="say",
        description="Make the bot say something (staff/admins/owner only)"
    )
    @app_commands.describe(
        message="The message you want the bot to say",
        channel="The channel to send the message to (defaults to current channel)"
    )
    async def say_command(
        self,
        inter: discord.Interaction,
        message: str,
        channel: discord.TextChannel = None,
    ):
        # Defer first to avoid the 3-second interaction timeout (10062 errors)
        await inter.response.defer(ephemeral=True)
        target = channel or inter.channel
        try:
            await target.send(message)
        except discord.Forbidden:
            return await inter.followup.send("❌ I don't have permission to send messages there.", ephemeral=True)
        except Exception as err:
            return await inter.followup.send(f"❌ Failed to send message: {err}", ephemeral=True)

        if target == inter.channel:
            await inter.followup.send("✅ Message sent!", ephemeral=True)
        else:
            await inter.followup.send(
                f"✅ Message sent to {target.mention}!",
                ephemeral=True,
            )


async def setup(bot: commands.Bot):
    await bot.add_cog(SayCog(bot))
