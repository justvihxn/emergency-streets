import discord
from discord.ext import commands, tasks
from discord import app_commands
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import random
import json
import os
import re

from config import OWNER_IDS
from utils.admin_access import is_admin

THUMBNAIL_PATH = "assets/tslogo.png"
BANNER_PATH = "assets/Emergency Streets gif.gif"
GIVEAWAY_FILE = "giveaways.json"

REACTION_EMOJI = "<:trusted:1402282696826425355>"
DECORATION_EMOJI = "<:gift_purple:1408997949718921347>"


def _has_giveaway_access(inter: discord.Interaction) -> bool:
    """Bot owner, server admin, staff role, OR admin role can use giveaways."""
    if inter.user.id in OWNER_IDS:
        return True
    if not inter.guild or not isinstance(inter.user, discord.Member):
        return False
    if inter.user.guild_permissions.administrator:
        return True
    if is_admin(str(inter.guild.id), inter.user):
        return True
    guild_id = str(inter.guild.id)
    staff_role_id = inter.client.staff_roles.get(guild_id)
    if staff_role_id and staff_role_id in [r.id for r in inter.user.roles]:
        return True
    return False


def giveaway_check():
    async def predicate(inter: discord.Interaction):
        if _has_giveaway_access(inter):
            return True
        await inter.response.send_message(
            "🚫 You need a staff role or admin role to manage giveaways.", ephemeral=True
        )
        return False
    return app_commands.check(predicate)


def now_ts() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def parse_duration(s: str) -> Optional[int]:
    s = s.strip().lower()
    if not s:
        return None
    total = 0
    for num, unit in re.findall(r"(\d+)\s*([smhdw])", s):
        n = int(num)
        if unit == "s": total += n
        elif unit == "m": total += n * 60
        elif unit == "h": total += n * 3600
        elif unit == "d": total += n * 86400
        elif unit == "w": total += n * 604800
    return total or None


def load_data() -> Dict[str, Dict[str, Any]]:
    if not os.path.exists(GIVEAWAY_FILE):
        with open(GIVEAWAY_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f)
        return {}
    with open(GIVEAWAY_FILE, "r", encoding="utf-8") as f:
        try: return json.load(f)
        except json.JSONDecodeError: return {}


def save_data(data: Dict[str, Dict[str, Any]]) -> None:
    with open(GIVEAWAY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def reaction_matches(reaction: discord.Reaction) -> bool:
    return str(reaction.emoji) == REACTION_EMOJI


class GiveawayCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.checker.start()

    def cog_unload(self):
        self.checker.cancel()

    @tasks.loop(seconds=10)
    async def checker(self):
        data = load_data()
        for g_id, items in list(data.items()):
            for mid, g in list(items.items()):
                if g.get("status") != "active":
                    continue
                if now_ts() >= int(g["end_ts"]):
                    channel = self.bot.get_channel(int(g["channel_id"]))
                    if not channel:
                        g["status"] = "ended"
                        save_data(data)
                        continue
                    try:
                        msg = await channel.fetch_message(int(mid))
                    except discord.NotFound:
                        g["status"] = "ended"
                        save_data(data)
                        continue

                    users = []
                    for reaction in msg.reactions:
                        if reaction_matches(reaction):
                            users = [u async for u in reaction.users() if not u.bot]
                            break

                    if not users:
                        await channel.send(embed=discord.Embed(
                            title=f"{DECORATION_EMOJI} Giveaway Ended",
                            description=f"No valid entries for **{g['prize']}**.",
                            color=discord.Color.purple()))
                    else:
                        winners = random.sample(users, min(len(users), int(g["winners"])))
                        await channel.send(embed=discord.Embed(
                            title=f"{DECORATION_EMOJI} Giveaway Ended",
                            description=f"**Prize:** {g['prize']}\n**Winners:** {', '.join(w.mention for w in winners)}",
                            color=discord.Color.purple()))
                    g["status"] = "ended"
                    save_data(data)

    @app_commands.command(name="gstart", description="Start a new giveaway.")
    @giveaway_check()
    @app_commands.describe(channel="Channel", duration="Duration", winners="Winners", prize="Prize")
    async def gstart(self, inter: discord.Interaction, channel: discord.TextChannel, duration: str,
                     winners: app_commands.Range[int, 1, 100], prize: str):
        await inter.response.defer(ephemeral=True)
        seconds = parse_duration(duration)
        if not seconds:
            return await inter.followup.send("Invalid duration.", ephemeral=True)
        end_ts = now_ts() + seconds
        embed = discord.Embed(
            title=f"{DECORATION_EMOJI} Giveaway Started!",
            description=(f"**Prize:** {prize}\n**Winners:** {winners}\n**Ends:** <t:{end_ts}:R> • <t:{end_ts}:f>\n\n"
                         f"React with {REACTION_EMOJI} to enter!"),
            color=discord.Color.purple())
        embed.set_footer(text=f"Hosted by {inter.user} • Emergency Streets")
        files = []
        if os.path.isfile(THUMBNAIL_PATH):
            embed.set_thumbnail(url="attachment://tslogo.png")
            files.append(discord.File(THUMBNAIL_PATH, filename="tslogo.png"))
        if os.path.isfile(BANNER_PATH):
            embed.set_image(url="attachment://banner.gif")
            files.append(discord.File(BANNER_PATH, filename="banner.gif"))
        msg = await channel.send(embed=embed, files=files)
        try:
            await msg.add_reaction(REACTION_EMOJI)
        except discord.HTTPException:
            await inter.followup.send("Couldn't add reaction.", ephemeral=True)
        data = load_data()
        data.setdefault(str(inter.guild_id), {})[str(msg.id)] = {
            "channel_id": str(channel.id),
            "end_ts": int(end_ts),
            "prize": prize,
            "winners": int(winners),
            "host_id": str(inter.user.id),
            "status": "active",
            "paused_remaining": None}
        save_data(data)
        await inter.followup.send(f"{DECORATION_EMOJI} Giveaway started in {channel.mention}!", ephemeral=True)

    @app_commands.command(name="gend", description="End a giveaway early.")
    @giveaway_check()
    async def gend(self, inter: discord.Interaction, message_id: str):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") not in ("active", "paused"):
            return await inter.response.send_message("Not found.", ephemeral=True)
        g["end_ts"] = now_ts()
        g["status"] = "active"
        save_data(data)
        await inter.response.send_message("Giveaway will end soon.", ephemeral=True)

    @app_commands.command(name="greroll", description="Reroll winners.")
    @giveaway_check()
    async def greroll(self, inter: discord.Interaction, message_id: str):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") != "ended":
            return await inter.response.send_message("Not ended.", ephemeral=True)
        channel = self.bot.get_channel(int(g["channel_id"]))
        if not channel:
            return await inter.response.send_message("Channel not found.", ephemeral=True)
        try:
            msg = await channel.fetch_message(int(message_id))
        except discord.NotFound:
            return await inter.response.send_message("Message not found.", ephemeral=True)
        participants = []
        for reaction in msg.reactions:
            if reaction_matches(reaction):
                participants = [u async for u in reaction.users() if not u.bot]
                break
        if not participants:
            return await inter.response.send_message("No participants.", ephemeral=True)
        winners = random.sample(participants, min(len(participants), int(g["winners"])))
        await channel.send(embed=discord.Embed(
            title=f"{DECORATION_EMOJI} Giveaway Reroll!",
            description=f"New winner(s): {', '.join(w.mention for w in winners)} for **{g['prize']}**.",
            color=discord.Color.purple()))
        await inter.response.send_message("Rerolled.", ephemeral=True)

    @app_commands.command(name="gpause", description="Pause giveaway.")
    @giveaway_check()
    async def gpause(self, inter: discord.Interaction, message_id: str):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") != "active":
            return await inter.response.send_message("Not active.", ephemeral=True)
        g["paused_remaining"] = max(0, int(g["end_ts"]) - now_ts())
        g["status"] = "paused"
        save_data(data)
        await inter.response.send_message("Paused.", ephemeral=True)

    @app_commands.command(name="gunpause", description="Resume giveaway.")
    @giveaway_check()
    async def gunpause(self, inter: discord.Interaction, message_id: str):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") != "paused":
            return await inter.response.send_message("Not paused.", ephemeral=True)
        rem = g.get("paused_remaining") or 0
        g["end_ts"] = now_ts() + (rem if rem > 0 else 5)
        g["status"] = "active"
        g["paused_remaining"] = None
        save_data(data)
        await inter.response.send_message("Resumed.", ephemeral=True)

    @app_commands.command(name="gedit", description="Edit giveaway.")
    @giveaway_check()
    async def gedit(self, inter: discord.Interaction, message_id: str, prize: Optional[str] = None,
                    winners: Optional[app_commands.Range[int, 1, 100]] = None,
                    set_duration: Optional[str] = None, add_duration: Optional[str] = None):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") not in ("active", "paused"):
            return await inter.response.send_message("Cannot edit.", ephemeral=True)
        if prize: g["prize"] = prize
        if winners: g["winners"] = int(winners)
        if set_duration:
            secs = parse_duration(set_duration)
            if not secs: return await inter.response.send_message("Invalid set_duration.", ephemeral=True)
            g["end_ts"] = now_ts() + secs
            g["status"] = "active"
            g["paused_remaining"] = None
        elif add_duration:
            secs = parse_duration(add_duration)
            if not secs: return await inter.response.send_message("Invalid add_duration.", ephemeral=True)
            if g["status"] == "paused":
                g["paused_remaining"] = (g.get("paused_remaining") or 0) + secs
            else:
                g["end_ts"] = int(g["end_ts"]) + secs
        save_data(data)
        await inter.response.send_message("Updated.", ephemeral=True)

    @app_commands.command(name="gcancel", description="Cancel giveaway.")
    @giveaway_check()
    async def gcancel(self, inter: discord.Interaction, message_id: str):
        data = load_data()
        g = data.get(str(inter.guild_id), {}).get(message_id)
        if not g or g.get("status") in ("ended", "cancelled"):
            return await inter.response.send_message("Not found or ended.", ephemeral=True)
        g["status"] = "cancelled"
        save_data(data)
        try:
            channel = self.bot.get_channel(int(g["channel_id"]))
            await channel.send(embed=discord.Embed(
                title=f"{DECORATION_EMOJI} Giveaway Cancelled",
                description=f"Prize **{g['prize']}** has been cancelled.",
                color=discord.Color.purple()))
        except Exception:
            pass
        await inter.response.send_message("Cancelled.", ephemeral=True)

    @app_commands.command(name="glist", description="List active giveaways.")
    @giveaway_check()
    async def glist(self, inter: discord.Interaction):
        data = load_data()
        all_g = data.get(str(inter.guild_id), {})
        active = {mid: g for mid, g in all_g.items() if g.get("status") in ("active", "paused")}
        if not active:
            return await inter.response.send_message("No active giveaways.", ephemeral=True)
        embed = discord.Embed(title="Active Giveaways", color=discord.Color.purple())
        for mid, g in active.items():
            status = g.get("status", "active")
            ends_str = f"Paused • {g.get('paused_remaining', 0)}s left" if status == "paused" else f"<t:{int(g['end_ts'])}:R> • <t:{int(g['end_ts'])}:f>"
            embed.add_field(
                name=f"{DECORATION_EMOJI} {g['prize']}",
                value=f"Status: **{status}**\nID: `{mid}`\nEnds: {ends_str}",
                inline=False)
        await inter.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(GiveawayCog(bot))
