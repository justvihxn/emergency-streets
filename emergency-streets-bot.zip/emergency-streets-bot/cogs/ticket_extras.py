"""
Ticket Extras
=============

Enhancements on top of the existing /ticketpanel system:

- /ticketrate      — rate a ticket after it's closed (1-5 stars, sends to logs)
- /ticketpriority  — mark a ticket Low / Normal / High / Urgent (colour + tag)
- /ticketreopen    — reopen a closed ticket
- /ticketsearch    — search tickets by owner / status / category
- /ticketnote      — add an internal staff-only note to the ticket
- /ticketnotes     — view internal notes on the current ticket
- /tickettag       — add or remove a coloured tag on a ticket

All commands operate on the ticket associated with the current channel unless
otherwise specified. Data is stored on the ticket document itself via the
existing `utils/ticket_db.py` facade.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.ticket_db import db
from utils.pretty import ok, err, info, warn, brand, BRAND_COLOR


PRIORITY = {
    "low":    ("🟢 Low",     0x22c55e),
    "normal": ("🔵 Normal",  0x3b82f6),
    "high":   ("🟠 High",    0xf97316),
    "urgent": ("🔴 Urgent",  0xef4444),
}


async def _log(guild: discord.Guild, embed: discord.Embed):
    cfg = await db.get_config(guild.id)
    ch_id = cfg.get("log_channel_id")
    if not ch_id:
        return
    ch = guild.get_channel(int(ch_id))
    if ch:
        try:
            await ch.send(embed=embed)
        except Exception:
            pass


async def _is_ticket_staff(member: discord.Member) -> bool:
    if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
        return True
    cfg = await db.get_config(member.guild.id)
    roles = cfg.get("ticket_staff_role_ids", [])
    return any(r.id in roles for r in member.roles)


async def _current_ticket(interaction: discord.Interaction) -> Optional[dict]:
    return await db.get_ticket_by_channel(interaction.channel.id)


class TicketExtras(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ─── /ticketrate ────────────────────────────────
    @app_commands.command(name="ticketrate",
                          description="Rate this ticket (1-5) after it has been closed.")
    async def rate(self, interaction: discord.Interaction,
                    stars: app_commands.Range[int, 1, 5],
                    review: Optional[str] = None):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if int(t["owner_id"]) != interaction.user.id:
            return await interaction.response.send_message(
                embed=err("Only ticket owner", "Only the ticket creator can rate."),
                ephemeral=True)
        if t.get("status") not in ("closed", "open", "claimed"):
            return await interaction.response.send_message(
                embed=err("Not allowed here"), ephemeral=True)
        await db.update_ticket(t["_id"], {
            "rating": stars,
            "review": (review or "")[:500],
            "rated_ts": time.time(),
        })
        e = discord.Embed(
            title="⭐ Thanks for your rating!",
            description=f"{'⭐' * stars} ({stars}/5)\n\n"
                        + (f"**Review:** {review}" if review else ""),
            color=0xfacc15,
        )
        e.set_footer(text="Emergency Streets • Ticket Rating")
        await interaction.response.send_message(embed=e)
        await _log(interaction.guild, discord.Embed(
            title="⭐ Ticket Rated",
            description=(f"**Ticket:** `{t['_id']}` in {interaction.channel.mention}\n"
                         f"**Rating:** {'⭐' * stars} ({stars}/5)\n"
                         f"**By:** {interaction.user.mention}\n"
                         + (f"**Review:** {review}" if review else "")),
            color=0xfacc15,
        ))

    # ─── /ticketpriority ────────────────────────────
    @app_commands.command(name="ticketpriority",
                          description="Set the priority of this ticket.")
    @app_commands.choices(level=[app_commands.Choice(name=v[0], value=k)
                                  for k, v in PRIORITY.items()])
    async def priority(self, interaction: discord.Interaction,
                        level: app_commands.Choice[str]):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message(
                embed=err("Staff only"), ephemeral=True)
        await db.update_ticket(t["_id"], {"priority": level.value})
        label, colour = PRIORITY[level.value]
        try:
            # rename channel with a priority prefix (strip old priority prefix)
            cur = interaction.channel.name
            for _, (l, _c) in PRIORITY.items():
                pfx = l.split()[0].lower()
                if cur.startswith(pfx + "-"):
                    cur = cur[len(pfx) + 1:]
                    break
            new_name = f"{label.split()[0].lower()}-{cur}"[:95]
            await interaction.channel.edit(name=new_name)
        except Exception:
            pass
        e = brand(f"Priority set to {label}",
                  f"Ticket `{t['_id']}` is now **{label}**.")
        e.color = discord.Color(colour)
        await interaction.response.send_message(embed=e)
        await _log(interaction.guild, e)

    # ─── /ticketreopen ──────────────────────────────
    @app_commands.command(name="ticketreopen",
                          description="Reopen the ticket associated with this channel.")
    async def reopen(self, interaction: discord.Interaction):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message(
                embed=err("Staff only"), ephemeral=True)
        if t.get("status") not in ("closed", "locked"):
            return await interaction.response.send_message(
                embed=info("Already open", "This ticket is not closed."),
                ephemeral=True)
        await db.update_ticket(t["_id"], {"status": "open", "reopened_ts": time.time()})
        owner = interaction.guild.get_member(int(t["owner_id"]))
        if owner:
            try:
                await interaction.channel.set_permissions(
                    owner, view_channel=True, send_messages=True,
                    read_message_history=True,
                )
            except Exception:
                pass
        try:
            cur = interaction.channel.name
            if cur.startswith("closed-"):
                await interaction.channel.edit(name=cur[len("closed-"):][:95])
        except Exception:
            pass
        e = ok(f"Ticket reopened",
               f"Ticket `{t['_id']}` reopened by {interaction.user.mention}.")
        await interaction.response.send_message(embed=e)
        await _log(interaction.guild, e)

    # ─── /ticketsearch ──────────────────────────────
    @app_commands.command(name="ticketsearch",
                          description="Search tickets by owner / status / category.")
    async def search(self, interaction: discord.Interaction,
                      owner: Optional[discord.User] = None,
                      status: Optional[str] = None,
                      category: Optional[str] = None):
        tickets = await db.list_tickets(interaction.guild.id)
        results = tickets
        if owner:
            results = [t for t in results if int(t.get("owner_id", 0)) == owner.id]
        if status:
            results = [t for t in results if (t.get("status") or "") == status.lower()]
        if category:
            results = [t for t in results if (t.get("category") or "").lower() == category.lower()]
        if not results:
            return await interaction.response.send_message(
                embed=info("No results"), ephemeral=True)
        lines = []
        for t in sorted(results, key=lambda x: -x.get("created_ts", 0))[:20]:
            ch = interaction.guild.get_channel(int(t.get("channel_id", 0)))
            lines.append(
                f"• `{t['_id']}` — {t.get('category','?')} — <@{t['owner_id']}> — "
                f"{t.get('status','?').upper()} — "
                + (ch.mention if ch else "*deleted channel*"))
        e = brand("🎫 Ticket Search", "\n".join(lines))
        await interaction.response.send_message(embed=e, ephemeral=True)

    # ─── /ticketnote ────────────────────────────────
    @app_commands.command(name="ticketnote",
                          description="Add an internal staff-only note to this ticket.")
    async def note_add(self, interaction: discord.Interaction, note: str):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message(
                embed=err("Staff only"), ephemeral=True)
        notes = list(t.get("notes") or [])
        notes.append({
            "author_id": interaction.user.id,
            "text": note[:500],
            "ts": time.time(),
        })
        await db.update_ticket(t["_id"], {"notes": notes[-30:]})
        e = brand("📝 Staff Note Added",
                  f"{interaction.user.mention}: {note[:500]}")
        await interaction.response.send_message(embed=e, ephemeral=True)

    # ─── /ticketnotes ───────────────────────────────
    @app_commands.command(name="ticketnotes",
                          description="View all internal notes for this ticket.")
    async def notes_view(self, interaction: discord.Interaction):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message(
                embed=err("Staff only"), ephemeral=True)
        notes = t.get("notes") or []
        if not notes:
            return await interaction.response.send_message(
                embed=info("No notes yet"), ephemeral=True)
        e = brand(f"📝 Staff Notes — {t['_id']}")
        for n in notes[-20:]:
            e.add_field(
                name=f"<t:{int(n.get('ts', time.time()))}:R>",
                value=f"<@{n['author_id']}>: {n.get('text', '')}",
                inline=False,
            )
        await interaction.response.send_message(embed=e, ephemeral=True)

    # ─── /tickettag ─────────────────────────────────
    @app_commands.command(name="tickettag",
                          description="Add or remove a tag on this ticket.")
    async def tag(self, interaction: discord.Interaction, tag: str, remove: bool = False):
        t = await _current_ticket(interaction)
        if not t:
            return await interaction.response.send_message(
                embed=err("Not a ticket channel"), ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message(
                embed=err("Staff only"), ephemeral=True)
        tags = list(t.get("tags") or [])
        tag = tag.strip().lower()[:20]
        if remove:
            tags = [x for x in tags if x != tag]
        else:
            if tag not in tags:
                tags.append(tag)
        await db.update_ticket(t["_id"], {"tags": tags})
        await interaction.response.send_message(
            embed=ok("Tags updated", "`" + "`, `".join(tags or ["(none)"]) + "`"),
            ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(TicketExtras(bot))
