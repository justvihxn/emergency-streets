"""
Ticket System — main cog
================================

Slash commands:
  /ticketpanel         send the ticket panel
  /addticketstaff     add a ticket staff role
  /removeticketstaff  remove a ticket staff role
  /blacklist           blacklist user
  /unblacklist         unblacklist user
  /transcript          generate transcript
  /close               close (archive) ticket
  /delete              delete ticket
  /rename              rename ticket
  /add                 add user to ticket
  /remove              remove user from ticket
  /claim               claim ticket
  /unclaim             unclaim ticket
  /stats               ticket statistics
  /ticketconfig        configure roles / log channel / category / cooldown / auto-close

Full button toolbar on every ticket:
  🎯 Claim   🔓 Unclaim   ➕ Add User   ➖ Remove User
  🔒 Lock    🔓 Unlock    📝 Rename     📌 Pin Ticket
  📢 Notify Staff   ⏰ Inactive Reminder   📂 Move Category
  📄 Transcript   💾 Save Transcript   🗑 Close   ❌ Delete
"""
from __future__ import annotations

import asyncio
import io
import time
from datetime import datetime, timezone, timedelta
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from utils.ticket_db import db
from utils.ticket_transcripts import generate_transcript


# ─── Categories (label → (emoji, description, color)) ─────────────
CATEGORIES: dict[str, tuple[str, str, int]] = {
    "General Support": ("🛠️", "Get help with an issue or question", 0x3b82f6),
    "Report User": ("🚨", "Report a rule violation or harmful behavior", 0xef4444),
    "Bug Report": ("🐛", "Report a bot or server issue", 0xf59e0b),
    "Appeal": ("📨", "Appeal a moderation action", 0x8b5cf6),
    "Staff Contact": ("👥", "Contact the staff team privately", 0x14b8a6),
}

DEFAULT_COOLDOWN = 60          # seconds between opening two tickets
DEFAULT_AUTO_CLOSE_HOURS = 48  # auto-close after inactivity
INACTIVE_REMINDER_MINUTES = 30
BRAND_COLOR = 0x9b59b6


# ═════════════════════ HELPERS ═════════════════════
def now_utc() -> datetime:
    return datetime.now(timezone.utc)


async def _get_cfg(guild_id: int) -> dict:
    return await db.get_config(guild_id)


def _is_admin(member: discord.Member) -> bool:
    if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
        return True
    return False


async def _is_ticket_staff(member: discord.Member) -> bool:
    if _is_admin(member):
        return True
    cfg = await _get_cfg(member.guild.id)
    ticket_staff_role_ids = cfg.get("ticket_staff_role_ids", [])
    return any(r.id in ticket_staff_role_ids for r in member.roles)


def _ticket_embed(ticket: dict, guild: discord.Guild) -> discord.Embed:
    cat = ticket["category"]
    emoji, desc, color = CATEGORIES.get(cat, ("🎫", "Ticket", BRAND_COLOR))
    owner = guild.get_member(int(ticket["owner_id"]))
    claimed_by = ticket.get("claimed_by")
    claimed_txt = f"<@{claimed_by}>" if claimed_by else "`Unclaimed`"

    e = discord.Embed(
        title=f"{emoji} {cat} Ticket",
        description=(
            f"Welcome {owner.mention if owner else '<user>'}!\n"
            f"A staff will be with you shortly. Please describe your request in detail.\n\n"
            f"**Category:** {cat}\n"
            f"**Ticket ID:** `{ticket['_id']}`\n"
            f"**Created:** <t:{int(ticket['created_ts'])}:R>\n"
            f"**Owner:** <@{ticket['owner_id']}>\n"
            f"**Claimed:** {claimed_txt}\n"
            f"**Status:** `{ticket.get('status','open').upper()}`"
        ),
        color=color,
        timestamp=now_utc(),
    )
    e.set_footer(text="Emergency Streets • Ticket System")
    return e


async def _log(guild: discord.Guild, embed: discord.Embed) -> None:
    cfg = await _get_cfg(guild.id)
    ch_id = cfg.get("log_channel_id")
    if not ch_id:
        return
    ch = guild.get_channel(int(ch_id))
    if ch:
        try:
            await ch.send(embed=embed)
        except Exception:
            pass


def _log_embed(title: str, desc: str, color: int = BRAND_COLOR) -> discord.Embed:
    e = discord.Embed(title=title, description=desc, color=color, timestamp=now_utc())
    e.set_footer(text="Emergency Streets • Ticket Logs")
    return e


# ═════════════════════ PANEL VIEW ═════════════════════
class TicketPanelView(discord.ui.View):
    """Persistent panel with a category select."""

    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(_CategorySelect())


class _CategorySelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label=name, emoji=data[0], description=data[1])
            for name, data in CATEGORIES.items()
        ]
        super().__init__(
            custom_id="ticket:category-select",
            placeholder="🎫  Select a category to open a ticket…",
            min_values=1, max_values=1, options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        cog: "TicketsCog" = interaction.client.get_cog("TicketsCog")  # type: ignore
        # Reset the select so the same value can be chosen again
        try:
            await interaction.message.edit(view=TicketPanelView())
        except Exception:
            pass
        if not cog:
            return await interaction.response.send_message("Ticket system offline.", ephemeral=True)
        await cog.open_ticket(interaction, category)


# ═════════════════════ TICKET BUTTONS VIEW ═════════════════════
class TicketButtonsView(discord.ui.View):
    """Persistent toolbar attached to the ticket embed."""

    def __init__(self):
        super().__init__(timeout=None)

    async def _guard(self, interaction: discord.Interaction, staff_only=False, owner_or_staff=False) -> Optional[dict]:
        ticket = await db.get_ticket_by_channel(interaction.channel.id)
        if not ticket:
            await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
            return None
        if staff_only and not await _is_ticket_staff(interaction.user):
            await interaction.response.send_message("❌ Only staffs/admins can use this.", ephemeral=True)
            return None
        if owner_or_staff and int(ticket["owner_id"]) != interaction.user.id and not await _is_ticket_staff(interaction.user):
            await interaction.response.send_message("❌ Ticket owner or staffs only.", ephemeral=True)
            return None
        return ticket

    # ── Row 1: Claim / Unclaim / Add / Remove ─────────────────
    @discord.ui.button(label="Claim", emoji="🎯", style=discord.ButtonStyle.success, custom_id="ticket:claim", row=0)
    async def claim(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        if ticket.get("claimed_by"):
            return await interaction.response.send_message("Already claimed.", ephemeral=True)
        await db.update_ticket(ticket["_id"], {
            "claimed_by": interaction.user.id,
            "claimed_ts": time.time(),
            "status": "claimed",
        })
        ticket = await db.get_ticket(ticket["_id"])
        try:
            await interaction.message.edit(embed=_ticket_embed(ticket, interaction.guild))
        except Exception:
            pass
        await interaction.response.send_message(f"🎯 Ticket claimed by {interaction.user.mention}.")
        await _log(interaction.guild, _log_embed(
            "🎯 Ticket Claimed",
            f"Ticket `{ticket['_id']}` claimed by {interaction.user.mention} in {interaction.channel.mention}",
            0x22c55e,
        ))

    @discord.ui.button(label="Unclaim", emoji="🔓", style=discord.ButtonStyle.secondary, custom_id="ticket:unclaim", row=0)
    async def unclaim(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction)
        if not ticket:
            return
        claimer = ticket.get("claimed_by")
        if not claimer:
            return await interaction.response.send_message("Not claimed.", ephemeral=True)
        if int(claimer) != interaction.user.id and not _is_admin(interaction.user):
            return await interaction.response.send_message("Only the claimer or an admin can unclaim.", ephemeral=True)
        await db.update_ticket(ticket["_id"], {"claimed_by": None, "claimed_ts": None, "status": "open"})
        ticket = await db.get_ticket(ticket["_id"])
        try:
            await interaction.message.edit(embed=_ticket_embed(ticket, interaction.guild))
        except Exception:
            pass
        await interaction.response.send_message("🔓 Ticket unclaimed.")
        await _log(interaction.guild, _log_embed(
            "🔓 Ticket Unclaimed", f"Ticket `{ticket['_id']}` unclaimed by {interaction.user.mention}", 0xf59e0b))

    @discord.ui.button(label="Add User", emoji="➕", style=discord.ButtonStyle.primary, custom_id="ticket:add", row=0)
    async def add_user(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        await self._guard(interaction, staff_only=True)
        await interaction.response.send_modal(_AddUserModal())

    @discord.ui.button(label="Remove User", emoji="➖", style=discord.ButtonStyle.secondary, custom_id="ticket:remove", row=0)
    async def remove_user(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        await self._guard(interaction, staff_only=True)
        await interaction.response.send_modal(_RemoveUserModal())

    # ── Row 2: Lock / Unlock / Rename / Pin ───────────────────
    @discord.ui.button(label="Lock", emoji="🔒", style=discord.ButtonStyle.secondary, custom_id="ticket:lock", row=1)
    async def lock(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        ch = interaction.channel
        owner = interaction.guild.get_member(int(ticket["owner_id"]))
        if owner:
            await ch.set_permissions(owner, send_messages=False)
        await db.update_ticket(ticket["_id"], {"status": "locked"})
        await interaction.response.send_message("🔒 Ticket locked.")
        await _log(interaction.guild, _log_embed("🔒 Ticket Locked", f"`{ticket['_id']}` locked by {interaction.user.mention}", 0x64748b))

    @discord.ui.button(label="Unlock", emoji="🔓", style=discord.ButtonStyle.secondary, custom_id="ticket:unlock", row=1)
    async def unlock(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        ch = interaction.channel
        owner = interaction.guild.get_member(int(ticket["owner_id"]))
        if owner:
            await ch.set_permissions(owner, send_messages=True)
        await db.update_ticket(ticket["_id"], {"status": "open"})
        await interaction.response.send_message("🔓 Ticket unlocked.")
        await _log(interaction.guild, _log_embed("🔓 Ticket Unlocked", f"`{ticket['_id']}` unlocked by {interaction.user.mention}", 0x22c55e))

    @discord.ui.button(label="Rename", emoji="📝", style=discord.ButtonStyle.secondary, custom_id="ticket:rename", row=1)
    async def rename(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        await self._guard(interaction, staff_only=True)
        await interaction.response.send_modal(_RenameModal())

    @discord.ui.button(label="Pin", emoji="📌", style=discord.ButtonStyle.secondary, custom_id="ticket:pin", row=1)
    async def pin(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        await self._guard(interaction, staff_only=True)
        try:
            await interaction.message.pin(reason=f"Pinned by {interaction.user}")
            await interaction.response.send_message("📌 Ticket message pinned.")
        except Exception as e:
            await interaction.response.send_message(f"⚠️ Could not pin: {e}", ephemeral=True)

    # ── Row 3: Notify / Reminder / Move ───────────────────────
    @discord.ui.button(label="Notify Staff", emoji="📢", style=discord.ButtonStyle.primary, custom_id="ticket:notify", row=2)
    async def notify(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, owner_or_staff=True)
        if not ticket:
            return
        cfg = await _get_cfg(interaction.guild.id)
        roles = [interaction.guild.get_role(r) for r in cfg.get("ticket_staff_role_ids", []) if interaction.guild.get_role(r)]
        mentions = " ".join(r.mention for r in roles) or "(no staff role configured)"
        await interaction.response.send_message(f"📢 {mentions} — attention needed here.")

    @discord.ui.button(label="Reminder", emoji="⏰", style=discord.ButtonStyle.secondary, custom_id="ticket:reminder", row=2)
    async def reminder(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        owner = interaction.guild.get_member(int(ticket["owner_id"]))
        mention = owner.mention if owner else f"<@{ticket['owner_id']}>"
        await interaction.response.send_message(
            f"⏰ {mention} — this ticket has been inactive. Please respond or it will be auto-closed."
        )

    @discord.ui.button(label="Move", emoji="📂", style=discord.ButtonStyle.secondary, custom_id="ticket:move", row=2)
    async def move(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        await self._guard(interaction, staff_only=True)
        await interaction.response.send_modal(_MoveModal())

    # ── Row 4: Transcript / Save / Close / Delete ─────────────
    @discord.ui.button(label="Transcript", emoji="📄", style=discord.ButtonStyle.primary, custom_id="ticket:transcript", row=3)
    async def transcript(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        await interaction.response.defer(thinking=True)
        html_p, txt_p, count = await generate_transcript(interaction.channel, ticket)
        files = [discord.File(str(html_p)), discord.File(str(txt_p))]
        await interaction.followup.send(content=f"📄 Transcript generated — **{count}** messages.", files=files)
        await _log(interaction.guild, _log_embed(
            "📄 Transcript Generated",
            f"`{ticket['_id']}` — {count} msgs — by {interaction.user.mention}",
            0x3b82f6))

    @discord.ui.button(label="Save", emoji="💾", style=discord.ButtonStyle.secondary, custom_id="ticket:save", row=3)
    async def save(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        await interaction.response.defer(thinking=True, ephemeral=True)
        html_p, txt_p, count = await generate_transcript(interaction.channel, ticket)
        # DM owner
        owner = interaction.guild.get_member(int(ticket["owner_id"]))
        dm_ok = False
        if owner:
            try:
                await owner.send(
                    content=f"📄 Transcript for your ticket `{ticket['_id']}` ({count} msgs).",
                    files=[discord.File(str(html_p)), discord.File(str(txt_p))],
                )
                dm_ok = True
            except Exception:
                dm_ok = False
        await interaction.followup.send(f"💾 Saved to `/transcripts/` — DM sent: {'✅' if dm_ok else '❌'}", ephemeral=True)

    @discord.ui.button(label="Close", emoji="🗑", style=discord.ButtonStyle.danger, custom_id="ticket:close", row=3)
    async def close(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, owner_or_staff=True)
        if not ticket:
            return
        await interaction.response.defer(thinking=True)
        html_p, txt_p, count = await generate_transcript(interaction.channel, ticket)

        # log + save
        await _log(interaction.guild, _log_embed(
            "🗑 Ticket Closed",
            f"`{ticket['_id']}` closed by {interaction.user.mention} — {count} msgs.",
            0xef4444))
        # DM
        owner = interaction.guild.get_member(int(ticket["owner_id"]))
        if owner:
            try:
                await owner.send(
                    f"Your ticket `{ticket['_id']}` was closed by {interaction.user}. Transcript attached.",
                    files=[discord.File(str(html_p)), discord.File(str(txt_p))],
                )
            except Exception:
                pass

        await db.update_ticket(ticket["_id"], {"status": "closed", "closed_ts": time.time(),
                                                "closed_by": interaction.user.id})
        # lock channel & remove owner
        try:
            if owner:
                await interaction.channel.set_permissions(owner, view_channel=False, send_messages=False)
            await interaction.channel.edit(name=f"closed-{interaction.channel.name}"[:100])
        except Exception:
            pass
        await interaction.followup.send("🗑 Ticket closed & archived. Use ❌ Delete to remove the channel.")

    @discord.ui.button(label="Delete", emoji="❌", style=discord.ButtonStyle.danger, custom_id="ticket:delete", row=3)
    async def delete(self, interaction: discord.Interaction, _btn: discord.ui.Button):
        ticket = await self._guard(interaction, staff_only=True)
        if not ticket:
            return
        await interaction.response.send_message("❌ Deleting in 5s…")
        await _log(interaction.guild, _log_embed(
            "❌ Ticket Deleted", f"`{ticket['_id']}` deleted by {interaction.user.mention}", 0x991b1b))
        await db.update_ticket(ticket["_id"], {"status": "deleted"})
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete(reason=f"Ticket deleted by {interaction.user}")
        except Exception:
            pass


# ═════════════════════ MODALS ═════════════════════
class _AddUserModal(discord.ui.Modal, title="Add User to Ticket"):
    user_id = discord.ui.TextInput(label="User ID or @mention", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        m = _parse_user(interaction.guild, self.user_id.value)
        if not m:
            return await interaction.response.send_message("User not found.", ephemeral=True)
        await interaction.channel.set_permissions(m, view_channel=True, send_messages=True)
        await db.update_ticket((await db.get_ticket_by_channel(interaction.channel.id))["_id"],
                               {"last_activity": time.time()})
        await interaction.response.send_message(f"➕ {m.mention} added.")
        await _log(interaction.guild, _log_embed("➕ User Added", f"{m.mention} added to {interaction.channel.mention}"))


class _RemoveUserModal(discord.ui.Modal, title="Remove User from Ticket"):
    user_id = discord.ui.TextInput(label="User ID or @mention", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        m = _parse_user(interaction.guild, self.user_id.value)
        if not m:
            return await interaction.response.send_message("User not found.", ephemeral=True)
        await interaction.channel.set_permissions(m, overwrite=None)
        await interaction.response.send_message(f"➖ {m.mention} removed.")
        await _log(interaction.guild, _log_embed("➖ User Removed", f"{m.mention} removed from {interaction.channel.mention}"))


class _RenameModal(discord.ui.Modal, title="Rename Ticket"):
    new_name = discord.ui.TextInput(label="New channel name", max_length=95, required=True)

    async def on_submit(self, interaction: discord.Interaction):
        clean = self.new_name.value.strip().lower().replace(" ", "-")[:95]
        try:
            await interaction.channel.edit(name=clean)
            await interaction.response.send_message(f"📝 Renamed to `{clean}`.")
            await _log(interaction.guild, _log_embed("📝 Ticket Renamed", f"→ `{clean}` by {interaction.user.mention}"))
        except Exception as e:
            await interaction.response.send_message(f"⚠️ Could not rename: {e}", ephemeral=True)


class _MoveModal(discord.ui.Modal, title="Move Ticket Category"):
    category_id = discord.ui.TextInput(label="Category ID", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            cid = int(self.category_id.value.strip())
            cat = interaction.guild.get_channel(cid)
            if not isinstance(cat, discord.CategoryChannel):
                return await interaction.response.send_message("Not a category.", ephemeral=True)
            await interaction.channel.edit(category=cat)
            await interaction.response.send_message(f"📂 Moved to **{cat.name}**.")
        except Exception as e:
            await interaction.response.send_message(f"⚠️ Move failed: {e}", ephemeral=True)


def _parse_user(guild: discord.Guild, s: str) -> Optional[discord.Member]:
    s = s.strip().replace("<@!", "<@")
    if s.startswith("<@") and s.endswith(">"):
        s = s[2:-1]
    if s.isdigit():
        return guild.get_member(int(s))
    lowered = s.lower()
    for m in guild.members:
        if m.name.lower() == lowered or (m.display_name and m.display_name.lower() == lowered):
            return m
    return None


# ═════════════════════ COG ═════════════════════
class TicketsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._cooldown: dict[str, float] = {}  # user_id → last_open ts
        self._loops_started = False

    async def cog_load(self):
        await db.connect()
        # Register persistent views
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketButtonsView())
        if not self._loops_started:
            self._auto_close_loop.start()
            self._loops_started = True

    def cog_unload(self):
        try:
            self._auto_close_loop.cancel()
        except Exception:
            pass

    # ─── OPEN TICKET (core) ───────────────────────────────────
    async def open_ticket(self, interaction: discord.Interaction, category: str):
        guild = interaction.guild
        user = interaction.user
        cfg = await _get_cfg(guild.id)

        # blacklist
        if await db.is_blacklisted(user.id):
            return await interaction.response.send_message("❌ You are blacklisted from opening tickets.", ephemeral=True)

        # cooldown
        cd = float(cfg.get("cooldown", DEFAULT_COOLDOWN))
        last = self._cooldown.get(str(user.id), 0)
        if time.time() - last < cd:
            wait = int(cd - (time.time() - last))
            return await interaction.response.send_message(f"⏳ Please wait **{wait}s** before opening another ticket.", ephemeral=True)

        # anti-duplicate
        existing = await db.find_open_ticket_by_user(guild.id, user.id, category)
        if existing:
            ch = guild.get_channel(int(existing["channel_id"]))
            if ch:
                return await interaction.response.send_message(
                    f"⚠️ You already have an open **{category}** ticket: {ch.mention}", ephemeral=True)

        await interaction.response.defer(thinking=True, ephemeral=True)

        # Determine category
        cat_channel = None
        cat_id = cfg.get("ticket_category_id")
        if cat_id:
            cat_channel = guild.get_channel(int(cat_id))
        if not isinstance(cat_channel, discord.CategoryChannel):
            cat_channel = None

        # Ticket number & ID
        num = await db.next_ticket_number(guild.id)
        ticket_id = f"T-{num:05d}"

        # Channel permissions
        overwrites: dict[discord.abc.Snowflake, discord.PermissionOverwrite] = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                              read_message_history=True, attach_files=True, embed_links=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True,
                                                  manage_messages=True, read_message_history=True),
        }
        for rid in cfg.get("ticket_staff_role_ids", []):
            role = guild.get_role(int(rid))
            if role:
                overwrites[role] = discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, read_message_history=True,
                    manage_messages=True, attach_files=True, embed_links=True)

        clean_cat = category.lower().replace(" ", "-")
        channel_name = f"{clean_cat}-{user.name}"[:95]
        try:
            channel = await guild.create_text_channel(
                channel_name, category=cat_channel, overwrites=overwrites,
                topic=f"{category} ticket • {ticket_id} • owner={user.id}",
                reason=f"Ticket opened by {user}",
            )
        except discord.Forbidden:
            return await interaction.followup.send("❌ Missing permissions to create channels.", ephemeral=True)

        # Save ticket
        ticket = {
            "_id": ticket_id,
            "guild_id": guild.id,
            "channel_id": channel.id,
            "owner_id": user.id,
            "category": category,
            "status": "open",
            "created_ts": time.time(),
            "last_activity": time.time(),
            "claimed_by": None,
            "claimed_ts": None,
        }
        await db.create_ticket(ticket)
        self._cooldown[str(user.id)] = time.time()

        # Ping message
        staff_roles = [guild.get_role(int(r)) for r in cfg.get("ticket_staff_role_ids", []) if guild.get_role(int(r))]
        ping_line = " ".join([user.mention] + [r.mention for r in staff_roles])
        ping_msg = await channel.send(ping_line, allowed_mentions=discord.AllowedMentions(users=True, roles=True))

        # Main ticket embed + buttons
        embed = _ticket_embed(ticket, guild)
        info_msg = await channel.send(embed=embed, view=TicketButtonsView())
        try:
            await info_msg.pin(reason="Ticket info")
        except Exception:
            pass

        # Auto-remove role ping
        async def _rm_ping():
            await asyncio.sleep(6)
            try:
                await ping_msg.delete()
            except Exception:
                pass
        asyncio.create_task(_rm_ping())

        await _log(guild, _log_embed(
            "🎫 Ticket Opened",
            f"**{category}** ticket `{ticket_id}` opened by {user.mention} → {channel.mention}",
            0x22c55e))
        await interaction.followup.send(f"✅ Ticket created: {channel.mention}", ephemeral=True)

    # ═════════════════ SLASH COMMANDS ═════════════════
    @app_commands.command(name="ticketpanel", description="Send the ticket panel in the current channel.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticketpanel(self, interaction: discord.Interaction):
        e = discord.Embed(
            title="🎫 Emergency Streets • Open a Ticket",
            description=(
                "Welcome to the support desk!\n\n"
                "Pick a category from the menu below and a private ticket channel will be created for you.\n\n"
                + "\n".join(f"{data[0]} **{name}** — {data[1]}" for name, data in CATEGORIES.items())
            ),
            color=BRAND_COLOR, timestamp=now_utc(),
        )
        e.set_footer(text="Please only open a ticket if you genuinely need help.")
        await interaction.channel.send(embed=e, view=TicketPanelView())
        await interaction.response.send_message("✅ Panel sent.", ephemeral=True)

    @app_commands.command(name="ticketconfig", description="Configure ticket system (roles, log, category, cooldown).")
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        staff_role="Add a role to the staffs list",
        log_channel="Channel where ticket logs go",
        ticket_category="Category where new tickets are created",
        cooldown_seconds="Cooldown between openings per user",
        auto_close_hours="Auto-close inactive tickets after N hours (0 = disabled)",
    )
    async def ticketconfig(self, interaction: discord.Interaction,
                            staff_role: Optional[discord.Role] = None,
                            log_channel: Optional[discord.TextChannel] = None,
                            ticket_category: Optional[discord.CategoryChannel] = None,
                            cooldown_seconds: Optional[int] = None,
                            auto_close_hours: Optional[int] = None):
        cfg = await _get_cfg(interaction.guild.id)
        updates: dict = {}
        if staff_role:
            roles = list(set(cfg.get("ticket_staff_role_ids", []) + [staff_role.id]))
            updates["ticket_staff_role_ids"] = roles
        if log_channel:
            updates["log_channel_id"] = log_channel.id
        if ticket_category:
            updates["ticket_category_id"] = ticket_category.id
        if cooldown_seconds is not None:
            updates["cooldown"] = max(0, int(cooldown_seconds))
        if auto_close_hours is not None:
            updates["auto_close_hours"] = max(0, int(auto_close_hours))
        if not updates:
            return await interaction.response.send_message(
                f"Current config: ```{cfg}```", ephemeral=True)
        await db.set_config(interaction.guild.id, updates)
        await interaction.response.send_message(f"✅ Updated: `{list(updates)}`", ephemeral=True)

    @app_commands.command(name="addticketstaff", description="Add a staff role.")
    @app_commands.checks.has_permissions(administrator=True)
    async def addticketstaff(self, interaction: discord.Interaction, role: discord.Role):
        cfg = await _get_cfg(interaction.guild.id)
        roles = list(set(cfg.get("ticket_staff_role_ids", []) + [role.id]))
        await db.set_config(interaction.guild.id, {"ticket_staff_role_ids": roles})
        await interaction.response.send_message(f"✅ {role.mention} added as staff.", ephemeral=True)

    @app_commands.command(name="removeticketstaff", description="Remove a staff role.")
    @app_commands.checks.has_permissions(administrator=True)
    async def removeticketstaff(self, interaction: discord.Interaction, role: discord.Role):
        cfg = await _get_cfg(interaction.guild.id)
        roles = [r for r in cfg.get("ticket_staff_role_ids", []) if r != role.id]
        await db.set_config(interaction.guild.id, {"ticket_staff_role_ids": roles})
        await interaction.response.send_message(f"✅ {role.mention} removed from staffs.", ephemeral=True)

    @app_commands.command(name="blacklist", description="Blacklist a user from opening tickets.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def blacklist_cmd(self, interaction: discord.Interaction, user: discord.User, reason: Optional[str] = ""):
        await db.blacklist_add(user.id, reason or "")
        await interaction.response.send_message(f"⛔ {user.mention} blacklisted.", ephemeral=True)

    @app_commands.command(name="unblacklist", description="Remove a user from ticket blacklist.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def unblacklist_cmd(self, interaction: discord.Interaction, user: discord.User):
        await db.blacklist_remove(user.id)
        await interaction.response.send_message(f"✅ {user.mention} unblacklisted.", ephemeral=True)

    @app_commands.command(name="transcript", description="Generate a transcript of this ticket.")
    async def transcript_cmd(self, interaction: discord.Interaction):
        ticket = await db.get_ticket_by_channel(interaction.channel.id)
        if not ticket:
            return await interaction.response.send_message("Not a ticket channel.", ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message("Staffs only.", ephemeral=True)
        await interaction.response.defer(thinking=True)
        html_p, txt_p, count = await generate_transcript(interaction.channel, ticket)
        await interaction.followup.send(f"📄 {count} messages.",
                                        files=[discord.File(str(html_p)), discord.File(str(txt_p))])

    @app_commands.command(name="close", description="Close this ticket.")
    async def close_cmd(self, interaction: discord.Interaction):
        # Reuse the button flow
        view = TicketButtonsView()
        for c in view.children:
            if isinstance(c, discord.ui.Button) and c.custom_id == "ticket:close":
                await view.close.callback(view, interaction)  # type: ignore
                return
        await interaction.response.send_message("Use the 🗑 Close button on the ticket panel.", ephemeral=True)

    @app_commands.command(name="delete", description="Delete this ticket channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def delete_cmd(self, interaction: discord.Interaction):
        ticket = await db.get_ticket_by_channel(interaction.channel.id)
        if not ticket:
            return await interaction.response.send_message("Not a ticket channel.", ephemeral=True)
        await interaction.response.send_message("❌ Deleting in 3s…")
        await asyncio.sleep(3)
        await db.update_ticket(ticket["_id"], {"status": "deleted"})
        try:
            await interaction.channel.delete()
        except Exception:
            pass

    @app_commands.command(name="rename", description="Rename this ticket channel.")
    async def rename_cmd(self, interaction: discord.Interaction, name: str):
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message("Staffs only.", ephemeral=True)
        await interaction.channel.edit(name=name[:95])
        await interaction.response.send_message(f"📝 Renamed to `{name[:95]}`.")

    @app_commands.command(name="add", description="Add a user to this ticket.")
    async def add_cmd(self, interaction: discord.Interaction, user: discord.Member):
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message("Staffs only.", ephemeral=True)
        await interaction.channel.set_permissions(user, view_channel=True, send_messages=True)
        await interaction.response.send_message(f"➕ {user.mention} added.")

    @app_commands.command(name="remove", description="Remove a user from this ticket.")
    async def remove_cmd(self, interaction: discord.Interaction, user: discord.Member):
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message("Staffs only.", ephemeral=True)
        await interaction.channel.set_permissions(user, overwrite=None)
        await interaction.response.send_message(f"➖ {user.mention} removed.")

    @app_commands.command(name="claim", description="Claim this ticket.")
    async def claim_cmd(self, interaction: discord.Interaction):
        ticket = await db.get_ticket_by_channel(interaction.channel.id)
        if not ticket:
            return await interaction.response.send_message("Not a ticket channel.", ephemeral=True)
        if not await _is_ticket_staff(interaction.user):
            return await interaction.response.send_message("Staffs only.", ephemeral=True)
        if ticket.get("claimed_by"):
            return await interaction.response.send_message("Already claimed.", ephemeral=True)
        await db.update_ticket(ticket["_id"], {"claimed_by": interaction.user.id,
                                                "claimed_ts": time.time(), "status": "claimed"})
        await interaction.response.send_message(f"🎯 Claimed by {interaction.user.mention}.")

    @app_commands.command(name="unclaim", description="Unclaim this ticket.")
    async def unclaim_cmd(self, interaction: discord.Interaction):
        ticket = await db.get_ticket_by_channel(interaction.channel.id)
        if not ticket:
            return await interaction.response.send_message("Not a ticket channel.", ephemeral=True)
        if int(ticket.get("claimed_by") or 0) != interaction.user.id and not _is_admin(interaction.user):
            return await interaction.response.send_message("Only claimer/admin.", ephemeral=True)
        await db.update_ticket(ticket["_id"], {"claimed_by": None, "claimed_ts": None, "status": "open"})
        await interaction.response.send_message("🔓 Unclaimed.")

    @app_commands.command(name="ticketstats", description="Show ticket system statistics.")
    async def stats_cmd(self, interaction: discord.Interaction):
        tickets = await db.list_tickets(interaction.guild.id)
        total = len(tickets)
        open_ = sum(1 for t in tickets if t.get("status") in ("open", "claimed", "locked"))
        closed = sum(1 for t in tickets if t.get("status") == "closed")
        deleted = sum(1 for t in tickets if t.get("status") == "deleted")
        by_cat: dict[str, int] = {}
        for t in tickets:
            by_cat[t["category"]] = by_cat.get(t["category"], 0) + 1
        cat_txt = "\n".join(f"• **{k}** — {v}" for k, v in sorted(by_cat.items(), key=lambda x: -x[1])) or "*no data*"
        e = discord.Embed(title="📊 Ticket Statistics", color=BRAND_COLOR, timestamp=now_utc())
        e.add_field(name="Total", value=str(total))
        e.add_field(name="Open", value=str(open_))
        e.add_field(name="Closed", value=str(closed))
        e.add_field(name="Deleted", value=str(deleted))
        e.add_field(name="By Category", value=cat_txt, inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    # ─── Auto-close inactive tickets ─────────────────────────
    @tasks.loop(minutes=15)
    async def _auto_close_loop(self):
        try:
            for guild in self.bot.guilds:
                cfg = await _get_cfg(guild.id)
                hours = float(cfg.get("auto_close_hours", DEFAULT_AUTO_CLOSE_HOURS))
                if hours <= 0:
                    continue
                threshold = time.time() - hours * 3600
                for t in await db.list_tickets(guild.id):
                    if t.get("status") not in ("open", "claimed", "locked"):
                        continue
                    if float(t.get("last_activity", 0)) < threshold:
                        ch = guild.get_channel(int(t["channel_id"]))
                        if not ch:
                            continue
                        try:
                            await ch.send("⏰ Auto-closing due to prolonged inactivity.")
                            await db.update_ticket(t["_id"], {"status": "closed", "closed_ts": time.time()})
                            await _log(guild, _log_embed("⏰ Auto-Closed", f"`{t['_id']}` inactive > {hours}h", 0xf59e0b))
                        except Exception:
                            pass
        except Exception as e:
            print(f"[tickets] auto_close error: {e}")

    @_auto_close_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    # ─── Track activity ───────────────────────────────────────
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        t = await db.get_ticket_by_channel(message.channel.id)
        if not t:
            return
        updates = {"last_activity": time.time()}
        # First staff response tracking
        if (t.get("claimed_by") and int(t["claimed_by"]) == message.author.id
                and not t.get("first_response_ts")):
            updates["first_response_ts"] = time.time()
        await db.update_ticket(t["_id"], updates)


async def setup(bot: commands.Bot):
    await bot.add_cog(TicketsCog(bot))
