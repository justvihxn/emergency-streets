import discord
from discord.ext import commands
from discord import app_commands
import time

class Ping(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="ping",
        description="📡 Check the bot's WebSocket and API latency."
    )
    async def ping(self, interaction: discord.Interaction):
        start_time = time.perf_counter()
        await interaction.response.defer(thinking=True)
        end_time = time.perf_counter()

        gateway_latency = round(self.bot.latency * 1000)
        api_latency = round((end_time - start_time) * 1000)

        embed = discord.Embed(
            title="🏓 Bot Ping Report",
            description="Get detailed latency info below.",
            color=discord.Color.purple()
        )
        embed.add_field(name="📶 Gateway Latency", value=f"`{gateway_latency}ms`", inline=True)
        embed.add_field(name="⚙️ API Latency", value=f"`{api_latency}ms`", inline=True)
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
        embed.timestamp = discord.utils.utcnow()

        await interaction.followup.send(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(Ping(bot))
