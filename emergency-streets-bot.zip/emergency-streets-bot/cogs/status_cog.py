import discord
from discord.ext import commands, tasks
import itertools


class Status(commands.Cog):
    """Rotates the bot's presence.

    NOTE: Discord rate-limits presence updates to roughly 5 per minute globally.
    Going faster than that will trigger a global 429 ("You are being blocked from
    accessing our API temporarily due to exceeding global rate limits"), which
    then breaks every other request the bot makes (autocomplete, on_message
    handlers, command responses, etc.). The previous value of `seconds=2` was
    the root cause of the 429 storm and has been raised to a safe interval.
    """

    def __init__(self, bot):
        self.bot = bot
        self.activities = itertools.cycle([
            discord.Game("https://discord.gg/DNZyTuNNQA"),
            discord.Activity(type=discord.ActivityType.watching, name="https://discord.gg/DNZyTuNNQA"),
            discord.Activity(type=discord.ActivityType.listening, name="Emergency Streets"),
        ])
        self.presences = itertools.cycle([
            discord.Status.online,
            discord.Status.idle,
            discord.Status.dnd,
        ])
        self.status_task.start()

    def cog_unload(self):
        self.status_task.cancel()

    # Safe rate: one presence update every 3 minutes.
    @tasks.loop(minutes=3)
    async def status_task(self):
        try:
            activity = next(self.activities)
            presence = next(self.presences)
            await self.bot.change_presence(status=presence, activity=activity)
        except Exception as e:
            # Never let presence errors crash the loop
            print(f"[status] change_presence failed: {e}")

    @status_task.before_loop
    async def _before_status(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(Status(bot))
