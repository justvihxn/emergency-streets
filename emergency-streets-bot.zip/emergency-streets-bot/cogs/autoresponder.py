"""Autoresponder cog — embed & text types, role-triggered, slash + prefix.
add/addembed/remove/setrole = BOT OWNER ONLY
list = staff
"""
import discord
from discord.ext import commands
from discord import app_commands
from store import is_staff
from config import OWNER_IDS
from utils.file_handler import load_json, save_json

AR_FILE = "database/autoresponder.json"


def _ar_load() -> dict:
    return load_json(AR_FILE)


def _ar_save(data: dict):
    save_json(AR_FILE, data)


def _ar_guild(data: dict, guild_id) -> dict:
    gid = str(guild_id)
    if gid not in data:
        data[gid] = {}
    return data[gid]


def _is_bot_owner(inter: discord.Interaction) -> bool:
    return inter.user.id in OWNER_IDS


def _is_staff_user(inter: discord.Interaction) -> bool:
    if not inter.guild:
        return False
    if inter.user.id in OWNER_IDS:
        return True
    m = inter.user
    if hasattr(m, "guild_permissions") and m.guild_permissions.administrator:
        return True
    return is_staff(str(inter.guild.id), m)


class AutoResponder(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    ar_grp = app_commands.Group(name="ar", description="Autoresponder management")

    # ─── /ar add ─────────────────────────────────────────────────────────────

    @ar_grp.command(name="add", description="Add a text autoresponse (bot owner only)")
    @app_commands.describe(
        trigger="Trigger keyword/phrase (case-insensitive)",
        response="Response text (use \\n for newlines)",
        role="Only members with this role can trigger it (leave blank = everyone)",
    )
    async def ar_add_text(
        self,
        inter: discord.Interaction,
        trigger: str,
        response: str,
        role: discord.Role = None,
    ):
        if not _is_bot_owner(inter):
            return await inter.response.send_message(
                embed=discord.Embed(title="👑 Owner only", description="Only bot owners can add autoresponders.", color=0xef4444),
                ephemeral=True,
            )
        data = _ar_load()
        guild = _ar_guild(data, inter.guild.id)
        key = trigger.lower().strip()
        guild[key] = {
            "type": "text",
            "response": response.replace("\\n", "\n"),
            "role_id": str(role.id) if role else None,
        }
        _ar_save(data)
        desc = f"**Trigger:** `{key}`\n**Type:** Text\n**Role:** {role.mention if role else 'Everyone'}"
        e = discord.Embed(title="✅ Autoresponder added", description=desc, color=0x22c55e)
        await inter.response.send_message(embed=e, ephemeral=True)

    # ─── /ar add-embed ────────────────────────────────────────────────────────

    @ar_grp.command(name="add-embed", description="Add an embed autoresponse (bot owner only)")
    @app_commands.describe(
        trigger="Trigger keyword/phrase (case-insensitive)",
        title="Embed title",
        description="Embed description (use \\n for newlines)",
        color="HEX color e.g. 9b59b6 (default: purple)",
        image="Full image URL shown at the bottom of the embed (optional)",
        thumbnail="Small thumbnail URL shown top-right of the embed (optional)",
        role="Only members with this role can trigger it (leave blank = everyone)",
    )
    async def ar_add_embed(
        self,
        inter: discord.Interaction,
        trigger: str,
        title: str,
        description: str,
        color: str = "9b59b6",
        image: str = None,
        thumbnail: str = None,
        role: discord.Role = None,
    ):
        if not _is_bot_owner(inter):
            return await inter.response.send_message(
                embed=discord.Embed(title="👑 Owner only", description="Only bot owners can add autoresponders.", color=0xef4444),
                ephemeral=True,
            )
        try:
            color_int = int(color.lstrip("#"), 16)
        except Exception:
            color_int = 0x9b59b6
        data = _ar_load()
        guild = _ar_guild(data, inter.guild.id)
        key = trigger.lower().strip()
        guild[key] = {
            "type": "embed",
            "embed": {
                "title": title,
                "description": description.replace("\\n", "\n"),
                "color": color_int,
                "image": image or None,
                "thumbnail": thumbnail or None,
            },
            "role_id": str(role.id) if role else None,
        }
        _ar_save(data)

        preview = discord.Embed(
            title=title,
            description=description.replace("\\n", "\n"),
            color=color_int,
        )
        if image:
            preview.set_image(url=image)
        if thumbnail:
            preview.set_thumbnail(url=thumbnail)
        preview.set_footer(text=f"Trigger: {key} | Role: {role.mention if role else 'Everyone'}")

        confirm = discord.Embed(title="✅ Embed autoresponder added", color=0x22c55e)
        confirm.add_field(name="Trigger", value=f"`{key}`", inline=True)
        confirm.add_field(name="Role", value=role.mention if role else "Everyone", inline=True)
        if image:
            confirm.add_field(name="Image", value="✅ set", inline=True)
        if thumbnail:
            confirm.add_field(name="Thumbnail", value="✅ set", inline=True)

        await inter.response.send_message(embeds=[confirm, preview], ephemeral=True)

    # ─── /ar remove ──────────────────────────────────────────────────────────

    @ar_grp.command(name="remove", description="Remove an autoresponse (bot owner only)")
    @app_commands.describe(trigger="The trigger to remove")
    async def ar_remove(self, inter: discord.Interaction, trigger: str):
        if not _is_bot_owner(inter):
            return await inter.response.send_message(
                embed=discord.Embed(title="👑 Owner only", description="Only bot owners can remove autoresponders.", color=0xef4444),
                ephemeral=True,
            )
        data = _ar_load()
        guild = _ar_guild(data, inter.guild.id)
        key = trigger.lower().strip()
        if key not in guild:
            return await inter.response.send_message(f"❌ No autoresponse for `{key}`.", ephemeral=True)
        del guild[key]
        _ar_save(data)
        await inter.response.send_message(f"🗑️ Removed autoresponse for `{key}`.", ephemeral=True)

    # ─── /ar list ────────────────────────────────────────────────────────────

    @ar_grp.command(name="list", description="List all autoresponses for this server (staff)")
    async def ar_list(self, inter: discord.Interaction):
        if not _is_staff_user(inter):
            return await inter.response.send_message("🚫 Staff only.", ephemeral=True)
        data = _ar_load()
        guild = _ar_guild(data, inter.guild.id)
        if not guild:
            return await inter.response.send_message("No autoresponses configured.", ephemeral=True)
        e = discord.Embed(title="📋 Guild Autoresponses", color=0x9b59b6)
        e.set_footer(text=f"{len(guild)} total autoresponse(s)")
        for key, val in list(guild.items())[:25]:
            role_str = f"<@&{val['role_id']}>" if val.get("role_id") else "Everyone"
            type_str = val.get("type", "text").title()
            has_image = "🖼️" if val.get("type") == "embed" and val.get("embed", {}).get("image") else ""
            has_thumb = "🔲" if val.get("type") == "embed" and val.get("embed", {}).get("thumbnail") else ""
            extras = f" {has_image}{has_thumb}".rstrip()
            e.add_field(
                name=f"`{key}`",
                value=f"**{type_str}**{extras} | Role: {role_str}",
                inline=False,
            )
        await inter.response.send_message(embed=e, ephemeral=True)

    # ─── Listener ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        data = _ar_load()
        guild_data = data.get(str(message.guild.id), {})
        if not guild_data:
            return
        content_lower = message.content.lower()
        for trigger, val in guild_data.items():
            if trigger not in content_lower:
                continue
            role_id = val.get("role_id")
            if role_id:
                role = message.guild.get_role(int(role_id))
                if role and role not in message.author.roles:
                    continue
            try:
                if val.get("type") == "embed":
                    emb_data = val.get("embed", {})
                    resp_embed = discord.Embed(
                        title=emb_data.get("title"),
                        description=emb_data.get("description"),
                        color=emb_data.get("color", 0x9b59b6),
                    )
                    if emb_data.get("image"):
                        resp_embed.set_image(url=emb_data["image"])
                    if emb_data.get("thumbnail"):
                        resp_embed.set_thumbnail(url=emb_data["thumbnail"])
                    await message.channel.send(embed=resp_embed)
                else:
                    await message.channel.send(val.get("response", ""))
            except Exception:
                pass
            break


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoResponder(bot))
