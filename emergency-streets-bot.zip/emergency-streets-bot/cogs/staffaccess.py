import discord
from discord.ext import commands


class StaffAccess(commands.Cog):
    """Placeholder cog — staff role management is handled by /staff in __init__.py."""
    def __init__(self, bot: commands.Bot):
        self.bot = bot


async def setup(bot: commands.Bot):
    await bot.add_cog(StaffAccess(bot))