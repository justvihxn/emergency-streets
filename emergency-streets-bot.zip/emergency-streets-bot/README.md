# Emergency Streets Discord Bot

A Discord bot focused on community support, safety, and staff operations.

## Included

- Ticket system with configurable **ticket staff** roles, categories, claim/unclaim, notes, priority, transcripts, reopening, and ticket logs
- Moderation commands and moderation case history
- Antinuke and automod protections
- DM broadcast tools
- Staff requirements/application panel
- Giveaway management
- Utility, AFK, autoresponder, logging, invite, and staff-access tools

## Removed

Selling, shop/products, orders, seller profiles, UPI, cryptocurrency, vouchers, and all minigames have been removed.

## Setup

1. Install Python 3.10 or newer.
2. Run `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env` and set the Discord token and owner IDs.
4. Start with `python bot.py` or `bash start.sh`.

### Ticket setup

Use `/ticketconfig` to set the ticket staff role, log channel, ticket category, cooldown, and inactivity timeout. You can also manage ticket staff roles with `/addticketstaff` and `/removeticketstaff`.

### Core retained commands

- Tickets: `/ticketpanel`, `/ticketconfig`, `/claim`, `/unclaim`, `/close`, `/transcript`, `/ticketpriority`, `/ticketnote`, `/ticketreopen`
- Moderation: `/warn`, `/warnings`, `/kick`, `/ban`, `/mute`, `/purge`, `/lockdown`, `/case`, `/modstats`
- Giveaways: `/gstart`, `/gend`, `/greroll`, `/gpause`, `/gunpause`, `/gedit`, `/gcancel`, `/glist`
- DM broadcast, antinuke, automod, staff roles, and recruitment are also available through their slash/prefix command groups.
