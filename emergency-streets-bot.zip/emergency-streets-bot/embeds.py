"""Embed helpers"""
from datetime import datetime, timezone
from typing import Optional
import discord
from config import BRAND


def expand_newlines(text: Optional[str]) -> str:
    if not text:
        return ""
    return (
        text.replace("\\r\\n", "\n")
        .replace("\\n", "\n")
        .replace("<br/>", "\n").replace("<br>", "\n").replace("<br />", "\n")
    )


def brand_embed() -> discord.Embed:
    e = discord.Embed(color=BRAND["color"], timestamp=datetime.now(timezone.utc))
    e.set_footer(text=BRAND["footer"])
    return e


def success_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    e = brand_embed()
    e.color = discord.Color(BRAND["successColor"])
    e.title = title
    if description:
        e.description = description
    return e


def error_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    e = brand_embed()
    e.color = discord.Color(BRAND["errorColor"])
    e.title = title
    if description:
        e.description = description
    return e


def info_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    e = brand_embed()
    e.color = discord.Color(BRAND["infoColor"])
    e.title = title
    if description:
        e.description = description
    return e


def warn_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    e = brand_embed()
    e.color = discord.Color(BRAND["warnColor"])
    e.title = title
    if description:
        e.description = description
    return e
